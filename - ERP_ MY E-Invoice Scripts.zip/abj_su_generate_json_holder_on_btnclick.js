/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Task              Date                Author                                         Remarks
 * E-Invoice JSON    09-07-2024        sayyad@abjcloudsolutions.com   
*/
 define(['N/record','N/redirect'],

    function(record, redirect) {

        function onRequest(context) {
            var request = context.request;
            if(request.parameters.custom_tranid && request.parameters.custom_trantype){
                record.load({
                    type: request.parameters.custom_trantype,
                    id: request.parameters.custom_tranid
                }).setValue({
                    fieldId:"custbody_my_e_inv_create_data",
                    value:true
                }).save();

                redirect.toRecord({
                    id: request.parameters.custom_tranid,
                    type: request.parameters.custom_trantype,
                });
            }
        }

        return {
            onRequest: onRequest
        };
     }
);