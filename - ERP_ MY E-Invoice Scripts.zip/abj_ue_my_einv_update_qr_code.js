/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/*******************************************************************************
 * **Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 * @Client        :  SRI E-Invoice
 * @Script File   :  abj_ue_my_einv_update_qr_code.js 
 * @script Record : - EINV UE | E-Invoice Update QR Code
 * @Trigger Type  :  afterSubmit
 * @Release Date  :  31/07/2024
 * @Author        :  SIRUSOLLA NAGARJUNA
 * @Description   :  This script is used  to Update  qr code status before saving the record.
 * @Deployment To :  "invoice"
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @Ticket_id : TECH-181
 *
 ******************************************************************************/
define(['N/record', 'N/runtime', 'N/search'], function (record, runtime, search) {
    function beforeLoad(context) {
        if (context.type === "view") {
            try {
                var mySearch = search.create({
                    type: "customrecord_my_einv_tax_data",
                    filters: [
                        ["custrecord_my_e_inv_linked_rec", "anyof", context.newRecord.id],
                        "AND",
                        ["custrecord_my_e_inv_doc_val_status", "is", "Valid"],
                        "AND",
                        ["isinactive","is",false]
                    ],
                    columns: [
                        "custrecord_my_e_inv_uuid",
                        "custrecord_my_e_inv_data_longid",
                        "custrecord_my_e_inv_doc_val_status"
                    ]
                });
                var results = mySearch.run().getRange({
                    start: 0,
                    end: 1
                });
                if (results.length > 0) {
                    var result = results[0];
                    var uuid = result.getValue("custrecord_my_e_inv_uuid");
                    var longId = result.getValue("custrecord_my_e_inv_data_longid");
                   // log.debug("UUID", uuid);
                   // log.debug("Long ID", longId);
                    if (runtime.envType == "SANDBOX") {
                        var formattedURL = "https://preprod.myinvois.hasil.gov.my/" + uuid + "/share/" + longId;
                    }
                    if (runtime.envType == "PRODUCTION") {
                        var formattedURL = "https://myinvois.hasil.gov.my/" + uuid + "/share/" + longId;
                    }
                    log.debug("Formatted URL beforeload :", formattedURL);
                    var id = record.submitFields({
                        type: context.newRecord.type,
                        id: context.newRecord.id,
                        values: {
                            custbody_ein_t_qr_code: formattedURL,
                        }
                    });
                    log.debug("id: beforeload", id);
                } else {
                    log.debug("Search Results", "No results found.");
                }
                var scriptObj = runtime.getCurrentScript();
                var remainingUsage = scriptObj.getRemainingUsage();
                var totalUnits = 1000;
               // log.debug("Current script consuming units: ", totalUnits - remainingUsage);
            } catch (e) {
                log.error(e.name, e.message);
            }
        }
    }

    function afterSubmit(context) {
        try {

            var mySearch = search.create({
                type: "customrecord_my_einv_tax_data",
                filters: [
                    ["custrecord_my_e_inv_linked_rec", "anyof", context.newRecord.id],
                    "AND",
                    ["custrecord_my_e_inv_doc_val_status", "is", "Valid"],
                    "AND",
                    ["isinactive","is",false]
                ],
                columns: [
                    "custrecord_my_e_inv_uuid",
                    "custrecord_my_e_inv_data_longid",
                    "custrecord_my_e_inv_doc_val_status"
                ]
            });
            var results = mySearch.run().getRange({
                start: 0,
                end: 1
            });
            if (results.length > 0) {
                var result = results[0];
                var uuid = result.getValue("custrecord_my_e_inv_uuid");
                var longId = result.getValue("custrecord_my_e_inv_data_longid");
               // log.debug("UUID", uuid);
               // log.debug("Long ID", longId);
                if (runtime.envType == "SANDBOX") {
                    var formattedURL = "https://preprod.myinvois.hasil.gov.my/" + uuid + "/share/" + longId;
                }
                if (runtime.envType == "PRODUCTION") {
                    var formattedURL = "https://myinvois.hasil.gov.my/" + uuid + "/share/" + longId;
                }
                var id = record.submitFields({
                    type: context.newRecord.type,
                    id: context.newRecord.id,
                    values: {
                        custbody_ein_t_qr_code: formattedURL,
                    }
                });
                log.debug("id: aftersubmit ", id);
                log.debug("Formatted URL aftersubmit :", formattedURL);
            } else {
                log.debug("Search Results", "No results found.");
            }
            var scriptObj = runtime.getCurrentScript();
            var remainingUsage = scriptObj.getRemainingUsage();
            var totalUnits = 1000;
          //  log.debug("Current script consuming units: ", totalUnits - remainingUsage);
        } catch (e) {
            log.error(e.name, e.message);
        }
    }
    return {
        beforeLoad: beforeLoad,
        afterSubmit: afterSubmit
    };
});