/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Task          Date                Author                                         Remarks
 * MY E-Invoice 29th Apr 2024   sayyad@abjcloudsolutions.com       
 */
define(['N/record', 'N/ui/serverWidget', 'N/search', 'N/redirect', 'N/https', 'N/ui/message', 'N/url'],

    function (record, serverWidget, search, redirect, https, message, url) {

        function onRequest(context) {
            try {
                switch (context.request.method) {
                    case "GET":
                        createUIForm(context);
                        break;
                    case "POST":
                        saveFormData(context);
                        break;
                    default:
                        context.response.write("Not supported method");
                        break;
                }
            } catch (ex) {
                log.error(ex.name, ex);
            }
        }

        /**
         * create the form and represent on the webpage
         */
        createUIForm = (context) => {
            let mode = context.request.parameters['mode'];
            var configId = context.request.parameters['custom_config_id'];
            var configSetupSearch = [];
            if(mode == "edit" || !mode){
                configSetupSearch = search.create({
                    type: 'customrecord_my_einv_con_setup',
                    columns: [
                        'internalid',
                        'custrecord_my_e_inv_clientid',
                        'custrecord_my_e_inv_client_secret',
                        'custrecord_my_e_inv_client_secret2',
                        'custrecord_my_e_invoice_base_url',
                        'custrecord_my_e_invoice_subsidiary',
                        'custrecord_my_e_inv_tin',
                        'custrecord_my_e_inv_brn',
                        'custrecord_my_e_inv_tin_validstatus',
                        'custrecord_my_e_inv_tin_autojsonhold',
                        'custrecord_my_e_inv_tin_autoappreinv'
                    ],
                    filters: [
                        ["internalid","anyof",configId]
                    ]
                }).run().getRange(0, 10);
            }


            var formObj = serverWidget.createForm({
                title: "Malaysia E-Invoice Connection Setup",
                hideNavBar: false
            });

            var fieldgroup2 = formObj.addFieldGroup({
                id: "custpage_my_einv_company_ids",
                label: "Registered E-Invoice Company Details"
            })

            var subsidiaryField = formObj.addField({
                id: "custpage_my_einv_subsidiary",
                label: "Subsidiary",
                type: serverWidget.FieldType.SELECT,
                container: "custpage_my_einv_company_ids",
                source: 'subsidiary'
            });
            var tinField = formObj.addField({
                id: "custpage_my_einv_tin",
                label: "TIN",
                type: serverWidget.FieldType.TEXT,
                container: "custpage_my_einv_company_ids"
            });
            var brnField = formObj.addField({
                id: "custpage_my_einv_brn",
                label: "BRN",
                type: serverWidget.FieldType.TEXT,
                container: "custpage_my_einv_company_ids"
            });
            var tinValidStatusField = formObj.addField({
                id: "custpage_my_einv_validstatus",
                label: "TIN Validation Status Code",
                type: serverWidget.FieldType.TEXT,
                container: "custpage_my_einv_company_ids"
            });

            var fieldgroup = formObj.addFieldGroup({
                id: "custpage_my_einv_tokens",
                label: "MY E-Invoice Tokens"
            })
            var clientIDField = formObj.addField({
                id: "custpage_my_einv_clientid",
                label: "Client ID",
                type: serverWidget.FieldType.TEXT,
                container: "custpage_my_einv_tokens"
            });
            var clientSecretField = formObj.addField({
                id: "custpage_my_einv_clientsecret",
                label: "Client Secret 1",
                type: serverWidget.FieldType.TEXT,
                container: "custpage_my_einv_tokens"
            });
            var clientSecret2Field = formObj.addField({
                id: "custpage_my_einv_clientsecret2",
                label: "Client Secret 2",
                type: serverWidget.FieldType.TEXT,
                container: "custpage_my_einv_tokens"
            });
            var apiBaseURLField = formObj.addField({
                id: "custpage_my_einv_baseurl",
                label: "API Base URL",
                type: serverWidget.FieldType.TEXT,
                container: "custpage_my_einv_tokens"
            });

            var recordActionField = formObj.addField({
                id: "custpage_my_einv_rec_action",
                label: "Record Action",
                type: serverWidget.FieldType.TEXT,
                container: "custpage_my_einv_tokens"
            });
            recordActionField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.HIDDEN
            });
            recordActionField.defaultValue = mode;


            var configIDField = formObj.addField({
                id: "custpage_my_einv_config_id",
                label: "Config ID",
                type: serverWidget.FieldType.TEXT,
                container: "custpage_my_einv_tokens"
            });
            configIDField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.HIDDEN
            });
            configIDField.defaultValue = configId;
            fieldgroup.isSingleColumn = true;
            fieldgroup2.isSingleColumn = true;
            // fieldgroup.isBorderHidden = true;

            clientIDField.isMandatory = true;
            clientSecretField.isMandatory = true;
            subsidiaryField.isMandatory = true;
            clientSecret2Field.isMandatory = true;
            apiBaseURLField.isMandatory = true;
            tinField.isMandatory = true;
            brnField.isMandatory = true;

            tinValidStatusField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            //auto approve and auto create fields
            var fieldgroup2 = formObj.addFieldGroup({
                id: "custpage_my_einv_auto_approve",
                label: "Automation Information"
            });

            var autoCreateJSONHolderField = formObj.addField({
                id: "custpage_my_einv_autocreatejson",
                label: "Create JSON Holder",
                type: serverWidget.FieldType.CHECKBOX,
                container: "custpage_my_einv_auto_approve"
            });

            var autoApproveField = formObj.addField({
                id: "custpage_my_einv_autoapprove",
                label: "Send to LHDN",
                type: serverWidget.FieldType.CHECKBOX,
                container: "custpage_my_einv_auto_approve"
            });

            /** setting the field type as inline if the record exist */
            if (configSetupSearch.length == 1) {
                clientIDField.updateDisplayType({
                    displayType: (mode == "edit") ? serverWidget.FieldDisplayType.NORMAL : serverWidget.FieldDisplayType.INLINE
                });
                clientSecretField.updateDisplayType({
                    displayType: (mode == "edit") ? serverWidget.FieldDisplayType.NORMAL : serverWidget.FieldDisplayType.INLINE
                });
                apiBaseURLField.updateDisplayType({
                    displayType: (mode == "edit") ? serverWidget.FieldDisplayType.NORMAL : serverWidget.FieldDisplayType.INLINE
                });
                subsidiaryField.updateDisplayType({
                    displayType: (mode == "edit") ? serverWidget.FieldDisplayType.NORMAL : serverWidget.FieldDisplayType.INLINE
                });
                clientSecret2Field.updateDisplayType({
                    displayType: (mode == "edit") ? serverWidget.FieldDisplayType.NORMAL : serverWidget.FieldDisplayType.INLINE
                });
                tinField.updateDisplayType({
                    displayType: (mode == "edit") ? serverWidget.FieldDisplayType.NORMAL : serverWidget.FieldDisplayType.INLINE
                });
                brnField.updateDisplayType({
                    displayType: (mode == "edit") ? serverWidget.FieldDisplayType.NORMAL : serverWidget.FieldDisplayType.INLINE
                });

                autoCreateJSONHolderField.updateDisplayType({
                    displayType: (mode == "edit") ? serverWidget.FieldDisplayType.NORMAL : serverWidget.FieldDisplayType.INLINE
                });
                autoApproveField.updateDisplayType({
                    displayType: (mode == "edit") ? serverWidget.FieldDisplayType.NORMAL : serverWidget.FieldDisplayType.INLINE
                });

                clientIDField.defaultValue = configSetupSearch[0].getValue("custrecord_my_e_inv_clientid");
                clientSecretField.defaultValue = configSetupSearch[0].getValue("custrecord_my_e_inv_client_secret");
                apiBaseURLField.defaultValue = configSetupSearch[0].getValue("custrecord_my_e_invoice_base_url");
                subsidiaryField.defaultValue = configSetupSearch[0].getValue("custrecord_my_e_invoice_subsidiary");
                clientSecret2Field.defaultValue = configSetupSearch[0].getValue("custrecord_my_e_inv_client_secret2");
                tinField.defaultValue = configSetupSearch[0].getValue("custrecord_my_e_inv_tin");
                brnField.defaultValue = configSetupSearch[0].getValue("custrecord_my_e_inv_brn");
                tinValidStatusField.defaultValue = configSetupSearch[0].getValue("custrecord_my_e_inv_tin_validstatus");
                autoCreateJSONHolderField.defaultValue = configSetupSearch[0].getValue("custrecord_my_e_inv_tin_autojsonhold") ? "T" : "F";
                autoApproveField.defaultValue = configSetupSearch[0].getValue("custrecord_my_e_inv_tin_autoappreinv") ? "T" : "F"
                if (!mode) {
                    var output = url.resolveScript({
                        scriptId: "customscript_su_my_einv_con_setup",
                        deploymentId: "customdeploy_su_my_einv_con_setup",
                        params:{
                            custom_config_id: configId
                        }
                    });
                    if (context.request.parameters['tokens_valid'] == "true") {
                        formObj.addPageInitMessage(message.create({
                            type: context.request.parameters['tin_valid'] == "false" ? message.Type.WARNING : message.Type.CONFIRMATION,
                            title: "VALIDATION WARNING",
                            message: context.request.parameters['tin_valid'] == "false" ? "TIN validation failed." : "Client ID & Client Secret and TIN validated successfully.",
                            duration: 5000
                        }));
                        formObj.addField({
                            id: "custpage_my_einv_inlinehtml",
                            label: "inlineHTML",
                            type: serverWidget.FieldType.INLINEHTML
                        }).defaultValue = "<script>setTimeout(history.pushState({}, null, '"+output+"'), 1000);</script>";
                    }

                    formObj.addButton({
                        id: "custpage_edit_form",
                        label: "Edit",
                        functionName: "require(['N/url'],(url)=>{let suiteleturl = url.resolveScript({scriptId: 'customscript_su_my_einv_con_setup',deploymentId: 'customdeploy_su_my_einv_con_setup',params:{mode:'edit', custom_config_id:'"+configId+"'}}); location.href = suiteleturl;})"
                    });

                    formObj.addButton({
                        id: "custpage_create_new",
                        label: "New Record",
                        functionName: "require(['N/url'],(url)=>{let suiteleturl = url.resolveScript({scriptId: 'customscript_su_my_einv_con_setup',deploymentId: 'customdeploy_su_my_einv_con_setup',params:{mode:'createnew'}}); location.href = suiteleturl;})"
                    });
                }
            }
            if (mode == "edit" || configSetupSearch.length <= 0) {
                formObj.addSubmitButton({
                    label: "Submit"
                });
                formObj.addButton({
                    id: "custpage_cancel_edit",
                    label: "Cancel",
                    functionName: "history.go(-1);"
                });
            }

            context.response.writePage(formObj);
        }

        /**
         * save the submitted form data on the record and redirec to suitelet view
         */
        saveFormData = (context) => {
            var dataObj = context.request.parameters;
            log.debug("POST dataObj", dataObj);
            let client_id = dataObj['custpage_my_einv_clientid'];
            let client_secret = dataObj['custpage_my_einv_clientsecret'];
            
            //duplicate detection for connection
            if(context.request.parameters.custpage_my_einv_subsidiary){
                let configFilter = [['custrecord_my_e_invoice_subsidiary','anyof',context.request.parameters.custpage_my_einv_subsidiary]];
                if(dataObj['custpage_my_einv_config_id']){
                    configFilter.push("AND",["internalid","noneof",dataObj['custpage_my_einv_config_id']]);
                }
                let configSetupSearch = search.create({
                    type: 'customrecord_my_einv_con_setup',
                    columns: ['internalid'],
                    filters: configFilter
                }).run().getRange(0, 10);
                if(configSetupSearch.length > 0){
                    let formObj = serverWidget.createForm({
                        title: "Malaysia E-Invoice Connection Setup",
                        hideNavBar: false
                    });
                    formObj.addField({
                        id: "custpage_my_einv_message",
                        label: "inlineHTML",
                        type: serverWidget.FieldType.INLINEHTML
                    }).defaultValue = "<h3>Error : <b>Duplicate subsidiary not allowed to setup connection.</b></h3>";
                    context.response.writePage(formObj);
                    return;
                }
            }

            let configFil = [];
            if(dataObj['custpage_my_einv_config_id']){
                configFil.push(["internalid","anyof",dataObj['custpage_my_einv_config_id']]);
            }
            let configSetupSearch = search.create({
                type: 'customrecord_my_einv_con_setup',
                columns: [
                    'internalid',
                    'custrecord_my_e_inv_clientid',
                    'custrecord_my_e_inv_client_secret',
                    'custrecord_my_e_inv_client_secret2',
                    'custrecord_my_e_invoice_base_url',
                    'custrecord_my_e_invoice_subsidiary',
                    'custrecord_my_e_inv_tin',
                    'custrecord_my_e_inv_brn'
                ],
                filters: configFil
            }).run().getRange(0, 10);

            /**
             * load or create the config setup record as per record search
             */
            var configSetupRec;
            if (configSetupSearch.length == 1 && dataObj['custpage_my_einv_rec_action'] != "createnew") {
                configSetupRec = record.load({
                    type: 'customrecord_my_einv_con_setup',
                    id: configSetupSearch[0].getValue('internalid')
                });
            } else if (configSetupSearch.length == 0 || dataObj['custpage_my_einv_rec_action'] == "createnew") {
                configSetupRec = record.create({
                    type: 'customrecord_my_einv_con_setup'
                });
            }

            let tokenResObj = https.post({
                url: `https://${context.request.parameters.custpage_my_einv_baseurl}/connect/token`,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Accept": "*/*"
                },
                body: `client_id=${client_id}&client_secret=${client_secret}&grant_type=client_credentials&scope=InvoicingAPI`
            });

            let tokenBody = JSON.parse(tokenResObj.body);

            log.audit("tokenResObj", tokenResObj);

            if (tokenResObj.code != 200) {
                var formObj = serverWidget.createForm({
                    title: "Malaysia E-Invoice Connection Setup",
                    hideNavBar: false
                });
                formObj.addPageInitMessage(message.create({
                    type: message.Type.ERROR,
                    title: tokenBody["error"],
                    message: "Client ID & Client Secret is incorrect"
                }));
                formObj.addButton({
                    id: "custpage_goback",
                    label: "Go Back",
                    functionName: "history.go(-1);"
                });
                context.response.writePage(formObj);
                return;
            }

            //validating the TIN and BRN status
            let tinValidationReponse = https.get({
                url: `https://${context.request.parameters.custpage_my_einv_baseurl}/api/v1.0/taxpayer/validate/${context.request.parameters.custpage_my_einv_tin}?idType=BRN&idValue=${context.request.parameters.custpage_my_einv_brn}`,
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "*/*",
                    "Authorization": `Bearer ${tokenBody.access_token}`
                }
            });

            var configId = configSetupRec.setValue({
                fieldId: "custrecord_my_e_inv_clientid",
                value: client_id
            }).setValue({
                fieldId: "custrecord_my_e_inv_client_secret",
                value: client_secret
            }).setValue({
                fieldId: "custrecord_my_e_invoice_base_url",
                value: context.request.parameters.custpage_my_einv_baseurl
            }).setValue({
                fieldId: "custrecord_my_e_invoice_subsidiary",
                value: context.request.parameters.custpage_my_einv_subsidiary
            }).setValue({
                fieldId: "custrecord_my_e_inv_client_secret2",
                value: context.request.parameters.custpage_my_einv_clientsecret2
            }).setValue({
                fieldId: "custrecord_my_e_inv_tin",
                value: context.request.parameters.custpage_my_einv_tin
            }).setValue({
                fieldId: "custrecord_my_e_inv_brn",
                value: context.request.parameters.custpage_my_einv_brn
            }).setValue({
                fieldId: "custrecord_my_e_inv_tin_validstatus",
                value: tinValidationReponse.code
            }).setValue({
                fieldId:"custrecord_my_e_inv_tin_autojsonhold",
                value:context.request.parameters.custpage_my_einv_autocreatejson == "T"
            }).setValue({
                fieldId:"custrecord_my_e_inv_tin_autoappreinv",
                value:context.request.parameters.custpage_my_einv_autoapprove == "T"
            }).save({
                enableSourcing: false,
                ignoreMandatoryFields: true
            });

            redirect.toSuitelet({
                scriptId: "customscript_su_my_einv_con_setup",
                deploymentId: "customdeploy_su_my_einv_con_setup",
                parameters: {
                    tokens_valid: true,
                    tin_valid: tinValidationReponse.code == 200,
                    custom_config_id: configId
                }
            });
        }

        /**
         * 
         * @param {number} length 
         * @param {string} chars 
         * @returns 
         */
        randomString = (length, chars) => {
            var result = '';
            for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
            return result;
        }

        return {
            onRequest: onRequest
        };
    }
);