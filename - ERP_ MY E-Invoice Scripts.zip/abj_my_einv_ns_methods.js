/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
define([
    'N/search',
    'N/config'
], function (search, config) {

    const getCustomerDetails = (currRec, entityType, isPerson) => {
        log.debug("isPerson",isPerson);
        //Scriptable search to fetch all the customer details
        let entityCol = [
            entityType == "Employee" || entityType == "employee" ? "internalid" : "terms",
            "custentity_ein_c_city",
            "custentity_ein_c_state",
            "custentity_ein_c_country",
            entityType == "Vendor" || entityType == "vendor" ? "companyname" : "internalid",
            entityType == "Employee" || entityType == "employee" ? "custentity_ein_c_tax_reg_no" : search.createColumn({
                name: "vatregnumber",
                label: "TIN Reg.no."
            }),
            search.createColumn({
                name: "custentity_ein_c_regnotype",
                label: "Type OF Registration no."
            }),
            search.createColumn({
                name: "custentity_ein_c_registrationno",
                label: "Registration no."
            }),
            search.createColumn({
                name: "custentity_ein_c_sstregistrationno",
                label: "SST Registration no."
            }),
            search.createColumn({
                name: "email",
                label: "Buyer's E-Mail"
            }),
            search.createColumn({
                name: "addressee",
                join: "Address",
                label: "Address Line 0"
            }),
            search.createColumn({
                name: "address1",
                join: "Address",
                label: "Address Line 1"
            }),
            search.createColumn({
                name: "address2",
                join: "Address",
                label: "Address Line 2"
            }),
            search.createColumn({
                name: "zipcode",
                join: "Address",
                label: "Zip"
            }),
            search.createColumn({
                name: "city",
                join: "Address",
                label: "City"
            }),
            search.createColumn({
                name: "state",
                join: "address",
                label: "State"
            }),
            search.createColumn({
                name: "country",
                join: "address",
                label: "Country"
            }),
            search.createColumn({
                name: "phone",
                label: "Contact Number"
            }),
            search.createColumn({
                name:"custentity_ein_c_msic",
                lable:"MSIC"
            })
        ];

        if(entityType == "Employee" || entityType == "employee"){
            entityCol.push("firstname");
        }else{
            isPerson ? entityCol.push("altname") : entityCol.push("companyname");
        }

        return search.create({
            type: entityType,
            filters: [
                ["internalid", "anyof", currRec.getValue("entity")],
                "AND", 
                ["address.isdefaultshipping","is","T"], 
                "AND", 
                ["address.address1","isnotempty",""], 
                "AND", 
                ["address.address2","isnotempty",""]
            ],
            columns: entityCol
        }).run().getRange(0, 1);
    }

    const getSupplierDetails = (subsidiaryId, isMulSub) => {
        if (isMulSub) {
            //Scriptable search to fetch all the supplier details
            let subsidiarySearch = search.create({
                type: "subsidiary",
                filters: [
                    ["internalid", "anyof", subsidiaryId]
                ],
                columns: [
                    search.createColumn({
                        name: "legalname",
                        label: "Registartion Name"
                    }),
                    search.createColumn({
                        name: "custrecord_ein_s_tinregno",
                        label: "TIN Reg.no."
                    }),
                    search.createColumn({
                        name: "custrecord_ein_s_regnotype",
                        label: "Type OF Registration no."
                    }),
                    search.createColumn({
                        name: "custrecord_ein_s_suppliersregistrationno",
                        label: "Registration no."
                    }),
                    search.createColumn({
                        name: "custrecord_ein_s_sstregistrationno",
                        label: "SST Registration no."
                    }),
                    search.createColumn({
                        name: "custrecord_ein_s_tourismtaxregno",
                        label: "Tourism Tax Registration no."
                    }),
                    search.createColumn({
                        name: "email",
                        label: "E-Mail ID"
                    }),
                    search.createColumn({
                        name: "custrecord_ein_s_msic",
                        label: "MSIC"
                    }),
                    search.createColumn({
                        name: "addressee",
                        join: "address",
                        label: "Address Line 0"
                    }),
                    search.createColumn({
                        name: "address1",
                        join: "address",
                        label: "Address Line 1"
                    }),
                    search.createColumn({
                        name: "address2",
                        join: "address",
                        label: "Address Line 2"
                    }),
                    search.createColumn({
                        name: "zip",
                        join: "address",
                        label: "Zip"
                    }),
                    search.createColumn({
                        name: "city",
                        join: "address",
                        label: "City"
                    }),
                    search.createColumn({
                        name: "state",
                        join: "address",
                        label: "State"
                    }),
                    search.createColumn({
                        name: "country",
                        join: "address",
                        label: "Country"
                    }),
                    search.createColumn({
                        name: "phone",
                        label: "Contact no."
                    }),
                    search.createColumn({
                        name: "custrecord_ein_s_bankaccno",
                        label: "PRIMARY BANK ACCOUNT NUMBER"
                    })
                ]
            });

            let subsidiarySearchResults = subsidiarySearch.run().getRange(0, 1);


            return {
                registor_name: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[0]),
                tin_reg_no: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[1]),
                type_of_reg: subsidiarySearchResults[0].getText(subsidiarySearch.columns[2]),
                reg_no: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[3]),
                sst_reg_no: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[4]),
                toursim_tax_reg_no: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[5]),
                email_id: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[6]),
                msic: subsidiarySearchResults[0].getText(subsidiarySearch.columns[7]),
                addressee: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[8]),
                addr1: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[9]),
                addr2: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[10]),
                zip: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[11]),
                city: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[12]),
                state: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[13]),
                country: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[14]),
                phone: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[15]).replace(/[^\d.-]/g, ""),
                pri_bank_acc_no: subsidiarySearchResults[0].getValue(subsidiarySearch.columns[16])
            }
        } else {
            var companyInfo = config.load({
                type: config.Type.COMPANY_INFORMATION
            });
            
            var tin = companyInfo.getValue({
                fieldId: 'custrecord_ein_s_tinregno'
            });
            log.debug("TIN", tin);

            var regType = companyInfo.getText({
                fieldId: 'custrecord_ein_s_regnotype'
            });
            log.debug("regType", regType);
            var regID = companyInfo.getValue({
                fieldId: 'custrecord_ein_s_suppliersregistrationno'
            });
            log.debug("regID", regID);
            var sstID = companyInfo.getValue({
                fieldId: 'custrecord_ein_s_sstregistrationno'
            });
            log.debug("sstID", sstID);
            var ttrnID = companyInfo.getValue({
                fieldId: 'custrecord_ein_s_tourismtaxregno'
            });
            log.debug("ttrnID", ttrnID);
            var msic = companyInfo.getText({
                fieldId: 'custrecord_ein_s_msic'
            });
            log.debug("msicID", msic.split('-')[0]);
            log.debug("msicNAME", msic.split('-')[1]);
            var bankName = companyInfo.getValue({
                fieldId: 'custrecord_ein_s_bankname'
            });
            log.debug("bankName", bankName);
            var bankAN = companyInfo.getValue({
                fieldId: 'custrecord_ein_s_bankaccno'
            });
            log.debug("bankAN", bankAN);

            var configShippAddress = companyInfo.getSubrecord({
                fieldId: 'shippingaddress'
            });

            return {
                registor_name: companyInfo.getValue("legalname"),
                tin_reg_no: tin,
                type_of_reg: regType,
                reg_no: regID,
                sst_reg_no: sstID,
                toursim_tax_reg_no: ttrnID,
                email_id: companyInfo.getValue("email"),
                msic: msic,
                addressee: configShippAddress.getValue("addressee"),
                addr1: configShippAddress.getValue("addr1"),
                addr2: configShippAddress.getValue("addr2"),
                zip: configShippAddress.getValue("zip"),
                city: configShippAddress.getValue("city"),
                state: configShippAddress.getValue("state"),
                country: configShippAddress.getText("country"),
                phone: companyInfo.getValue("fax"),
                pri_bank_acc_no: bankAN
            }
        }

    }

    const getDepositDetails = (invid) => {
        return search.create({
            type: "depositapplication",
            filters: [
                ["type", "anyof", "DepAppl"],
                "AND",
                ["mainline", "is", "F"],
                "AND",
                ["appliedtotransaction.internalid", "anyof", invid]
            ],
            columns: [
                search.createColumn({
                    name: "datecreated",
                    label: "Deposit Date"
                }),
                search.createColumn({
                    name: "createdfrom",
                    label: "Deposit Reference No."
                }),
                search.createColumn({
                    name: "fxamount",
                    label: "Amount"
                }),
                "currency"
            ]
        });
    }

    const getStateCode = (statename) => {
        let stateCodeSearch = search.create({
            type: "customrecord_einv_r_statecode",
            filters: [
                ["custrecord_einv_r_statename", "is", statename]
            ],
            columns: [
                search.createColumn({
                    name: "name",
                    label: "Name"
                })
            ]
        }).run().getRange(0, 1);

        return stateCodeSearch.length > 0 ? stateCodeSearch[0].getValue("name").split("-")[0] : '17';
    }

    const getCountryCode = (countryname) => {
        let countryCodeSearch = search.create({
            type: "customrecord_einv_r_countrycode",
            filters: [
                ["custrecord_einv_r_countryname", "is", countryname]
            ],
            columns: [
                search.createColumn({
                    name: "name",
                    label: "Name"
                })
            ]
        }).run().getRange(0, 1);
        return countryCodeSearch.length > 0 ? countryCodeSearch[0].getValue("name") : '';
    }

    const getVendorDeposit = (vbid) => {
        return search.create({
            type: "vendorprepaymentapplication",
            filters:
            [
               ["type","anyof","VPrepApp"], 
               "AND", 
               ["mainline","is","F"], 
               "AND", 
               ["appliedtotransaction.internalid","anyof",vbid]
            ],
            columns:
            [
               search.createColumn({name: "trandate", label: "Payment Date"}),
               search.createColumn({name: "createdfrom", label: "Deposit Ref no."}),
               search.createColumn({name: "paymentmethod", label: "Payment Method"}),
               search.createColumn({name: "fxamount", label: "Amount"}),
               search.createColumn({name: "postingperiod", label: "Period"}),
               search.createColumn({
                  name: "type",
                  join: "appliedToTransaction",
                  label: "Type"
               }),
               search.createColumn({name: "appliedtotransaction", label: "Document no."}),
               search.createColumn({name: "tranid", label: "Application no."}),
               search.createColumn({name: "entity", label: "Name"}),
               search.createColumn({name: "location", label: "Location"}),
               search.createColumn({name: "currency", label: "Currency"})
            ]
         })
    }

    return {
        getCustomerDetails: getCustomerDetails,
        getSupplierDetails: getSupplierDetails,
        getCountryCode: getCountryCode,
        getStateCode: getStateCode,
        getDepositDetails: getDepositDetails,
        getVendorDeposit: getVendorDeposit
    }

});