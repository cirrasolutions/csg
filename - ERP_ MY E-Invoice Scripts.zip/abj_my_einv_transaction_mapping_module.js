/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
 define([
    'N/runtime',
    'N/search',
    './abj_my_einv_module.js', 
    './moment.js', 
    './abj_my_einv_ns_methods.js',
    './abj_einv_json_validator.js'
], function(runtime, search, _EINV_MOD_, moment, _NS_MOD_, _EINV_JSONVALIDATOR_MOD_) {
    /**
    * it will map the Invoice data to json object
    */
    const mapJSONWithINVData = (currRec, jsonObj, tranTypeCode, currentSubId) =>{
        let configSetupSearch = search.create({
            type: 'customrecord_my_einv_con_setup',
            columns: [
                'internalid',
                'custrecord_my_e_inv_clientid',
                'custrecord_my_e_inv_client_secret',
                'custrecord_my_e_inv_client_secret2',
                'custrecord_my_e_invoice_base_url',
                'custrecord_my_e_invoice_subsidiary',
                'custrecord_my_e_inv_tin',
                'custrecord_my_e_inv_brn',
                'custrecord_my_e_inv_tin_autoappreinv'
            ],
            filters: [
                ['custrecord_my_e_invoice_subsidiary','anyof', currentSubId] 
            ]
        }).run().getRange(0, 10);
        let datecreated = moment(new Date()).toISOString();
        log.debug("datecreated",datecreated);

        //Scriptable search to fetch all the supplier details
        var multiSubFeature = runtime.isFeatureInEffect({feature:"subsidiaries"});
        var applicableSubId = multiSubFeature ? configSetupSearch[0].getValue('custrecord_my_e_invoice_subsidiary') : 1;
        var suppDetailsObj = _NS_MOD_.getSupplierDetails(applicableSubId, multiSubFeature);
        log.debug("suppDetailsObj",suppDetailsObj);

        //Scriptable search to fetch all the customer details
        let isPerson = search.lookupFields({
            type: search.Type.CUSTOMER,
            id: currRec.getValue("entity"),
            columns: ["isperson"]
        })['isperson'];
        var customerDetails = _NS_MOD_.getCustomerDetails(currRec, search.Type.CUSTOMER, isPerson);
        
        //Saved search for pre-payment or deposits
        let dep_index = 0;
        jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["currencyID"] = currRec.getText("currency");
        _NS_MOD_.getDepositDetails(currRec.id).run().each(depr=>{
            let isoDepDateTime = moment(depr.getValue("datecreated")).toISOString().split("T");
            if(dep_index == 0){
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["ID"][0]["_"] = depr.getValue({name:"createdfrom"}) //deposit reference
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["_"] = parseFloat(depr.getValue({name:"fxamount"})) //deposit amount 
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["currencyID"] = depr.getText({name:"currency"}) || currRec.getText("currency");
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidDate"][0]["_"] = isoDepDateTime[0]//date
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidTime"][0]["_"] = isoDepDateTime[1]//paid time
            }else{
                jsonObj["Invoice"][0]["PrepaidPayment"].push({
                    "ID":[{
                        "_": depr.getValue({name:"createdfrom"}) //deposit reference
                    }],
                    "PaidAmount":[{
                        "_": parseFloat(depr.getValue({name:"fxamount"})) //deposit amount 
                    }],
                   "PaidAmount":[{
                        "currencyID": depr.getText({name:"currency"}) || currRec.getText("currency")
                   }],
                   "PaidDate":[{
                        "_": isoDepDateTime[0]//date
                   }],
                   "PaidTime":[{
                        "_": isoDepDateTime[1]//paid time
                   }]
                });
            }
        });

        var custShippingAddress = currRec.getSubrecord({
            fieldId: 'shippingaddress'
        });

        //JSON Object creator as per JSON file sequence
        jsonObj["Invoice"][0]["ID"][0]["_"] = currRec.getValue("tranid");
        jsonObj["Invoice"][0]["IssueDate"][0]["_"] = datecreated.split("T")[0];
        jsonObj["Invoice"][0]["IssueTime"][0]["_"] = datecreated.split("T")[1].split(".")[0]+'Z';
        jsonObj["Invoice"][0]["InvoiceTypeCode"][0]["_"] = tranTypeCode;
        // jsonObj["Invoice"][0]["InvoiceTypeCode"][0]["listVersionID"] = "1.1";
        jsonObj["Invoice"][0]["DocumentCurrencyCode"][0]["_"] = currRec.getValue("currencyname");
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["StartDate"][0]["_"] = currRec.getValue("startdate") ? moment(currRec.getValue("startdate")).format("YYYY-MM-DD") : "";
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["EndDate"][0]["_"] = currRec.getValue("enddate") ? moment(currRec.getValue("enddate")).format("YYYY-MM-DD") : "";
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["Description"][0]["_"] = currRec.getText("custbody_ein_t_frequencyofbilling");
        jsonObj["Invoice"][0]["BillingReference"][0]["AdditionalDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_billrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][0]["ID"][0]["_"] = "";//currRec.getValue("custbody_t_importedgoodsrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][0]["DocumentType"][0]["_"] = "CustomsImportForm";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_ftanfo") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["DocumentType"][0]["_"] = "FreeTradeAgreement";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["DocumentDescription"][0]["_"] = ""; //currRec.getValue("memo") || "", //need confirmation
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][2]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_exportedgoodsrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][2]["DocumentType"][0]["_"] = "K2";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][3]["ID"][0]["_"] = currRec.getValue("custbody_abj_incoterm") || "";

        jsonObj["Invoice"][0]["BillingReference"][1]["InvoiceDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_invoice_doc_no");
        jsonObj["Invoice"][0]["BillingReference"][1]["InvoiceDocumentReference"][0]["UUID"][0]["_"] = currRec.getValue("custbody_ein_t_invoice_uuid");
        
        //Supplier Data as per field mapping sheet
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = suppDetailsObj.registor_name;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"] = suppDetailsObj.tin_reg_no;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"] = suppDetailsObj.reg_no;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = suppDetailsObj.type_of_reg;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["_"] = "SST";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["schemeID"] = suppDetailsObj.sst_reg_no;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"] = (suppDetailsObj.email_id) ? suppDetailsObj.email_id : "NA";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"] = (suppDetailsObj.phone) ? suppDetailsObj.phone : "NA";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["_"] = (suppDetailsObj.msic).split("-")[0];
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["name"] = (suppDetailsObj.msic).split("-")[1];
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"] = suppDetailsObj.city;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = suppDetailsObj.zip;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = _NS_MOD_.getStateCode(suppDetailsObj.state),
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = suppDetailsObj.addressee;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = suppDetailsObj.addr1;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = suppDetailsObj.addr2;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = _NS_MOD_.getCountryCode(suppDetailsObj.country),
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] =  "ISO3166-1";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["_"] = currRec.getValue('custbody_ein_t_exporterrefno') || "";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["schemeAgencyName"] = "CertEx";

        //Customer Data as per field mapping sheet
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = isPerson ? customerDetails[0].getValue({name: "altname", label: "Buyer's Name"}) : customerDetails[0].getValue({name: "companyname"});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"] = customerDetails[0].getValue({name: "vatregnumber", label: "TIN Reg.no."});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_registrationno", label: "Company Registration no."});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = customerDetails[0].getText({name: "custentity_ein_c_regnotype", label: "Type OF Registration no."});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_sstregistrationno", label: "SST Registration no."});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["schemeID"] = "SST";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"] = (customerDetails[0].getValue({name: "email", label: "E-Mail ID"})) ? (customerDetails[0].getValue({name: "email", label: "E-Mail ID"})) : "NA";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"] = (customerDetails[0].getValue({name: "phone", label: "Contact no."})) ? (customerDetails[0].getValue({name: "phone", label: "Contact no."}).replace(/[^\d.-]/g, "")) : "NA";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_city"});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = customerDetails[0].getValue({name: "zipcode", join: "Address", label: "Zip"});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = (customerDetails[0].getText({name:"custentity_ein_c_state"})).split("-")[0];//_NS_MOD_.getStateCode(currRec.getValue("custbody_ein_t_c_state")),
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = customerDetails[0].getValue({name: "addressee", join: "Address", label: "Address Line 0"});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = customerDetails[0].getValue({name: "address1", join: "Address", label: "Address Line 1"});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = customerDetails[0].getValue({name: "address2", join: "Address", label: "Address Line 2"});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = (customerDetails[0].getText({name:"custentity_ein_c_country"})).split("-")[0];//_NS_MOD_.getCountryCode(currRec.getValue("custbody_ein_t_c_country")),
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] = "ISO3166-1";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";

        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = isPerson ? customerDetails[0].getValue({name: "altname", label: "Buyer's Name"}) : customerDetails[0].getValue({name: "companyname"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["_"] = customerDetails[0].getValue({name: "vatregnumber", label: "TIN Reg.no."});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_registrationno"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = "BRN";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CityName"][0]["_"] = currRec.getValue("custbody_ein_t_c_city");//custShippingAddress.getValue({fieldId: "city"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = "";//custShippingAddress.getValue({fieldId: "zip"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = currRec.getText({fieldId:"custbody_ein_t_c_state"}).split("-")[0];//_NS_MOD_.getStateCode(custShippingAddress.getValue({fieldId:"state"}));
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = custShippingAddress.getValue({fieldId: "addressee"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = custShippingAddress.getValue({fieldId: "addr1"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = custShippingAddress.getValue({fieldId: "addr2"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = currRec.getText({fieldId:"custbody_ein_t_c_country"});//_NS_MOD_.getCountryCode(custShippingAddress.getText({fieldId:"country"}));
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] = "ISO3166-1";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";
        //// jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["ChargeIndicator"][0]["_"] = ""; //yet to map
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = "TEST FRIEGHT"; //yet to map
        
        jsonObj["Invoice"][0]["PaymentMeans"][0]["PaymentMeansCode"][0]["_"] = currRec.getText('custbody_ein_t_paymentmode').split("-")[0];
        jsonObj["Invoice"][0]["PaymentMeans"][0]["PayeeFinancialAccount"][0]["ID"][0]["_"] = suppDetailsObj.pri_bank_acc_no;

        jsonObj["Invoice"][0]["PaymentTerms"][0]["Note"][0]["_"] = currRec.getText('terms');

        jsonObj["Invoice"][0]["AllowanceCharge"][0]["ChargeIndicator"][0]["_"] = false;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = "TEST";  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["_"] = 0;//yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["ChargeIndicator"][0]["_"] = true;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["AllowanceChargeReason"][0]["_"] = "TEST"  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["_"] = 0;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["currencyID"] = currRec.getText("currency");  //yet to map

        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxAmount"][0]["_"] = currRec.getValue('taxtotal');
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxableAmount"][0]["_"] = currRec.getValue('taxtotal') ? (currRec.getValue('subtotal') || 0) : 0;
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxableAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxAmount"][0]["_"] = parseFloat(currRec.getValue('taxtotal') || 0);
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["ID"][0]["_"] = (currRec.getText('custbody_ein_t_taxtype')).split("-")[0];
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["_"] = "OTH"
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["schemeID"] = "UN/ECE 5153";
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["schemeAgencyID"] = "6"

        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["LineExtensionAmount"][0]["_"] = currRec.getValue('total');
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["LineExtensionAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["_"] = currRec.getValue("subtotal") //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["_"] = currRec.getValue("total"); //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["_"] = parseFloat(currRec.getValue('discounttotal') || 0);
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableRoundingAmount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableRoundingAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["_"] = currRec.getValue("total"); //this is total amount - prepaid amount
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["currencyID"] = currRec.getText("currency");

        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["SourceCurrencyCode"][0]["_"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["TargetCurrencyCode"][0]["_"] = "MYR";
        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["CalculationRate"][0]["_"] = parseFloat(currRec.getValue("exchangerate") || 0);      

        let itemCount = currRec.getLineCount('item');

        var jsonBodyValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceBody(jsonObj);
        var jsonLineValidatorError = '';

        for(let i=0; i < itemCount; i++){
            let itemType = currRec.getSublistValue("item","itemtype",i);
            let otherorfee = currRec.getSublistValue("item","custcol_ein_t_fee_charge_rate_yes_no",i);
            if(itemType == "Description")continue;
            if(itemType == "Discount"){
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["ChargeIndicator"][0]["_"] = false; //yet to map
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = currRec.getSublistValue('item','description',i); //yet to map
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["MultiplierFactorNumeric"][0]["_"] = parseFloat(currRec.getSublistValue('item', 'rate', i) || 0);
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["Amount"][0]["_"] = parseFloat(currRec.getSublistValue('item', 'amount', i) || 0);
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");
                jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["_"] += parseFloat(parseFloat(currRec.getSublistValue('item', 'amount', i) || 0));
                continue;
            };
            if(otherorfee){
                jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));//yet to map
                jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));
                jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));
                continue;
            }
            //INVOICE LINE DATA
            jsonObj["Invoice"][0]["InvoiceLine"].push({
                "ID": [{
                    "_": currRec.getSublistValue("item","item_display",i)
                }],
                "InvoicedQuantity": [{
                    "_": currRec.getSublistValue('item', 'quantity', i) || 0,
                    "unitCode": currRec.getSublistValue('item', 'unit', i) || ""
                }],
                "LineExtensionAmount": [{
                    "_": parseFloat(currRec.getSublistValue("item","amount",i) || 0),
                    "currencyID": currRec.getText("currency")
                }],
                "AllowanceCharge": [{
                        "ChargeIndicator": [{
                            "_": false
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0
                        }],
                        "Amount": [{
                            "_": 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    },
                    {
                        "ChargeIndicator": [{
                            "_": true
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0 //yet to map
                        }],
                        "Amount": [{
                            "_": 0,//currRec.getSublistValue('item', 'discountamount', i) || 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    }
                ],
                "TaxTotal": [{
                    "TaxAmount": [{
                        "_": parseFloat(currRec.getSublistValue('item', 'tax1amt', i) || 0),
                        "currencyID": currRec.getText("currency")
                    }],
                    "TaxSubtotal": [{
                        "TaxableAmount": [{
                            "_": parseFloat(currRec.getSublistValue('item','amount',i) || 0), //yet to map
                            "currencyID": currRec.getText("currency")
                        }],
                        "TaxAmount": [{
                            "_": parseFloat(currRec.getSublistValue('item', 'tax1amt', i) || 0),
                            "currencyID": currRec.getText("currency")
                        }],
                        "Percent": [{
                            "_": parseFloat(currRec.getSublistValue('item','taxrate1',i) || 0) //yet to map
                        }],
                        "TaxCategory": [{
                            "ID": [{
                                "_": currRec.getSublistValue('item','custcol_ein_t_taxtype',i) ? (currRec.getSublistText('item', 'custcol_ein_t_taxtype', i)).split("-")[0] : ""
                            }],
                            "Percent": [{
                                "_": parseFloat(currRec.getSublistValue('item','taxrate1',i) || 0) // yet to map
                            }],
                            "TaxScheme": [{
                                "ID": [{
                                    "_": "OTH",
                                    "schemeID": "UN/ECE 5153",
                                    "schemeAgencyID": "6"
                                }]
                            }],
                            "TaxExemptionReason": [{
                                "_": currRec.getSublistValue('item','taxrate1',i) ? "NA" : currRec.getSublistValue("item","custcol_ein_t_taxexemptionreason",i)
                            }]
                        }]
                    }]
                }],
                "Item": [{
                    "CommodityClassification": [{
                            "ItemClassificationCode": [{
                                "_": currRec.getSublistText('item', 'custcol_ein_t_prodtariffcode', i) || "",
                                "listID": "PTC"
                            }]
                        },
                        {
                            "ItemClassificationCode": [{
                                "_": (currRec.getSublistText('item', 'custcol_ein_t_classification', i)).split('-')[0],
                                "listID": "CLASS"
                            }]
                        }
                    ],
                    "Description": [{
                        "_": currRec.getSublistValue('item', 'description', i) || ""
                    }],
                    "OriginCountry": [{
                        "IdentificationCode": [{
                            "_": currRec.getSublistText('item', 'custcol_ein_t_countryoforigin', i) || ""
                        }]
                    }]
                }],
                "Price": [{
                    "PriceAmount": [{
                        "_": parseFloat(currRec.getSublistValue('item', 'rate', i) || 0),
                        "currencyID": currRec.getText("currency")
                    }]
                }],
                "ItemPriceExtension": [{
                    "Amount": [{
                        "_": parseFloat(currRec.getSublistValue('item', 'amount', i) || 0),
                        "currencyID": currRec.getText("currency")
                    }]
                }]
            });
                
            let lineValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceLine(jsonObj["Invoice"][0]["InvoiceLine"][jsonObj["Invoice"][0]["InvoiceLine"].length-1]);
            jsonLineValidatorError += lineValidatorError ? `\nitem line ${i+1} :` + "\n" + Object.keys(lineValidatorError).map(key=>lineValidatorError[key]).join("\n") : '';
        }

        return {
            jsondata : jsonObj,
            jsonBodyValid: jsonBodyValidatorError ? Object.keys(jsonBodyValidatorError).map(key=>jsonBodyValidatorError[key]).join("\n") : '',
            jsonLineValid: jsonLineValidatorError
        };
    }

    /**
     * it will map the Vendor Bill data to json object
     */
    const mapJSONWithVBData = (currRec, jsonObj, tranTypeCode, currentSubId) =>{
        let configSetupSearch = search.create({
            type: 'customrecord_my_einv_con_setup',
            columns: [
                'internalid',
                'custrecord_my_e_inv_clientid',
                'custrecord_my_e_inv_client_secret',
                'custrecord_my_e_inv_client_secret2',
                'custrecord_my_e_invoice_base_url',
                'custrecord_my_e_invoice_subsidiary',
                'custrecord_my_e_inv_tin',
                'custrecord_my_e_inv_brn',
                'custrecord_my_e_inv_tin_autoappreinv'
            ],
            filters: [
                ['custrecord_my_e_invoice_subsidiary','anyof', currentSubId]
            ]
        }).run().getRange(0, 10);
        let datecreated = moment(new Date()).toISOString();
        log.debug("datecreated",datecreated);

        //Scriptable search to fetch all the supplier details
        var multiSubFeature = runtime.isFeatureInEffect({feature:"subsidiaries"});
        var applicableSubId = multiSubFeature ? configSetupSearch[0].getValue('custrecord_my_e_invoice_subsidiary') : 1;
        var suppDetailsObj = _NS_MOD_.getSupplierDetails(applicableSubId, multiSubFeature);
        log.debug("suppDetailsObj",suppDetailsObj);

        //Scriptable search to fetch all the customer details
        let isPerson = search.lookupFields({
            type: search.Type.VENDOR,
            id: currRec.getValue("entity"),
            columns: ["isperson"]
        })['isperson'];
        var customerDetails = _NS_MOD_.getCustomerDetails(currRec, search.Type.VENDOR, isPerson);
        
        //Saved search for pre-payment or deposits
        let dep_index = 0;
        jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["currencyID"] = currRec.getText("currency");
        _NS_MOD_.getDepositDetails(currRec.id).run().each(depr=>{
            let isoDepDateTime = moment(depr.getValue("datecreated")).toISOString().split("T");
            if(dep_index == 0){
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["ID"][0]["_"] = depr.getValue({name:"createdfrom"}) //deposit reference
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["_"] = parseFloat(depr.getValue({name:"fxamount"})) //deposit amount 
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["currencyID"] = depr.getText({name:"currency"}) || currRec.getText("currency");
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidDate"][0]["_"] = isoDepDateTime[0]//date
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidTime"][0]["_"] = isoDepDateTime[1]//paid time
            }else{
                jsonObj["Invoice"][0]["PrepaidPayment"].push({
                    "ID":[{
                        "_": depr.getValue({name:"createdfrom"}) //deposit reference
                    }],
                    "PaidAmount":[{
                        "_": parseFloat(depr.getValue({name:"fxamount"})) //deposit amount 
                    }],
                   "PaidAmount":[{
                        "currencyID": depr.getText({name:"currency"}) || currRec.getText("currency")
                   }],
                   "PaidDate":[{
                        "_": isoDepDateTime[0]//date
                   }],
                   "PaidTime":[{
                        "_": isoDepDateTime[1]//paid time
                   }]
                });
            }
        });

        //JSON Object creator as per JSON file sequence
        jsonObj["Invoice"][0]["ID"][0]["_"] = currRec.getValue("transactionnumber");
        jsonObj["Invoice"][0]["IssueDate"][0]["_"] = datecreated.split("T")[0];
        jsonObj["Invoice"][0]["IssueTime"][0]["_"] = datecreated.split("T")[1].split(".")[0]+'Z';
        jsonObj["Invoice"][0]["InvoiceTypeCode"][0]["_"] = tranTypeCode;
        // jsonObj["Invoice"][0]["InvoiceTypeCode"][0]["listVersionID"] = "1.1";
        jsonObj["Invoice"][0]["DocumentCurrencyCode"][0]["_"] = currRec.getValue("currencyname");
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["StartDate"][0]["_"] = currRec.getValue("custbody_ein_t_billingstartdate") ? moment(currRec.getValue("custbody_ein_t_billingstartdate")).format("YYYY-MM-DD") : "";
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["EndDate"][0]["_"] = currRec.getValue("custbody_ein_t_billingenddate") ? moment(currRec.getValue("custbody_ein_t_billingenddate")).format("YYYY-MM-DD") : "";
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["Description"][0]["_"] = currRec.getText("custbody_ein_t_frequencyofbilling");
        jsonObj["Invoice"][0]["BillingReference"][0]["AdditionalDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_billrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_t_importedgoodsrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][0]["DocumentType"][0]["_"] = "CustomsImportForm";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_ftanfo") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["DocumentType"][0]["_"] = "FreeTradeAgreement";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["DocumentDescription"][0]["_"] = ""; //currRec.getValue("memo") || "", //need confirmation
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][2]["ID"][0]["_"] = "";//currRec.getValue("custbody_ein_t_exportedgoodsrefno");
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][2]["DocumentType"][0]["_"] = "K2";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][3]["ID"][0]["_"] = currRec.getText("incoterm") || "";

        log.audit("invoice document detailes","mapped");

        jsonObj["Invoice"][0]["BillingReference"][1]["InvoiceDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_invoice_doc_no");
        jsonObj["Invoice"][0]["BillingReference"][1]["InvoiceDocumentReference"][0]["UUID"][0]["_"] = currRec.getValue("custbody_ein_t_invoice_uuid");

        //supplier Data as per field mapping sheet
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = isPerson ? customerDetails[0].getValue({name: "altname", label: "Buyer's Name"}) : customerDetails[0].getValue({name: "companyname"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"] = customerDetails[0].getValue({name: "vatregnumber", label: "TIN Reg.no."});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_registrationno", label: "Company Registration no."});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = customerDetails[0].getText({name: "custentity_ein_c_regnotype", label: "Type OF Registration no."});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"] = (customerDetails[0].getValue({name: "email", label: "E-Mail ID"})) ? (customerDetails[0].getValue({name: "email", label: "E-Mail ID"})) : "NA";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"] = (customerDetails[0].getValue({name: "phone", label: "Contact no."})) ? (customerDetails[0].getValue({name: "phone", label: "Contact no."}).replace(/[^\d.-]/g, "")) : "NA";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["_"] = (customerDetails[0].getText("custentity_ein_c_msic")).split("-")[0];
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["name"] = (customerDetails[0].getText("custentity_ein_c_msic")).split("-")[1];
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_city"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = customerDetails[0].getValue({name: "zipcode", join: "Address", label: "Zip"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = (customerDetails[0].getText({name:"custentity_ein_c_state"})).split("-")[0];//_NS_MOD_.getStateCode(currRec.getValue("custbody_ein_t_c_state")),
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = customerDetails[0].getValue({name: "addressee", join: "Address", label: "Address Line 0"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = customerDetails[0].getValue({name: "address1", join: "Address", label: "Address Line 1"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = customerDetails[0].getValue({name: "address2", join: "Address", label: "Address Line 2"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = (customerDetails[0].getText({name:"custentity_ein_c_country"})).split("-")[0];//_NS_MOD_.getCountryCode(currRec.getValue("custbody_ein_t_c_country")),
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] = "ISO3166-1";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["_"] = currRec.getValue('custbody_ein_t_exporterrefno') || "";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["schemeAgencyName"] = "CertEx";

        log.audit("invoice supplier detailes","mapped");

        //customer Data as per field mapping sheet
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = suppDetailsObj.registor_name;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"] = suppDetailsObj.tin_reg_no;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"] = suppDetailsObj.reg_no;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = suppDetailsObj.type_of_reg;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["_"] = suppDetailsObj.sst_reg_no;//yet to map
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["schemeID"] = "SST";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"] = (suppDetailsObj.email_id) ? suppDetailsObj.email_id : "NA";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"] = (suppDetailsObj.phone) ? suppDetailsObj.phone : "NA";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"] = suppDetailsObj.city;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = suppDetailsObj.zip;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = _NS_MOD_.getStateCode(suppDetailsObj.state),
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = suppDetailsObj.addressee;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = suppDetailsObj.addr1;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = suppDetailsObj.addr2;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = _NS_MOD_.getCountryCode(suppDetailsObj.country),
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] =  "ISO3166-1";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";

        log.audit("invoice customer detailes","mapped");

        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = suppDetailsObj.registor_name;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["_"] = suppDetailsObj.tin_reg_no;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["_"] = suppDetailsObj.reg_no;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = "BRN";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CityName"][0]["_"] = suppDetailsObj.city;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = suppDetailsObj.zip;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = _NS_MOD_.getStateCode(suppDetailsObj.state);
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = suppDetailsObj.addressee;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = suppDetailsObj.addr1;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = suppDetailsObj.addr2;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = _NS_MOD_.getCountryCode(suppDetailsObj.country);
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] = "ISO3166-1";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";
        //// jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["ChargeIndicator"][0]["_"] = ""; //yet to map
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = "TEST FRIEGHT"; //yet to map

        log.audit("invoice delivery detailes","mapped");

        jsonObj["Invoice"][0]["PaymentMeans"][0]["PaymentMeansCode"][0]["_"] = currRec.getText('custbody_ein_t_paymentmode').split("-")[0];
        jsonObj["Invoice"][0]["PaymentMeans"][0]["PayeeFinancialAccount"][0]["ID"][0]["_"] = suppDetailsObj.pri_bank_acc_no;

        jsonObj["Invoice"][0]["PaymentTerms"][0]["Note"][0]["_"] = currRec.getText('terms');

        jsonObj["Invoice"][0]["AllowanceCharge"][0]["ChargeIndicator"][0]["_"] = false;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = "TEST";  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["ChargeIndicator"][0]["_"] = true;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["AllowanceChargeReason"][0]["_"] = "TEST"  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["_"] = 0;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["currencyID"] = currRec.getText("currency");  //yet to map

        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxAmount"][0]["_"] = currRec.getValue('taxtotal');
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxableAmount"][0]["_"] = currRec.getValue('taxtotal') ? (currRec.getValue('grosstotal') || 0) : 0;
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxableAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxAmount"][0]["_"] = parseFloat(currRec.getValue('taxtotal') || 0);
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["ID"][0]["_"] = (currRec.getText('custbody_ein_t_taxtype')).split("-")[0];
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["_"] = "OTH"
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["schemeID"] = "UN/ECE 5153";
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["schemeAgencyID"] = "6"

        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["LineExtensionAmount"][0]["_"] = currRec.getValue('total');
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["LineExtensionAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["_"] = currRec.getValue("grosstotal") //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["_"] = currRec.getValue("total"); //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["_"] = 0;//currRec.getValue('discounttotal');
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableRoundingAmount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableRoundingAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["_"] = parseFloat(currRec.getValue("usertotal")); //this is total amount - prepaid amount
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["currencyID"] = currRec.getText("currency");

        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["SourceCurrencyCode"][0]["_"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["TargetCurrencyCode"][0]["_"] = "MYR";
        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["CalculationRate"][0]["_"] = parseFloat(currRec.getValue("exchangerate") || 0);

        let itemCount = currRec.getLineCount('item');

        var jsonBodyValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceBody(jsonObj);
        var jsonLineValidatorError = '';

        //adding the item lines
        for(let i=0; i < itemCount; i++){
            let itemType = currRec.getSublistValue("item","itemtype",i);
            let otherorfee = currRec.getSublistValue("item","custcol_ein_t_fee_charge_rate_yes_no",i);
            if(itemType == "Description")continue;
            if(itemType == "Discount"){
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["ChargeIndicator"][0]["_"] = false; //yet to map
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = currRec.getSublistValue('item','description',i); //yet to map
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["MultiplierFactorNumeric"][0]["_"] = parseFloat(currRec.getSublistValue('item', 'rate', i) || 0);
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["Amount"][0]["_"] = parseFloat(currRec.getSublistValue('item', 'amount', i) || 0);
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");
                jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["_"] += parseFloat(parseFloat(currRec.getSublistValue('item', 'amount', i) || 0));
                continue;
            };
            if(otherorfee){
                jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));//yet to map
                jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));
                jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));
                continue;
            }
            //INVOICE LINE DATA
            jsonObj["Invoice"][0]["InvoiceLine"].push({
                "ID": [{
                    "_": currRec.getSublistValue("item","item_display",i)
                }],
                "InvoicedQuantity": [{
                    "_": currRec.getSublistValue('item', 'quantity', i) || 0,
                    "unitCode": currRec.getSublistValue('item', 'unit', i) || ""
                }],
                "LineExtensionAmount": [{
                    "_": parseFloat(currRec.getSublistValue("item","amount",i) || 0),
                    "currencyID": currRec.getText("currency")
                }],
                "AllowanceCharge": [{
                        "ChargeIndicator": [{
                            "_": false
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0
                        }],
                        "Amount": [{
                            "_": 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    },
                    {
                        "ChargeIndicator": [{
                            "_": true
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0 //yet to map
                        }],
                        "Amount": [{
                            "_": 0,//currRec.getSublistValue('item', 'discountamount', i) || 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    }
                ],
                "TaxTotal": [{
                    "TaxAmount": [{
                        "_": currRec.getSublistValue('item','taxrate1',i) ? (parseFloat(currRec.getSublistValue('item', 'tax1amt', i) || 0)) : 0,
                        "currencyID": currRec.getText("currency")
                    }],
                    "TaxSubtotal": [{
                        "TaxableAmount": [{
                            "_": parseFloat(currRec.getSublistValue('item','amount',i) || 0), //yet to map
                            "currencyID": currRec.getText("currency")
                        }],
                        "TaxAmount": [{
                            "_": parseFloat(currRec.getSublistValue('item', 'tax1amt', i) || 0),
                            "currencyID": currRec.getText("currency")
                        }],
                        "Percent": [{
                            "_": parseFloat(currRec.getSublistValue('item','taxrate1',i) || 0) //yet to map
                        }],
                        "TaxCategory": [{
                            "ID": [{
                                "_": currRec.getSublistValue('item','custcol_ein_t_taxtype',i) ? (currRec.getSublistText('item', 'custcol_ein_t_taxtype', i)).split("-")[0] : ""
                            }],
                            "Percent": [{
                                "_": parseFloat(currRec.getSublistValue('item','taxrate1',i) || 0) // yet to map
                            }],
                            "TaxScheme": [{
                                "ID": [{
                                    "_": "OTH",
                                    "schemeID": "UN/ECE 5153",
                                    "schemeAgencyID": "6"
                                }]
                            }],
                            "TaxExemptionReason": [{
                                "_": currRec.getSublistValue('item','taxrate1',i) ? "NA" : currRec.getSublistValue("item","custcol_ein_t_taxexemptionreason",i) //yet to map
                            }]
                        }]
                    }]
                }],
                "Item": [{
                    "CommodityClassification": [{
                            "ItemClassificationCode": [{
                                "_": currRec.getSublistText('item', 'custcol_ein_t_prodtariffcode', i) || "",
                                "listID": "PTC"
                            }]
                        },
                        {
                            "ItemClassificationCode": [{
                                "_": (currRec.getSublistText('item', 'custcol_ein_t_classification', i)).split('-')[0],
                                "listID": "CLASS"
                            }]
                        }
                    ],
                    "Description": [{
                        "_": currRec.getSublistValue('item', 'description', i) || ""
                    }],
                    "OriginCountry": [{
                        "IdentificationCode": [{
                            "_": currRec.getSublistText('item', 'custcol_ein_t_countryoforigin', i) || ""
                        }]
                    }]
                }],
                "Price": [{
                    "PriceAmount": [{
                        "_": parseFloat(currRec.getSublistValue('item', 'rate', i) || 0),
                        "currencyID": currRec.getText("currency")
                    }]
                }],
                "ItemPriceExtension": [{
                    "Amount": [{
                        "_": parseFloat(currRec.getSublistValue('item', 'amount', i) || 0),
                        "currencyID": currRec.getText("currency")
                    }]
                }]
            });

            let lineValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceLine(jsonObj["Invoice"][0]["InvoiceLine"][jsonObj["Invoice"][0]["InvoiceLine"].length-1]);
            jsonLineValidatorError += lineValidatorError ? `\nitem line ${i+1} :` + "\n" + Object.keys(lineValidatorError).map(key=>lineValidatorError[key]).join("\n") : '';
        }

        //expense lines adding into the invoice lines
        let expenseLineCount = currRec.getLineCount("expense");
        let invoiceLineCountStart = jsonObj["Invoice"][0]["InvoiceLine"].length;
        for(let i = 0; i < expenseLineCount; i++,invoiceLineCountStart++){
            jsonObj["Invoice"][0]["InvoiceLine"].push({
                "ID": [{
                    "_": currRec.getSublistText("expense","category",i)
                }],
                "InvoicedQuantity": [{
                    "_": 1,
                    "unitCode": ""//yet to map
                }],
                "LineExtensionAmount": [{
                    "_": currRec.getSublistValue("expense","amount",i) || 0,
                    "currencyID": currRec.getText("currency")
                }],
                "AllowanceCharge": [{
                        "ChargeIndicator": [{
                            "_": false
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0
                        }],
                        "Amount": [{
                            "_": 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    },
                    {
                        "ChargeIndicator": [{
                            "_": true
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0 //yet to map
                        }],
                        "Amount": [{
                            "_": 0,//currRec.getSublistValue('item', 'discountamount', i) || 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    }
                ],
                "TaxTotal": [{
                    "TaxAmount": [{
                        "_": currRec.getSublistValue('expense','taxrate1',i) ? (currRec.getSublistValue('expense', 'tax1amt', i) || 0) : 0,
                        "currencyID": currRec.getText("currency")
                    }],
                    "TaxSubtotal": [{
                        "TaxableAmount": [{
                            "_": currRec.getSublistValue('expense','amount',i) || 0, //yet to map
                            "currencyID": currRec.getText("currency")
                        }],
                        "TaxAmount": [{
                            "_": currRec.getSublistValue('expense', 'tax1amt', i) || 0,
                            "currencyID": currRec.getText("currency")
                        }],
                        "Percent": [{
                            "_": parseFloat(currRec.getSublistValue('expense','taxrate1',i) || 0) //yet to map
                        }],
                        "TaxCategory": [{
                            "ID": [{
                                "_": currRec.getSublistValue('expense','custcol_ein_t_taxtype',i) ? (currRec.getSublistText('expense', 'custcol_ein_t_taxtype', i)).split("-")[0] : ""
                            }],
                            "Percent": [{
                                "_": parseFloat(currRec.getSublistValue('expense','taxrate1',i) || 0) // yet to map
                            }],
                            "TaxScheme": [{
                                "ID": [{
                                    "_": "OTH",
                                    "schemeID": "UN/ECE 5153",
                                    "schemeAgencyID": "6"
                                }]
                            }],
                            "TaxExemptionReason": [{
                                "_": currRec.getSublistValue('expense','taxrate1',i) ? "NA" : currRec.getSublistValue("expense","custcol_ein_t_taxexemptionreason",i) //yet to map
                            }]
                        }]
                    }]
                }],
                "Item": [{
                    "CommodityClassification": [{
                            "ItemClassificationCode": [{
                                "_": currRec.getSublistText('expense', 'custcol_ein_t_prodtariffcode', i) || "",
                                "listID": "PTC"
                            }]
                        },
                        {
                            "ItemClassificationCode": [{
                                "_": (currRec.getSublistText('expense', 'custcol_ein_t_classification', i)).split('-')[0],
                                "listID": "CLASS"
                            }]
                        }
                    ],
                    "Description": [{
                        "_": currRec.getSublistValue('expense', 'memo', i) || ""
                    }],
                    "OriginCountry": [{
                        "IdentificationCode": [{
                            "_": currRec.getSublistText('expense', 'custcol_ein_t_countryoforigin', i) || ""
                        }]
                    }]
                }],
                "Price": [{
                    "PriceAmount": [{
                        "_": currRec.getSublistValue('expense', 'amount', i) || 0,
                        "currencyID": currRec.getText("currency")
                    }]
                }],
                "ItemPriceExtension": [{
                    "Amount": [{
                        "_": currRec.getSublistValue('expense', 'amount', i) || 0,
                        "currencyID": currRec.getText("currency")
                    }]
                }]
            });

            let lineValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceLine(jsonObj["Invoice"][0]["InvoiceLine"][invoiceLineCountStart]);
            jsonLineValidatorError += lineValidatorError ? `\nexpense line ${i+1} :` + "\n" + Object.keys(lineValidatorError).map(key=>lineValidatorError[key]).join("\n") : '';
        }


        return {
            jsondata : jsonObj,
            jsonBodyValid: jsonBodyValidatorError ? Object.keys(jsonBodyValidatorError).map(key=>jsonBodyValidatorError[key]).join("\n") : '',
            jsonLineValid: jsonLineValidatorError
        };
    }



    /**
     * it will map the Expense data to json object
     */
    const mapJSONWithEXPData = (currRec, jsonObj, tranTypeCode, currentSubId) =>{
        let configSetupSearch = search.create({
            type: 'customrecord_my_einv_con_setup',
            columns: [
                'internalid',
                'custrecord_my_e_inv_clientid',
                'custrecord_my_e_inv_client_secret',
                'custrecord_my_e_inv_client_secret2',
                'custrecord_my_e_invoice_base_url',
                'custrecord_my_e_invoice_subsidiary',
                'custrecord_my_e_inv_tin',
                'custrecord_my_e_inv_brn',
                'custrecord_my_e_inv_tin_autoappreinv'
            ],
            filters: [
                ['custrecord_my_e_invoice_subsidiary','anyof', currentSubId]
            ]
        }).run().getRange(0, 10);
        let datecreated = moment(new Date()).toISOString();
        log.debug("datecreated",datecreated);

        //Scriptable search to fetch all the supplier details
        var multiSubFeature = runtime.isFeatureInEffect({feature:"subsidiaries"});
        var applicableSubId = multiSubFeature ? configSetupSearch[0].getValue('custrecord_my_e_invoice_subsidiary') : 1;
        var suppDetailsObj = _NS_MOD_.getSupplierDetails(applicableSubId, multiSubFeature);
        log.debug("suppDetailsObj",suppDetailsObj);

        //Scriptable search to fetch all the customer details
        var customerDetails = _NS_MOD_.getCustomerDetails(currRec, search.Type.EMPLOYEE);
        
        jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["currencyID"] = currRec.getText("expensereportcurrency");
        //Saved search for pre-payment or deposits
        // let dep_index = 0;
        // _NS_MOD_.getDepositDetails(currRec.id).run().each(depr=>{
        //     let isoDepDateTime = moment(depr.getValue("datecreated")).toISOString().split("T");
        //     if(dep_index == 0){
        //         jsonObj["Invoice"][0]["PrepaidPayment"][0]["ID"][0]["_"] = depr.getValue({name:"createdfrom"}) //deposit reference
        //         jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["_"] = depr.getValue({name:"fxamount"}) //deposit amount 
        //         jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["currencyID"] = "MYR";
        //         jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidDate"][0]["_"] = isoDepDateTime[0]//date
        //         jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidTime"][0]["_"] = isoDepDateTime[1]//paid time
        //     }else{
        //         jsonObj["Invoice"][0]["PrepaidPayment"].push({
        //             "ID":[{
        //                 "_": depr.getValue({name:"createdfrom"}) //deposit reference
        //             }],
        //             "PaidAmount":[{
        //                 "_": depr.getValue({name:"fxamount"}) //deposit amount 
        //             }],
        //            "PaidAmount":[{
        //                 "currencyID": "MYR"
        //            }],
        //            "PaidDate":[{
        //                 "_": isoDepDateTime[0]//date
        //            }],
        //            "PaidTime":[{
        //                 "_": isoDepDateTime[1]//paid time
        //            }]
        //         });
        //     }
        // });
        

        //JSON Object creator as per JSON file sequence
        jsonObj["Invoice"][0]["ID"][0]["_"] = currRec.getValue("tranid");
        jsonObj["Invoice"][0]["IssueDate"][0]["_"] = datecreated.split("T")[0];
        jsonObj["Invoice"][0]["IssueTime"][0]["_"] = datecreated.split("T")[1].split(".")[0]+'Z';
        jsonObj["Invoice"][0]["InvoiceTypeCode"][0]["_"] = tranTypeCode;
        // jsonObj["Invoice"][0]["InvoiceTypeCode"][0]["listVersionID"] = "1.1";
        jsonObj["Invoice"][0]["DocumentCurrencyCode"][0]["_"] = currRec.getText("expensereportcurrency");
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["StartDate"][0]["_"] = currRec.getValue("custbody_ein_t_billingstartdate") ? moment(currRec.getValue("custbody_ein_t_billingstartdate")).format("YYYY-MM-DD") : "";
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["EndDate"][0]["_"] = currRec.getValue("custbody_ein_t_billingenddate") ? moment(currRec.getValue("custbody_ein_t_billingenddate")).format("YYYY-MM-DD") : "";
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["Description"][0]["_"] = currRec.getText("custbody_ein_t_frequencyofbilling");
        jsonObj["Invoice"][0]["BillingReference"][0]["AdditionalDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_billrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_t_importedgoodsrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][0]["DocumentType"][0]["_"] = "CustomsImportForm";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_ftanfo") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["DocumentType"][0]["_"] = "FreeTradeAgreement";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["DocumentDescription"][0]["_"] = ""; //currRec.getValue("memo") || "", //need confirmation
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][2]["ID"][0]["_"] = "";//currRec.getValue("custbody_ein_t_exportedgoodsrefno");
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][2]["DocumentType"][0]["_"] = "K2";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][3]["ID"][0]["_"] = currRec.getValue("custbody_abj_incoterm") || "";

        log.audit("invoice document detailes","mapped");

        jsonObj["Invoice"][0]["BillingReference"][1]["InvoiceDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_invoice_doc_no");
        jsonObj["Invoice"][0]["BillingReference"][1]["InvoiceDocumentReference"][0]["UUID"][0]["_"] = currRec.getValue("custbody_ein_t_invoice_uuid");

        //supplier Data as per field mapping sheet
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = customerDetails[0].getValue({name: "firstname", label: "Buyer's Name"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_tax_reg_no", label: "TIN Reg.no."});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_registrationno", label: "Company Registration no."});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = customerDetails[0].getText({name: "custentity_ein_c_regnotype", label: "Type OF Registration no."});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"] = (customerDetails[0].getValue({name: "email", label: "E-Mail ID"})) ? (customerDetails[0].getValue({name: "email", label: "E-Mail ID"})) : "NA";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"] = (customerDetails[0].getValue({name: "phone", label: "Contact no."})) ? (customerDetails[0].getValue({name: "phone", label: "Contact no."}).replace(/[^\d.-]/g, "")) : "NA";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["_"] = (customerDetails[0].getText("custentity_ein_c_msic")).split("-")[0];
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["name"] = (customerDetails[0].getText("custentity_ein_c_msic")).split("-")[1];
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_city"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = customerDetails[0].getValue({name: "zipcode", join: "Address", label: "Zip"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = (customerDetails[0].getText({name:"custentity_ein_c_state"})).split("-")[0];//_NS_MOD_.getStateCode(currRec.getValue("custbody_ein_t_c_state")),
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = customerDetails[0].getValue({name: "addressee", join: "Address", label: "Address Line 0"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = customerDetails[0].getValue({name: "address1", join: "Address", label: "Address Line 1"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = customerDetails[0].getValue({name: "address2", join: "Address", label: "Address Line 2"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = (customerDetails[0].getText({name:"custentity_ein_c_country"})).split("-")[0];//_NS_MOD_.getCountryCode(currRec.getValue("custbody_ein_t_c_country")),
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] = "ISO3166-1";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["_"] = currRec.getValue('custbody_ein_t_exporterrefno') || "";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["schemeAgencyName"] = "CertEx";

        log.audit("invoice supplier detailes","mapped");

        //customer Data as per field mapping sheet
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = suppDetailsObj.registor_name;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"] = suppDetailsObj.tin_reg_no;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"] = suppDetailsObj.reg_no;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = suppDetailsObj.type_of_reg;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["_"] = suppDetailsObj.sst_reg_no;//yet to map
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["schemeID"] = "SST";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"] = (suppDetailsObj.email_id) ? suppDetailsObj.email_id : "NA";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"] = (suppDetailsObj.phone) ? suppDetailsObj.phone : "NA";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"] = suppDetailsObj.city;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = suppDetailsObj.zip;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = _NS_MOD_.getStateCode(suppDetailsObj.state),
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = suppDetailsObj.addressee;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = suppDetailsObj.addr1;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = suppDetailsObj.addr2;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = _NS_MOD_.getCountryCode(suppDetailsObj.country),
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] =  "ISO3166-1";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";

        log.audit("invoice customer detailes","mapped");

        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = suppDetailsObj.registor_name;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["_"] = suppDetailsObj.tin_reg_no;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["_"] = suppDetailsObj.reg_no;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = "BRN";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CityName"][0]["_"] = suppDetailsObj.city;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = suppDetailsObj.zip;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = _NS_MOD_.getStateCode(suppDetailsObj.state);
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = suppDetailsObj.addressee;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = suppDetailsObj.addr1;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = suppDetailsObj.addr2;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = _NS_MOD_.getCountryCode(suppDetailsObj.country);
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] = "ISO3166-1";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";
        //// jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["ChargeIndicator"][0]["_"] = ""; //yet to map
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("expensereportcurrency");
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = "TEST FRIEGHT"; //yet to map

        log.audit("invoice delivery detailes","mapped");

        jsonObj["Invoice"][0]["PaymentMeans"][0]["PaymentMeansCode"][0]["_"] = currRec.getText('custbody_ein_t_paymentmode').split("-")[0];
        jsonObj["Invoice"][0]["PaymentMeans"][0]["PayeeFinancialAccount"][0]["ID"][0]["_"] = suppDetailsObj.pri_bank_acc_no;

        jsonObj["Invoice"][0]["PaymentTerms"][0]["Note"][0]["_"] = currRec.getText('custbody_ein_t_term');

        jsonObj["Invoice"][0]["AllowanceCharge"][0]["ChargeIndicator"][0]["_"] = false;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = "TEST";  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("expensereportcurrency");  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["ChargeIndicator"][0]["_"] = true;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["AllowanceChargeReason"][0]["_"] = "TEST"  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["_"] = 0;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["currencyID"] = currRec.getText("expensereportcurrency");  //yet to map

        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxAmount"][0]["_"] = currRec.getValue('tax1amt');
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxAmount"][0]["currencyID"] = currRec.getText("expensereportcurrency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxableAmount"][0]["_"] = currRec.getValue('tax1amt') ? (currRec.getValue('expense_total') || 0) : 0;
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxableAmount"][0]["currencyID"] = currRec.getText("expensereportcurrency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxAmount"][0]["_"] = currRec.getValue('tax1amt') || 0;
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxAmount"][0]["currencyID"] = currRec.getText("expensereportcurrency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["ID"][0]["_"] = (currRec.getText('custbody_ein_t_taxtype')).split("-")[0];
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["_"] = "OTH"
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["schemeID"] = "UN/ECE 5153";
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["schemeAgencyID"] = "6"

        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["LineExtensionAmount"][0]["_"] = currRec.getValue('total');
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["LineExtensionAmount"][0]["currencyID"] = currRec.getText("expensereportcurrency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["_"] = parseFloat(currRec.getValue("expense_total") || 0); //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["currencyID"] = currRec.getText("expensereportcurrency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["_"] = currRec.getValue("amount"); //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["currencyID"] = currRec.getText("expensereportcurrency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["_"] = 0;//currRec.getValue('discounttotal');
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["currencyID"] = currRec.getText("expensereportcurrency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["currencyID"] = currRec.getText("expensereportcurrency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableRoundingAmount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableRoundingAmount"][0]["currencyID"] = currRec.getText("expensereportcurrency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["_"] = currRec.getValue("amount"); //this is total amount - prepaid amount
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["currencyID"] = currRec.getText("expensereportcurrency");

        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["SourceCurrencyCode"][0]["_"] = currRec.getText("expensereportcurrency");
        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["TargetCurrencyCode"][0]["_"] = "MYR";
        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["CalculationRate"][0]["_"] = parseFloat(currRec.getValue("expensereportexchangerate") || 0);
        
        var jsonBodyValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceBody(jsonObj);
        var jsonLineValidatorError = '';

        //expense lines adding into the invoice lines
        let expenseLineCount = currRec.getLineCount("expense");
        for(let i = 0; i < expenseLineCount; i++){
            jsonObj["Invoice"][0]["InvoiceLine"].push({
                "ID": [{
                    "_": currRec.getSublistText("expense","category",i)
                }],
                "InvoicedQuantity": [{
                    "_": 1,
                    "unitCode": ""//yet to map
                }],
                "LineExtensionAmount": [{
                    "_": currRec.getSublistValue("expense","amount",i) || 0,
                    "currencyID": currRec.getText("expensereportcurrency")
                }],
                "AllowanceCharge": [{
                        "ChargeIndicator": [{
                            "_": false
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0
                        }],
                        "Amount": [{
                            "_": 0,
                            "currencyID": currRec.getText("expensereportcurrency")
                        }]
                    },
                    {
                        "ChargeIndicator": [{
                            "_": true
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0 //yet to map
                        }],
                        "Amount": [{
                            "_": 0,//currRec.getSublistValue('item', 'discountamount', i) || 0,
                            "currencyID": currRec.getText("expensereportcurrency")
                        }]
                    }
                ],
                "TaxTotal": [{
                    "TaxAmount": [{
                        "_": currRec.getSublistValue('expense','taxrate1',i) ? (currRec.getSublistValue('expense', 'tax1amt', i) || 0) : 0,
                        "currencyID": currRec.getText("expensereportcurrency")
                    }],
                    "TaxSubtotal": [{
                        "TaxableAmount": [{
                            "_": currRec.getSublistValue('expense','amount',i) || 0, //yet to map
                            "currencyID": currRec.getText("expensereportcurrency")
                        }],
                        "TaxAmount": [{
                            "_": currRec.getSublistValue('expense', 'tax1amt', i) || 0,
                            "currencyID": currRec.getText("expensereportcurrency")
                        }],
                        "Percent": [{
                            "_": parseFloat(currRec.getSublistValue('expense','taxrate1',i) || 0) //yet to map
                        }],
                        "TaxCategory": [{
                            "ID": [{
                                "_": currRec.getSublistValue('expense','custcol_ein_t_taxtype',i) ? (currRec.getSublistText('expense', 'custcol_ein_t_taxtype', i)).split("-")[0] : ""
                            }],
                            "Percent": [{
                                "_": parseFloat(currRec.getSublistValue('expense','taxrate1',i) || 0) // yet to map
                            }],
                            "TaxScheme": [{
                                "ID": [{
                                    "_": "OTH",
                                    "schemeID": "UN/ECE 5153",
                                    "schemeAgencyID": "6"
                                }]
                            }],
                            "TaxExemptionReason": [{
                                "_": currRec.getSublistValue('expense','taxrate1',i) ? "NA" : currRec.getSublistValue("expense","custcol_ein_t_taxexemptionreason",i) //yet to map
                            }]
                        }]
                    }]
                }],
                "Item": [{
                    "CommodityClassification": [{
                            "ItemClassificationCode": [{
                                "_": currRec.getSublistText('expense', 'custcol_ein_t_prodtariffcode', i) || "",
                                "listID": "PTC"
                            }]
                        },
                        {
                            "ItemClassificationCode": [{
                                "_": (currRec.getSublistText('expense', 'custcol_ein_t_classification', i)).split('-')[0],
                                "listID": "CLASS"
                            }]
                        }
                    ],
                    "Description": [{
                        "_": currRec.getSublistValue('expense', 'memo', i) || ""
                    }],
                    "OriginCountry": [{
                        "IdentificationCode": [{
                            "_": currRec.getSublistText('expense', 'custcol_ein_t_countryoforigin', i) || ""
                        }]
                    }]
                }],
                "Price": [{
                    "PriceAmount": [{
                        "_": currRec.getSublistValue('expense', 'amount', i) || 0,
                        "currencyID": currRec.getText("expensereportcurrency")
                    }]
                }],
                "ItemPriceExtension": [{
                    "Amount": [{
                        "_": currRec.getSublistValue('expense', 'amount', i) || 0,
                        "currencyID": currRec.getText("expensereportcurrency")
                    }]
                }]
            });

            let lineValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceLine(jsonObj["Invoice"][0]["InvoiceLine"][jsonObj["Invoice"][0]["InvoiceLine"].length-1]);
            jsonLineValidatorError += lineValidatorError ? `\nexpense line ${i+1} :` + "\n" + Object.keys(lineValidatorError).map(key=>lineValidatorError[key]).join("\n") : '';
        }


        return {
            jsondata : jsonObj,
            jsonBodyValid: jsonBodyValidatorError ? Object.keys(jsonBodyValidatorError).map(key=>jsonBodyValidatorError[key]).join("\n") : '',
            jsonLineValid: jsonLineValidatorError
        };
    }


    
    /**
     * it will map the Expense data to json object
     */
    const mapJSONWithCHECKData = (currRec, jsonObj, tranTypeCode, currentSubId) =>{
        let configSetupSearch = search.create({
            type: 'customrecord_my_einv_con_setup',
            columns: [
                'internalid',
                'custrecord_my_e_inv_clientid',
                'custrecord_my_e_inv_client_secret',
                'custrecord_my_e_inv_client_secret2',
                'custrecord_my_e_invoice_base_url',
                'custrecord_my_e_invoice_subsidiary',
                'custrecord_my_e_inv_tin',
                'custrecord_my_e_inv_brn',
                'custrecord_my_e_inv_tin_autoappreinv'
            ],
            filters: [
                ['custrecord_my_e_invoice_subsidiary','anyof', currentSubId]
            ]
        }).run().getRange(0, 10);
        let datecreated = moment(new Date()).toISOString();
        log.debug("datecreated",datecreated);

        //Scriptable search to fetch all the supplier details
        var multiSubFeature = runtime.isFeatureInEffect({feature:"subsidiaries"});
        var applicableSubId = multiSubFeature ? configSetupSearch[0].getValue('custrecord_my_e_invoice_subsidiary') : 1;
        var suppDetailsObj = _NS_MOD_.getSupplierDetails(applicableSubId, multiSubFeature);
        log.debug("suppDetailsObj",suppDetailsObj);

        //Scriptable search to fetch all the customer details
        var entityType = search.lookupFields({
            type: search.Type.ENTITY,
            id: currRec.getValue('entity'),
            columns:['type']
        })['type'][0]['value']
        var customerDetails = _NS_MOD_.getCustomerDetails(currRec, entityType);
        
        jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["currencyID"] = currRec.getText("currency");
        //Saved search for pre-payment or deposits
        // let dep_index = 0;
        // _NS_MOD_.getDepositDetails(currRec.id).run().each(depr=>{
        //     let isoDepDateTime = moment(depr.getValue("datecreated")).toISOString().split("T");
        //     if(dep_index == 0){
        //         jsonObj["Invoice"][0]["PrepaidPayment"][0]["ID"][0]["_"] = depr.getValue({name:"createdfrom"}) //deposit reference
        //         jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["_"] = depr.getValue({name:"fxamount"}) //deposit amount 
        //         jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["currencyID"] = "MYR";
        //         jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidDate"][0]["_"] = isoDepDateTime[0]//date
        //         jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidTime"][0]["_"] = isoDepDateTime[1]//paid time
        //     }else{
        //         jsonObj["Invoice"][0]["PrepaidPayment"].push({
        //             "ID":[{
        //                 "_": depr.getValue({name:"createdfrom"}) //deposit reference
        //             }],
        //             "PaidAmount":[{
        //                 "_": depr.getValue({name:"fxamount"}) //deposit amount 
        //             }],
        //            "PaidAmount":[{
        //                 "currencyID": "MYR"
        //            }],
        //            "PaidDate":[{
        //                 "_": isoDepDateTime[0]//date
        //            }],
        //            "PaidTime":[{
        //                 "_": isoDepDateTime[1]//paid time
        //            }]
        //         });
        //     }
        // });

        //JSON Object creator as per JSON file sequence
        jsonObj["Invoice"][0]["ID"][0]["_"] = currRec.getValue("tranid");
        jsonObj["Invoice"][0]["IssueDate"][0]["_"] = datecreated.split("T")[0];
        jsonObj["Invoice"][0]["IssueTime"][0]["_"] = datecreated.split("T")[1].split(".")[0]+'Z';
        jsonObj["Invoice"][0]["InvoiceTypeCode"][0]["_"] = tranTypeCode;
        // jsonObj["Invoice"][0]["InvoiceTypeCode"][0]["listVersionID"] = "1.1";
        jsonObj["Invoice"][0]["DocumentCurrencyCode"][0]["_"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["StartDate"][0]["_"] = currRec.getValue("custbody_ein_t_billingstartdate") ? moment(currRec.getValue("custbody_ein_t_billingstartdate")).format("YYYY-MM-DD") : "";
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["EndDate"][0]["_"] = currRec.getValue("custbody_ein_t_billingenddate") ? moment(currRec.getValue("custbody_ein_t_billingenddate")).format("YYYY-MM-DD") : "";
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["Description"][0]["_"] = currRec.getText("custbody_ein_t_frequencyofbilling");
        jsonObj["Invoice"][0]["BillingReference"][0]["AdditionalDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_billrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_t_importedgoodsrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][0]["DocumentType"][0]["_"] = "CustomsImportForm";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_ftanfo") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["DocumentType"][0]["_"] = "FreeTradeAgreement";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["DocumentDescription"][0]["_"] = ""; //currRec.getValue("memo") || "", //need confirmation
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][2]["ID"][0]["_"] = "";//currRec.getValue("custbody_ein_t_exportedgoodsrefno");
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][2]["DocumentType"][0]["_"] = "K2";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][3]["ID"][0]["_"] = currRec.getValue("custbody_abj_incoterm") || "";

        log.audit("invoice document detailes","mapped");

        jsonObj["Invoice"][0]["BillingReference"][1]["InvoiceDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_invoice_doc_no");
        jsonObj["Invoice"][0]["BillingReference"][1]["InvoiceDocumentReference"][0]["UUID"][0]["_"] = currRec.getValue("custbody_ein_t_invoice_uuid");

        //supplier Data as per field mapping sheet
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = customerDetails[0].getValue({name: "companyname", label: "Company Name"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"] = entityType == "Employee" ? customerDetails[0].getValue({name: "custentity_ein_c_tax_reg_no", label: "TIN Reg.no."}) :  customerDetails[0].getValue({name: "vatregnumber", label: "TIN Reg.no."}); 
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_registrationno", label: "Company Registration no."});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = customerDetails[0].getText({name: "custentity_ein_c_regnotype", label: "Type OF Registration no."});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"] = (customerDetails[0].getValue({name: "email", label: "E-Mail ID"})) ? (customerDetails[0].getValue({name: "email", label: "E-Mail ID"})) : "NA";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"] = (customerDetails[0].getValue({name: "phone", label: "Contact no."})) ? (customerDetails[0].getValue({name: "phone", label: "Contact no."}).replace(/[^\d.-]/g, "")) : "NA";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["_"] = (customerDetails[0].getText("custentity_ein_c_msic")).split("-")[0];
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["name"] = (customerDetails[0].getText("custentity_ein_c_msic")).split("-")[1];
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_city"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = customerDetails[0].getValue({name: "zipcode", join: "Address", label: "Zip"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = (customerDetails[0].getText({name:"custentity_ein_c_state"})).split("-")[0];//_NS_MOD_.getStateCode(currRec.getValue("custbody_ein_t_c_state")),
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = customerDetails[0].getValue({name: "addressee", join: "Address", label: "Address Line 0"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = customerDetails[0].getValue({name: "address1", join: "Address", label: "Address Line 1"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = customerDetails[0].getValue({name: "address2", join: "Address", label: "Address Line 2"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = (customerDetails[0].getText({name:"custentity_ein_c_country"})).split("-")[0];//_NS_MOD_.getCountryCode(currRec.getValue("custbody_ein_t_c_country")),
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] = "ISO3166-1";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["_"] = currRec.getValue('custbody_ein_t_exporterrefno') || "";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["schemeAgencyName"] = "CertEx";

        log.audit("invoice supplier detailes","mapped");

        //customer Data as per field mapping sheet
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = suppDetailsObj.registor_name;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"] = suppDetailsObj.tin_reg_no;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"] = suppDetailsObj.reg_no;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = suppDetailsObj.type_of_reg;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["_"] = suppDetailsObj.sst_reg_no;//yet to map
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["schemeID"] = "SST";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"] = (suppDetailsObj.email_id) ? suppDetailsObj.email_id : "NA";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"] = (suppDetailsObj.phone) ? suppDetailsObj.phone : "NA";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"] = suppDetailsObj.city;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = suppDetailsObj.zip;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = _NS_MOD_.getStateCode(suppDetailsObj.state),
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = suppDetailsObj.addressee;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = suppDetailsObj.addr1;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = suppDetailsObj.addr2;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = _NS_MOD_.getCountryCode(suppDetailsObj.country),
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] =  "ISO3166-1";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";

        log.audit("invoice customer detailes","mapped");

        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = suppDetailsObj.registor_name;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["_"] = suppDetailsObj.tin_reg_no;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["_"] = suppDetailsObj.reg_no;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = "BRN";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CityName"][0]["_"] = suppDetailsObj.city;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = suppDetailsObj.zip;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = _NS_MOD_.getStateCode(suppDetailsObj.state);
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = suppDetailsObj.addressee;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = suppDetailsObj.addr1;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = suppDetailsObj.addr2;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = _NS_MOD_.getCountryCode(suppDetailsObj.country);
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] = "ISO3166-1";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";
        //// jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["ChargeIndicator"][0]["_"] = ""; //yet to map
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = "TEST FRIEGHT"; //yet to map

        log.audit("invoice delivery detailes","mapped");

        jsonObj["Invoice"][0]["PaymentMeans"][0]["PaymentMeansCode"][0]["_"] = currRec.getText('custbody_ein_t_paymentmode').split("-")[0];
        jsonObj["Invoice"][0]["PaymentMeans"][0]["PayeeFinancialAccount"][0]["ID"][0]["_"] = suppDetailsObj.pri_bank_acc_no;

        jsonObj["Invoice"][0]["PaymentTerms"][0]["Note"][0]["_"] = currRec.getText('custbody_ein_t_term');

        jsonObj["Invoice"][0]["AllowanceCharge"][0]["ChargeIndicator"][0]["_"] = false;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = "TEST";  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["ChargeIndicator"][0]["_"] = true;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["AllowanceChargeReason"][0]["_"] = "TEST"  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["_"] = 0;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["currencyID"] = currRec.getText("currency");  //yet to map

        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxAmount"][0]["_"] = currRec.getValue('taxtotal');
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxableAmount"][0]["_"] = currRec.getValue('taxtotal') ? (currRec.getValue('total') || 0) : 0;
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxableAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxAmount"][0]["_"] = parseFloat(currRec.getValue('taxtotal') || 0);
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["ID"][0]["_"] = (currRec.getText('custbody_ein_t_taxtype')).split("-")[0];
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["_"] = "OTH"
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["schemeID"] = "UN/ECE 5153";
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["schemeAgencyID"] = "6"

        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["LineExtensionAmount"][0]["_"] = currRec.getValue('total');
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["LineExtensionAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["_"] = parseFloat(parseFloat(currRec.getValue("usertotal"))) - parseFloat(currRec.getValue('taxtotal')) //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["_"] = parseFloat(currRec.getValue("usertotal")); //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["_"] = 0;//currRec.getValue('discounttotal');
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableRoundingAmount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableRoundingAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["_"] = parseFloat(currRec.getValue("usertotal")); //this is total amount - prepaid amount
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["currencyID"] = currRec.getText("currency");

        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["SourceCurrencyCode"][0]["_"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["TargetCurrencyCode"][0]["_"] = "MYR";
        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["CalculationRate"][0]["_"] = parseFloat(currRec.getValue("exchangerate") || 0);

        let itemCount = currRec.getLineCount('item');

        var jsonBodyValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceBody(jsonObj);
        var jsonLineValidatorError = '';

        //adding the item lines
        for(let i=0; i < itemCount; i++){
            let itemType = currRec.getSublistValue("item","itemtype",i);
            let otherorfee = currRec.getSublistValue("item","custcol_ein_t_fee_charge_rate_yes_no",i);
            if(itemType == "Description")continue;
            if(itemType == "Discount"){
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["ChargeIndicator"][0]["_"] = false; //yet to map
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = currRec.getSublistValue('item','description',i); //yet to map
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["MultiplierFactorNumeric"][0]["_"] = parseFloat(currRec.getSublistValue('item', 'rate', i) || 0);
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["Amount"][0]["_"] = parseFloat(currRec.getSublistValue('item', 'amount', i) || 0);
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");
                jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["_"] += parseFloat(parseFloat(currRec.getSublistValue('item', 'amount', i) || 0));
                continue;
            };
            if(otherorfee){
                jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));//yet to map
                jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));
                jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));
                continue;
            }
            //INVOICE LINE DATA
            jsonObj["Invoice"][0]["InvoiceLine"].push({
                "ID": [{
                    "_": currRec.getSublistValue("item","item_display",i)
                }],
                "InvoicedQuantity": [{
                    "_": currRec.getSublistValue('item', 'quantity', i) || 0,
                    "unitCode": currRec.getSublistValue('item', 'unit', i) || ""
                }],
                "LineExtensionAmount": [{
                    "_": parseFloat(currRec.getSublistValue("item","amount",i) || 0),
                    "currencyID": currRec.getText("currency")
                }],
                "AllowanceCharge": [{
                        "ChargeIndicator": [{
                            "_": false
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0
                        }],
                        "Amount": [{
                            "_": 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    },
                    {
                        "ChargeIndicator": [{
                            "_": true
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0 //yet to map
                        }],
                        "Amount": [{
                            "_": 0,//currRec.getSublistValue('item', 'discountamount', i) || 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    }
                ],
                "TaxTotal": [{
                    "TaxAmount": [{
                        "_": currRec.getSublistValue('item','taxrate1',i) ? (parseFloat(currRec.getSublistValue('item', 'tax1amt', i) || 0)) : 0,
                        "currencyID": currRec.getText("currency")
                    }],
                    "TaxSubtotal": [{
                        "TaxableAmount": [{
                            "_": parseFloat(currRec.getSublistValue('item','amount',i) || 0), //yet to map
                            "currencyID": currRec.getText("currency")
                        }],
                        "TaxAmount": [{
                            "_": parseFloat(currRec.getSublistValue('item', 'tax1amt', i) || 0),
                            "currencyID": currRec.getText("currency")
                        }],
                        "Percent": [{
                            "_": parseFloat(currRec.getSublistValue('item','taxrate1',i) || 0) //yet to map
                        }],
                        "TaxCategory": [{
                            "ID": [{
                                "_": currRec.getSublistValue('item','custcol_ein_t_taxtype',i) ? (currRec.getSublistText('item', 'custcol_ein_t_taxtype', i)).split("-")[0] : ""
                            }],
                            "Percent": [{
                                "_": parseFloat(currRec.getSublistValue('item','taxrate1',i) || 0) // yet to map
                            }],
                            "TaxScheme": [{
                                "ID": [{
                                    "_": "OTH",
                                    "schemeID": "UN/ECE 5153",
                                    "schemeAgencyID": "6"
                                }]
                            }],
                            "TaxExemptionReason": [{
                                "_": currRec.getSublistValue('item','taxrate1',i) ? "NA" : currRec.getSublistValue("item","custcol_ein_t_taxexemptionreason",i) //yet to map
                            }]
                        }]
                    }]
                }],
                "Item": [{
                    "CommodityClassification": [{
                            "ItemClassificationCode": [{
                                "_": currRec.getSublistText('item', 'custcol_ein_t_prodtariffcode', i) || "",
                                "listID": "PTC"
                            }]
                        },
                        {
                            "ItemClassificationCode": [{
                                "_": (currRec.getSublistText('item', 'custcol_ein_t_classification', i)).split('-')[0],
                                "listID": "CLASS"
                            }]
                        }
                    ],
                    "Description": [{
                        "_": currRec.getSublistValue('item', 'description', i) || ""
                    }],
                    "OriginCountry": [{
                        "IdentificationCode": [{
                            "_": currRec.getSublistText('item', 'custcol_ein_t_countryoforigin', i) || ""
                        }]
                    }]
                }],
                "Price": [{
                    "PriceAmount": [{
                        "_": parseFloat(currRec.getSublistValue('item', 'rate', i) || 0),
                        "currencyID": currRec.getText("currency")
                    }]
                }],
                "ItemPriceExtension": [{
                    "Amount": [{
                        "_": parseFloat(currRec.getSublistValue('item', 'amount', i) || 0),
                        "currencyID": currRec.getText("currency")
                    }]
                }]
            });

            let lineValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceLine(jsonObj["Invoice"][0]["InvoiceLine"][jsonObj["Invoice"][0]["InvoiceLine"].length-1]);
            jsonLineValidatorError += lineValidatorError ? `\nitem line ${i+1} :` + "\n" + Object.keys(lineValidatorError).map(key=>lineValidatorError[key]).join("\n") : '';
        }

        //expense lines adding into the invoice lines
        let expenseLineCount = currRec.getLineCount("expense");
        let invoiceLineCountStart = jsonObj["Invoice"][0]["InvoiceLine"].length;
        for(let i = 0; i < expenseLineCount; i++,invoiceLineCountStart++){
            jsonObj["Invoice"][0]["InvoiceLine"].push({
                "ID": [{
                    "_": currRec.getSublistText("expense","category",i)
                }],
                "InvoicedQuantity": [{
                    "_": 1,
                    "unitCode": ""//yet to map
                }],
                "LineExtensionAmount": [{
                    "_": currRec.getSublistValue("expense","amount",i) || 0,
                    "currencyID": currRec.getText("currency")
                }],
                "AllowanceCharge": [{
                        "ChargeIndicator": [{
                            "_": false
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0
                        }],
                        "Amount": [{
                            "_": 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    },
                    {
                        "ChargeIndicator": [{
                            "_": true
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0 //yet to map
                        }],
                        "Amount": [{
                            "_": 0,//currRec.getSublistValue('item', 'discountamount', i) || 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    }
                ],
                "TaxTotal": [{
                    "TaxAmount": [{
                        "_": currRec.getSublistValue('expense','taxrate1',i) ? (currRec.getSublistValue('expense', 'tax1amt', i) || 0) : 0,
                        "currencyID": currRec.getText("currency")
                    }],
                    "TaxSubtotal": [{
                        "TaxableAmount": [{
                            "_": currRec.getSublistValue('expense','amount',i) || 0, //yet to map
                            "currencyID": currRec.getText("currency")
                        }],
                        "TaxAmount": [{
                            "_": currRec.getSublistValue('expense', 'tax1amt', i) || 0,
                            "currencyID": currRec.getText("currency")
                        }],
                        "Percent": [{
                            "_": parseFloat(currRec.getSublistValue('expense','taxrate1',i) || 0) //yet to map
                        }],
                        "TaxCategory": [{
                            "ID": [{
                                "_": currRec.getSublistValue('expense','custcol_ein_t_taxtype',i) ? (currRec.getSublistText('expense', 'custcol_ein_t_taxtype', i)).split("-")[0] : ""
                            }],
                            "Percent": [{
                                "_": parseFloat(currRec.getSublistValue('expense','taxrate1',i) || 0) // yet to map
                            }],
                            "TaxScheme": [{
                                "ID": [{
                                    "_": "OTH",
                                    "schemeID": "UN/ECE 5153",
                                    "schemeAgencyID": "6"
                                }]
                            }],
                            "TaxExemptionReason": [{
                                "_": currRec.getSublistValue('expense','taxrate1',i) ? "NA" : currRec.getSublistValue("expense","custcol_ein_t_taxexemptionreason",i) //yet to map
                            }]
                        }]
                    }]
                }],
                "Item": [{
                    "CommodityClassification": [{
                            "ItemClassificationCode": [{
                                "_": currRec.getSublistText('expense', 'custcol_ein_t_prodtariffcode', i) || "",
                                "listID": "PTC"
                            }]
                        },
                        {
                            "ItemClassificationCode": [{
                                "_": (currRec.getSublistText('expense', 'custcol_ein_t_classification', i)).split('-')[0],
                                "listID": "CLASS"
                            }]
                        }
                    ],
                    "Description": [{
                        "_": currRec.getSublistValue('expense', 'memo', i) || ""
                    }],
                    "OriginCountry": [{
                        "IdentificationCode": [{
                            "_": currRec.getSublistText('expense', 'custcol_ein_t_countryoforigin', i) || ""
                        }]
                    }]
                }],
                "Price": [{
                    "PriceAmount": [{
                        "_": currRec.getSublistValue('expense', 'amount', i) || 0,
                        "currencyID": currRec.getText("currency")
                    }]
                }],
                "ItemPriceExtension": [{
                    "Amount": [{
                        "_": currRec.getSublistValue('expense', 'amount', i) || 0,
                        "currencyID": currRec.getText("currency")
                    }]
                }]
            });

            let lineValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceLine(jsonObj["Invoice"][0]["InvoiceLine"][invoiceLineCountStart]);
            jsonLineValidatorError += lineValidatorError ? `\nexpense line ${i+1} :` + "\n" + Object.keys(lineValidatorError).map(key=>lineValidatorError[key]).join("\n") : '';
        }


        return {
            jsondata : jsonObj,
            jsonBodyValid: jsonBodyValidatorError ? Object.keys(jsonBodyValidatorError).map(key=>jsonBodyValidatorError[key]).join("\n") : '',
            jsonLineValid: jsonLineValidatorError
        };
    }


    /**
    * it will map the Invoice data to json object
    */
    const mapJSONWithCMData = (currRec, jsonObj, tranTypeCode, currentSubId) =>{
        let configSetupSearch = search.create({
            type: 'customrecord_my_einv_con_setup',
            columns: [
                'internalid',
                'custrecord_my_e_inv_clientid',
                'custrecord_my_e_inv_client_secret',
                'custrecord_my_e_inv_client_secret2',
                'custrecord_my_e_invoice_base_url',
                'custrecord_my_e_invoice_subsidiary',
                'custrecord_my_e_inv_tin',
                'custrecord_my_e_inv_brn',
                'custrecord_my_e_inv_tin_autoappreinv'
            ],
            filters: [
                ['custrecord_my_e_invoice_subsidiary','anyof', currentSubId]
            ]
        }).run().getRange(0, 10);
        let datecreated = moment(new Date()).toISOString();
        log.debug("datecreated",datecreated);

        //Scriptable search to fetch all the supplier details
        var multiSubFeature = runtime.isFeatureInEffect({feature:"subsidiaries"});
        var applicableSubId = multiSubFeature ? configSetupSearch[0].getValue('custrecord_my_e_invoice_subsidiary') : 1;
        var suppDetailsObj = _NS_MOD_.getSupplierDetails(applicableSubId, multiSubFeature);
        log.debug("suppDetailsObj",suppDetailsObj);

        //Scriptable search to fetch all the customer details
        let isPerson = search.lookupFields({
            type: search.Type.CUSTOMER,
            id: currRec.getValue("entity"),
            columns: ["isperson"]
        })['isperson'];
        var customerDetails = _NS_MOD_.getCustomerDetails(currRec, search.Type.CUSTOMER, isPerson);
        
        //Saved search for pre-payment or deposits
        let dep_index = 0;
        jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["currencyID"] = currRec.getText("currency");
        _NS_MOD_.getDepositDetails(currRec.id).run().each(depr=>{
            let isoDepDateTime = moment(depr.getValue("datecreated")).toISOString().split("T");
            if(dep_index == 0){
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["ID"][0]["_"] = depr.getValue({name:"createdfrom"}) //deposit reference
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["_"] = parseFloat(depr.getValue({name:"fxamount"})) //deposit amount 
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["currencyID"] = depr.getText({name:"currency"}) || currRec.getText("currency");
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidDate"][0]["_"] = isoDepDateTime[0]//date
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidTime"][0]["_"] = isoDepDateTime[1]//paid time
            }else{
                jsonObj["Invoice"][0]["PrepaidPayment"].push({
                    "ID":[{
                        "_": depr.getValue({name:"createdfrom"}) //deposit reference
                    }],
                    "PaidAmount":[{
                        "_": parseFloat(depr.getValue({name:"fxamount"})) //deposit amount 
                    }],
                   "PaidAmount":[{
                        "currencyID": depr.getText({name:"currency"}) || currRec.getText("currency")
                   }],
                   "PaidDate":[{
                        "_": isoDepDateTime[0]//date
                   }],
                   "PaidTime":[{
                        "_": isoDepDateTime[1]//paid time
                   }]
                });
            }
        });

        var custShippingAddress = currRec.getSubrecord({
            fieldId: 'shippingaddress'
        });

        //JSON Object creator as per JSON file sequence
        jsonObj["Invoice"][0]["ID"][0]["_"] = currRec.getValue("tranid");
        jsonObj["Invoice"][0]["IssueDate"][0]["_"] = datecreated.split("T")[0];
        jsonObj["Invoice"][0]["IssueTime"][0]["_"] = datecreated.split("T")[1].split(".")[0]+'Z';
        jsonObj["Invoice"][0]["InvoiceTypeCode"][0]["_"] = tranTypeCode;
        // jsonObj["Invoice"][0]["InvoiceTypeCode"][0]["listVersionID"] = "1.1";
        jsonObj["Invoice"][0]["DocumentCurrencyCode"][0]["_"] = currRec.getValue("currencyname");
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["StartDate"][0]["_"] = currRec.getValue("startdate") ? moment(currRec.getValue("startdate")).format("YYYY-MM-DD") : "";
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["EndDate"][0]["_"] = currRec.getValue("enddate") ? moment(currRec.getValue("enddate")).format("YYYY-MM-DD") : "";
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["Description"][0]["_"] = currRec.getText("custbody_ein_t_frequencyofbilling");

        jsonObj["Invoice"][0]["BillingReference"][1]["InvoiceDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_invoice_doc_no");
        jsonObj["Invoice"][0]["BillingReference"][1]["InvoiceDocumentReference"][0]["UUID"][0]["_"] = currRec.getValue("custbody_ein_t_invoice_uuid");

        jsonObj["Invoice"][0]["BillingReference"][0]["AdditionalDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_billrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_t_importedgoodsrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][0]["DocumentType"][0]["_"] = "CustomsImportForm";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_ftanfo") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["DocumentType"][0]["_"] = "FreeTradeAgreement";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["DocumentDescription"][0]["_"] = ""; //currRec.getValue("memo") || "", //need confirmation
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][2]["ID"][0]["_"] = "";//currRec.getValue("custbody_ein_t_exportedgoodsrefno");
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][2]["DocumentType"][0]["_"] = "K2";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][3]["ID"][0]["_"] = currRec.getValue("custbody_abj_incoterm") || "";
        
        //Supplier Data as per field mapping sheet
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = suppDetailsObj.registor_name;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"] = suppDetailsObj.tin_reg_no;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"] = suppDetailsObj.reg_no;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = suppDetailsObj.type_of_reg;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"] = (suppDetailsObj.email_id) ? suppDetailsObj.email_id : "NA";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"] = (suppDetailsObj.phone) ? suppDetailsObj.phone : "NA";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["_"] = (suppDetailsObj.msic).split("-")[0];
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["name"] = (suppDetailsObj.msic).split("-")[1];
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"] = suppDetailsObj.city;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = suppDetailsObj.zip;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = _NS_MOD_.getStateCode(suppDetailsObj.state),
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = suppDetailsObj.addressee;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = suppDetailsObj.addr1;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = suppDetailsObj.addr2;
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = _NS_MOD_.getCountryCode(suppDetailsObj.country),
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] =  "ISO3166-1";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["_"] = currRec.getValue('custbody_ein_t_exporterrefno') || "";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["schemeAgencyName"] = "CertEx";

        //Customer Data as per field mapping sheet
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = isPerson ? customerDetails[0].getValue({name: "altname", label: "Buyer's Name"}) : customerDetails[0].getValue({name: "companyname"});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"] = customerDetails[0].getValue({name: "vatregnumber", label: "TIN Reg.no."});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_registrationno", label: "Company Registration no."});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = customerDetails[0].getText({name: "custentity_ein_c_regnotype", label: "Type OF Registration no."});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_sstregistrationno", label: "SST Registration no."});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["schemeID"] = "SST";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"] = (customerDetails[0].getValue({name: "email", label: "E-Mail ID"})) ? (customerDetails[0].getValue({name: "email", label: "E-Mail ID"})) : "NA";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"] = (customerDetails[0].getValue({name: "phone", label: "Contact no."})) ? (customerDetails[0].getValue({name: "phone", label: "Contact no."}).replace(/[^\d.-]/g, "")) : "NA";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_city"});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = customerDetails[0].getValue({name: "zipcode", join: "Address", label: "Zip"});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = (customerDetails[0].getText({name:"custentity_ein_c_state"})).split("-")[0];//_NS_MOD_.getStateCode(currRec.getValue("custbody_ein_t_c_state")),
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = customerDetails[0].getValue({name: "addressee", join: "Address", label: "Address Line 0"});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = customerDetails[0].getValue({name: "address1", join: "Address", label: "Address Line 1"});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = customerDetails[0].getValue({name: "address2", join: "Address", label: "Address Line 2"});
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = (customerDetails[0].getText({name:"custentity_ein_c_country"})).split("-")[0];//_NS_MOD_.getCountryCode(currRec.getValue("custbody_ein_t_c_country")),
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] = "ISO3166-1";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";

        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = custShippingAddress.getValue({fieldId: "addressee"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["_"] = customerDetails[0].getValue({name: "vatregnumber", label: "TIN Reg.no."});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_registrationno"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = "BRN";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CityName"][0]["_"] = currRec.getValue({fieldId: "custbody_ein_t_c_city"});;//custShippingAddress.getValue({fieldId: "city"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = "";//custShippingAddress.getValue({fieldId: "zip"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = currRec.getText({fieldId:"custbody_ein_t_c_state"}).split("-")[0];//_NS_MOD_.getStateCode(custShippingAddress.getValue({fieldId:"state"}));
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = custShippingAddress.getValue({fieldId: "addressee"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = custShippingAddress.getValue({fieldId: "addr1"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = custShippingAddress.getValue({fieldId: "addr2"});
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = currRec.getText({fieldId:"custbody_ein_t_c_country"});//_NS_MOD_.getCountryCode(custShippingAddress.getText({fieldId:"country"}));
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] = "ISO3166-1";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";
        //// jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["ChargeIndicator"][0]["_"] = ""; //yet to map
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = "TEST FRIEGHT"; //yet to map
        
        jsonObj["Invoice"][0]["PaymentMeans"][0]["PaymentMeansCode"][0]["_"] = currRec.getText('custbody_ein_t_paymentmode').split("-")[0];
        jsonObj["Invoice"][0]["PaymentMeans"][0]["PayeeFinancialAccount"][0]["ID"][0]["_"] = suppDetailsObj.pri_bank_acc_no;

        jsonObj["Invoice"][0]["PaymentTerms"][0]["Note"][0]["_"] = customerDetails[0].getText('terms');

        jsonObj["Invoice"][0]["AllowanceCharge"][0]["ChargeIndicator"][0]["_"] = false;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = "TEST";  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["_"] = 0;//yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["ChargeIndicator"][0]["_"] = true;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["AllowanceChargeReason"][0]["_"] = "TEST"  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["_"] = 0;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["currencyID"] = currRec.getText("currency");  //yet to map

        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxAmount"][0]["_"] = currRec.getValue('taxtotal');
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxableAmount"][0]["_"] = currRec.getValue('taxtotal') ? (currRec.getValue('subtotal') || 0) : 0;
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxableAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxAmount"][0]["_"] = parseFloat(currRec.getValue('taxtotal') || 0);
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["ID"][0]["_"] = (currRec.getText('custbody_ein_t_taxtype')).split("-")[0];
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["_"] = "OTH"
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["schemeID"] = "UN/ECE 5153";
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["schemeAgencyID"] = "6"

        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["LineExtensionAmount"][0]["_"] = currRec.getValue('total');
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["LineExtensionAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["_"] = currRec.getValue("subtotal") //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["_"] = currRec.getValue("total"); //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["_"] = parseFloat(currRec.getValue('discounttotal') || 0);
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableRoundingAmount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableRoundingAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["_"] = currRec.getValue("total"); //this is total amount - prepaid amount
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["currencyID"] = currRec.getText("currency");

        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["SourceCurrencyCode"][0]["_"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["TargetCurrencyCode"][0]["_"] = "MYR";
        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["CalculationRate"][0]["_"] = parseFloat(currRec.getValue("exchangerate") || 0);

        let itemCount = currRec.getLineCount('item');

        var jsonBodyValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceBody(jsonObj);
        var jsonLineValidatorError = '';

        for(let i=0; i < itemCount; i++){
            let itemType = currRec.getSublistValue("item","itemtype",i);
            let otherorfee = currRec.getSublistValue("item","custcol_ein_t_fee_charge_rate_yes_no",i);
            if(itemType == "Description")continue;
            if(itemType == "Discount"){
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["ChargeIndicator"][0]["_"] = false; //yet to map
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = currRec.getSublistValue('item','description',i); //yet to map
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["MultiplierFactorNumeric"][0]["_"] = parseFloat(currRec.getSublistValue('item', 'rate', i) || 0);
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["Amount"][0]["_"] = parseFloat(currRec.getSublistValue('item', 'amount', i) || 0);
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");
                jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["_"] += parseFloat(parseFloat(currRec.getSublistValue('item', 'amount', i) || 0));
                continue;
            };
            if(otherorfee){
                jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));//yet to map
                jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));
                jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));
                continue;
            }
            //INVOICE LINE DATA
            jsonObj["Invoice"][0]["InvoiceLine"].push({
                "ID": [{
                    "_": currRec.getSublistValue("item","item_display",i)
                }],
                "InvoicedQuantity": [{
                    "_": currRec.getSublistValue('item', 'quantity', i) || 0,
                    "unitCode": currRec.getSublistValue('item', 'unit', i) || ""
                }],
                "LineExtensionAmount": [{
                    "_": parseFloat(currRec.getSublistValue("item","amount",i) || 0),
                    "currencyID": currRec.getText("currency")
                }],
                "AllowanceCharge": [{
                        "ChargeIndicator": [{
                            "_": false
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0
                        }],
                        "Amount": [{
                            "_": 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    },
                    {
                        "ChargeIndicator": [{
                            "_": true
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0 //yet to map
                        }],
                        "Amount": [{
                            "_": 0,//currRec.getSublistValue('item', 'discountamount', i) || 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    }
                ],
                "TaxTotal": [{
                    "TaxAmount": [{
                        "_": parseFloat(currRec.getSublistValue('item', 'tax1amt', i) || 0),
                        "currencyID": currRec.getText("currency")
                    }],
                    "TaxSubtotal": [{
                        "TaxableAmount": [{
                            "_": currRec.getSublistValue('item','taxrate1',i) ? currRec.getSublistValue('item','amount',i) : 0, //yet to map
                            "currencyID": currRec.getText("currency")
                        }],
                        "TaxAmount": [{
                            "_": parseFloat(currRec.getSublistValue('item', 'tax1amt', i) || 0),
                            "currencyID": currRec.getText("currency")
                        }],
                        "Percent": [{
                            "_": parseFloat(currRec.getSublistValue('item','taxrate1',i) || 0) //yet to map
                        }],
                        "TaxCategory": [{
                            "ID": [{
                                "_": currRec.getSublistValue('item','custcol_ein_t_taxtype',i) ? (currRec.getSublistText('item', 'custcol_ein_t_taxtype', i)).split("-")[0] : ""
                            }],
                            "Percent": [{
                                "_": parseFloat(currRec.getSublistValue('item','taxrate1',i) || 0) // yet to map
                            }],
                            "TaxScheme": [{
                                "ID": [{
                                    "_": "OTH",
                                    "schemeID": "UN/ECE 5153",
                                    "schemeAgencyID": "6"
                                }]
                            }],
                            "TaxExemptionReason": [{
                                "_": currRec.getSublistValue('item','taxrate1',i) ? "NA" : currRec.getSublistValue("item","custcol_ein_t_taxexemptionreason",i)
                            }]
                        }]
                    }]
                }],
                "Item": [{
                    "CommodityClassification": [{
                            "ItemClassificationCode": [{
                                "_": currRec.getSublistText('item', 'custcol_ein_t_prodtariffcode', i) || "",
                                "listID": "PTC"
                            }]
                        },
                        {
                            "ItemClassificationCode": [{
                                "_": (currRec.getSublistText('item', 'custcol_ein_t_classification', i)).split('-')[0],
                                "listID": "CLASS"
                            }]
                        }
                    ],
                    "Description": [{
                        "_": currRec.getSublistValue('item', 'description', i) || ""
                    }],
                    "OriginCountry": [{
                        "IdentificationCode": [{
                            "_": currRec.getSublistText('item', 'custcol_ein_t_countryoforigin', i) || ""
                        }]
                    }]
                }],
                "Price": [{
                    "PriceAmount": [{
                        "_": parseFloat(currRec.getSublistValue('item', 'rate', i) || 0),
                        "currencyID": currRec.getText("currency")
                    }]
                }],
                "ItemPriceExtension": [{
                    "Amount": [{
                        "_": parseFloat(currRec.getSublistValue('item', 'amount', i) || 0),
                        "currencyID": currRec.getText("currency")
                    }]
                }]
            });
                
            let lineValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceLine(jsonObj["Invoice"][0]["InvoiceLine"][jsonObj["Invoice"][0]["InvoiceLine"].length-1]);
            jsonLineValidatorError += lineValidatorError ? `\nitem line ${i+1} :` + "\n" + Object.keys(lineValidatorError).map(key=>lineValidatorError[key]).join("\n") : '';
        }

        return {
            jsondata : jsonObj,
            jsonBodyValid: jsonBodyValidatorError ? Object.keys(jsonBodyValidatorError).map(key=>jsonBodyValidatorError[key]).join("\n") : '',
            jsonLineValid: jsonLineValidatorError
        };
    }


    /**
    * it will map the Invoice data to json object
    */
    const mapJSONWithVCData = (currRec, jsonObj, tranTypeCode, currentSubId) =>{
        let configSetupSearch = search.create({
            type: 'customrecord_my_einv_con_setup',
            columns: [
                'internalid',
                'custrecord_my_e_inv_clientid',
                'custrecord_my_e_inv_client_secret',
                'custrecord_my_e_inv_client_secret2',
                'custrecord_my_e_invoice_base_url',
                'custrecord_my_e_invoice_subsidiary',
                'custrecord_my_e_inv_tin',
                'custrecord_my_e_inv_brn',
                'custrecord_my_e_inv_tin_autoappreinv'
            ],
            filters: [
                ['custrecord_my_e_invoice_subsidiary','anyof', currentSubId]
            ]
        }).run().getRange(0, 10);
        let datecreated = moment(new Date()).toISOString();
        log.debug("datecreated",datecreated);

        //Scriptable search to fetch all the supplier details
        var multiSubFeature = runtime.isFeatureInEffect({feature:"subsidiaries"});
        var applicableSubId = multiSubFeature ? configSetupSearch[0].getValue('custrecord_my_e_invoice_subsidiary') : 1;
        var suppDetailsObj = _NS_MOD_.getSupplierDetails(applicableSubId, multiSubFeature);
        log.debug("suppDetailsObj",suppDetailsObj);

        //Scriptable search to fetch all the customer details
        let isPerson = search.lookupFields({
            type: search.Type.VENDOR,
            id: currRec.getValue("entity"),
            columns: ["isperson"]
        })['isperson'];
        var customerDetails = _NS_MOD_.getCustomerDetails(currRec, search.Type.VENDOR, isPerson);
        
        //Saved search for pre-payment or deposits
        let dep_index = 0;
        jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["currencyID"] = currRec.getText("currency");
        _NS_MOD_.getDepositDetails(currRec.id).run().each(depr=>{
            let isoDepDateTime = moment(depr.getValue("datecreated")).toISOString().split("T");
            if(dep_index == 0){
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["ID"][0]["_"] = depr.getValue({name:"createdfrom"}) //deposit reference
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["_"] = parseFloat(depr.getValue({name:"fxamount"})) //deposit amount 
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidAmount"][0]["currencyID"] = depr.getText({name:"currency"}) || currRec.getText("currency");
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidDate"][0]["_"] = isoDepDateTime[0]//date
                jsonObj["Invoice"][0]["PrepaidPayment"][0]["PaidTime"][0]["_"] = isoDepDateTime[1]//paid time
            }else{
                jsonObj["Invoice"][0]["PrepaidPayment"].push({
                    "ID":[{
                        "_": depr.getValue({name:"createdfrom"}) //deposit reference
                    }],
                    "PaidAmount":[{
                        "_": parseFloat(depr.getValue({name:"fxamount"})) //deposit amount 
                    }],
                   "PaidAmount":[{
                        "currencyID": depr.getText({name:"currency"}) || currRec.getText("currency")
                   }],
                   "PaidDate":[{
                        "_": isoDepDateTime[0]//date
                   }],
                   "PaidTime":[{
                        "_": isoDepDateTime[1]//paid time
                   }]
                });
            }
        });

        // var custShippingAddress = currRec.getSubrecord({
        //     fieldId: 'shippingaddress'
        // });

        //JSON Object creator as per JSON file sequence
        jsonObj["Invoice"][0]["ID"][0]["_"] = currRec.getValue("transactionnumber");
        jsonObj["Invoice"][0]["IssueDate"][0]["_"] = datecreated.split("T")[0];
        jsonObj["Invoice"][0]["IssueTime"][0]["_"] = datecreated.split("T")[1].split(".")[0]+'Z';
        jsonObj["Invoice"][0]["InvoiceTypeCode"][0]["_"] = tranTypeCode;
        // jsonObj["Invoice"][0]["InvoiceTypeCode"][0]["listVersionID"] = "1.1";
        jsonObj["Invoice"][0]["DocumentCurrencyCode"][0]["_"] = currRec.getValue("currencyname");
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["StartDate"][0]["_"] = currRec.getValue("startdate") ? moment(currRec.getValue("startdate")).format("YYYY-MM-DD") : "";
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["EndDate"][0]["_"] = currRec.getValue("enddate") ? moment(currRec.getValue("enddate")).format("YYYY-MM-DD") : "";
        jsonObj["Invoice"][0]["InvoicePeriod"][0]["Description"][0]["_"] = currRec.getText("custbody_ein_t_frequencyofbilling");

        jsonObj["Invoice"][0]["BillingReference"][1]["InvoiceDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_invoice_doc_no");
        jsonObj["Invoice"][0]["BillingReference"][1]["InvoiceDocumentReference"][0]["UUID"][0]["_"] = currRec.getValue("custbody_ein_t_invoice_uuid");

        jsonObj["Invoice"][0]["BillingReference"][0]["AdditionalDocumentReference"][0]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_billrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][0]["ID"][0]["_"] = "";//currRec.getValue("custbody_t_importedgoodsrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][0]["DocumentType"][0]["_"] = "CustomsImportForm";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_ftanfo") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["DocumentType"][0]["_"] = "FreeTradeAgreement";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][1]["DocumentDescription"][0]["_"] = ""; //currRec.getValue("memo") || "", //need confirmation
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][2]["ID"][0]["_"] = currRec.getValue("custbody_ein_t_exportedgoodsrefno") || "";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][2]["DocumentType"][0]["_"] = "K2";
        jsonObj["Invoice"][0]["AdditionalDocumentReference"][3]["ID"][0]["_"] = currRec.getValue("custbody_abj_incoterm") || "";
        
        //supplier Data as per field mapping sheet
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = isPerson ? customerDetails[0].getValue({name: "altname", label: "Alt Name"}) : customerDetails[0].getValue({name: "companyname", label: "Company Name"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"] = customerDetails[0].getValue({name: "vatregnumber", label: "TIN Reg.no."}); 
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_registrationno", label: "Company Registration no."});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = customerDetails[0].getText({name: "custentity_ein_c_regnotype", label: "Type OF Registration no."});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"] = (customerDetails[0].getValue({name: "email", label: "E-Mail ID"})) ? (customerDetails[0].getValue({name: "email", label: "E-Mail ID"})) : "NA";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"] = (customerDetails[0].getValue({name: "phone", label: "Contact no."})) ? (customerDetails[0].getValue({name: "phone", label: "Contact no."}).replace(/[^\d.-]/g, "")) : "NA";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["_"] = (customerDetails[0].getText("custentity_ein_c_msic")).split("-")[0];
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["name"] = (customerDetails[0].getText("custentity_ein_c_msic")).split("-")[1];
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"] = customerDetails[0].getValue({name: "custentity_ein_c_city"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = customerDetails[0].getValue({name: "zipcode", join: "Address", label: "Zip"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = (customerDetails[0].getText({name:"custentity_ein_c_state"})).split("-")[0];//_NS_MOD_.getStateCode(currRec.getValue("custbody_ein_t_c_state")),
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = customerDetails[0].getValue({name: "addressee", join: "Address", label: "Address Line 0"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = customerDetails[0].getValue({name: "address1", join: "Address", label: "Address Line 1"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = customerDetails[0].getValue({name: "address2", join: "Address", label: "Address Line 2"});
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = (customerDetails[0].getText({name:"custentity_ein_c_country"})).split("-")[0];//_NS_MOD_.getCountryCode(currRec.getValue("custbody_ein_t_c_country")),
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] = "ISO3166-1";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["_"] = currRec.getValue('custbody_ein_t_exporterrefno') || "";
        jsonObj["Invoice"][0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["schemeAgencyName"] = "CertEx";

        //customer Data as per field mapping sheet
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = suppDetailsObj.registor_name;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"] = suppDetailsObj.tin_reg_no;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"] = suppDetailsObj.reg_no;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = suppDetailsObj.type_of_reg;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["_"] = suppDetailsObj.sst_reg_no;//yet to map
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["schemeID"] = "SST";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"] = (suppDetailsObj.email_id) ? suppDetailsObj.email_id : "NA";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"] = (suppDetailsObj.phone) ? suppDetailsObj.phone : "NA";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"] = suppDetailsObj.city;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = suppDetailsObj.zip;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = _NS_MOD_.getStateCode(suppDetailsObj.state),
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = suppDetailsObj.addressee;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = suppDetailsObj.addr1;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = suppDetailsObj.addr2;
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = _NS_MOD_.getCountryCode(suppDetailsObj.country),
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] =  "ISO3166-1";
        jsonObj["Invoice"][0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";

        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"] = suppDetailsObj.registor_name;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["_"] = suppDetailsObj.tin_reg_no;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["schemeID"] = "TIN";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["_"] = suppDetailsObj.reg_no;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["schemeID"] = suppDetailsObj.type_of_reg;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CityName"][0]["_"] = suppDetailsObj.city;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["PostalZone"][0]["_"] = suppDetailsObj.zip;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"] = _NS_MOD_.getStateCode(suppDetailsObj.state),
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"] = suppDetailsObj.addressee;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"] = suppDetailsObj.addr1;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"] = suppDetailsObj.addr2;
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"] = _NS_MOD_.getCountryCode(suppDetailsObj.country),
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"] = "ISO3166-1";
        jsonObj["Invoice"][0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"] = "6";
        //// jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["ChargeIndicator"][0]["_"] = ""; //yet to map
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = "TEST FRIEGHT"; //yet to map
        
        jsonObj["Invoice"][0]["PaymentMeans"][0]["PaymentMeansCode"][0]["_"] = currRec.getText('custbody_ein_t_paymentmode').split("-")[0];
        jsonObj["Invoice"][0]["PaymentMeans"][0]["PayeeFinancialAccount"][0]["ID"][0]["_"] = suppDetailsObj.pri_bank_acc_no;

        var vlookup = search.lookupFields({
            type:"vendor",
            id:currRec.getValue("entity"),
            columns:["terms"]
        });
        jsonObj["Invoice"][0]["PaymentTerms"][0]["Note"][0]["_"] = vlookup["terms"][0].text;

        jsonObj["Invoice"][0]["AllowanceCharge"][0]["ChargeIndicator"][0]["_"] = false;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = "TEST";  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["_"] = 0;//yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["ChargeIndicator"][0]["_"] = true;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["AllowanceChargeReason"][0]["_"] = "TEST"  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["_"] = 0;  //yet to map
        jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["currencyID"] = currRec.getText("currency");  //yet to map

        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxAmount"][0]["_"] = currRec.getValue('taxtotal');
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxableAmount"][0]["_"] = currRec.getValue('taxtotal') ? (currRec.getValue('amount') || 0) : 0;
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxableAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxAmount"][0]["_"] = parseFloat(currRec.getValue('taxtotal') || 0);
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["ID"][0]["_"] = (currRec.getText('custbody_ein_t_taxtype')).split("-")[0];
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["_"] = "OTH"
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["schemeID"] = "UN/ECE 5153";
        jsonObj["Invoice"][0]["TaxTotal"][0]["TaxSubtotal"][0]["TaxCategory"][0]["TaxScheme"][0]["ID"][0]["schemeAgencyID"] = "6"

        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["LineExtensionAmount"][0]["_"] = currRec.getValue('total');
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["LineExtensionAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["_"] = parseFloat(parseFloat(currRec.getValue("usertotal"))) - parseFloat(currRec.getValue('taxtotal')); //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["_"] = parseFloat(currRec.getValue("usertotal")); //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["_"] = parseFloat(currRec.getValue('discounttotal') || 0);
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableRoundingAmount"][0]["_"] = 0; //yet to map
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableRoundingAmount"][0]["currencyID"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["_"] = parseFloat(currRec.getValue("usertotal")); //this is total amount - prepaid amount
        jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["currencyID"] = currRec.getText("currency");

        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["SourceCurrencyCode"][0]["_"] = currRec.getText("currency");
        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["TargetCurrencyCode"][0]["_"] = "MYR";
        jsonObj["Invoice"][0]["TaxExchangeRate"][0]["CalculationRate"][0]["_"] = parseFloat(currRec.getValue("exchangerate") || 0);
        
        let itemCount = currRec.getLineCount('item');

        var jsonBodyValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceBody(jsonObj);
        var jsonLineValidatorError = '';

        //adding the item lines
        for(let i=0; i < itemCount; i++){
            let itemType = currRec.getSublistValue("item","itemtype",i);
            let otherorfee = currRec.getSublistValue("item","custcol_ein_t_fee_charge_rate_yes_no",i);
            if(itemType == "Description")continue;
            if(itemType == "Discount"){
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["ChargeIndicator"][0]["_"] = false; //yet to map
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["AllowanceChargeReason"][0]["_"] = currRec.getSublistValue('item','description',i); //yet to map
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["MultiplierFactorNumeric"][0]["_"] = parseFloat(currRec.getSublistValue('item', 'rate', i) || 0);
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["Amount"][0]["_"] = parseFloat(currRec.getSublistValue('item', 'amount', i) || 0);
                jsonObj["Invoice"][0]["InvoiceLine"][i-1]["AllowanceCharge"][0]["Amount"][0]["currencyID"] = currRec.getText("currency");
                jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["AllowanceTotalAmount"][0]["_"] += parseFloat(parseFloat(currRec.getSublistValue('item', 'amount', i) || 0));
                continue;
            };
            if(otherorfee){
                jsonObj["Invoice"][0]["AllowanceCharge"][0]["Amount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));//yet to map
                jsonObj["Invoice"][0]["LegalMonetaryTotal"][0]["ChargeTotalAmount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));
                jsonObj["Invoice"][0]["AllowanceCharge"][1]["Amount"][0]["_"] += parseFloat(currRec.getSublistValue('item', 'amount', i));
                continue;
            }
            //INVOICE LINE DATA
            jsonObj["Invoice"][0]["InvoiceLine"].push({
                "ID": [{
                    "_": currRec.getSublistValue("item","item_display",i)
                }],
                "InvoicedQuantity": [{
                    "_": currRec.getSublistValue('item', 'quantity', i) || 0,
                    "unitCode": currRec.getSublistValue('item', 'unit', i) || ""
                }],
                "LineExtensionAmount": [{
                    "_": parseFloat(currRec.getSublistValue("item","amount",i) || 0),
                    "currencyID": currRec.getText("currency")
                }],
                "AllowanceCharge": [{
                        "ChargeIndicator": [{
                            "_": false
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0
                        }],
                        "Amount": [{
                            "_": 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    },
                    {
                        "ChargeIndicator": [{
                            "_": true
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0 //yet to map
                        }],
                        "Amount": [{
                            "_": 0,//currRec.getSublistValue('item', 'discountamount', i) || 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    }
                ],
                "TaxTotal": [{
                    "TaxAmount": [{
                        "_": currRec.getSublistValue('item','taxrate1',i) ? (parseFloat(currRec.getSublistValue('item', 'tax1amt', i) || 0)) : 0,
                        "currencyID": currRec.getText("currency")
                    }],
                    "TaxSubtotal": [{
                        "TaxableAmount": [{
                            "_": parseFloat(currRec.getSublistValue('item','amount',i) || 0), //yet to map
                            "currencyID": currRec.getText("currency")
                        }],
                        "TaxAmount": [{
                            "_": parseFloat(currRec.getSublistValue('item', 'tax1amt', i) || 0),
                            "currencyID": currRec.getText("currency")
                        }],
                        "Percent": [{
                            "_": parseFloat(currRec.getSublistValue('item','taxrate1',i) || 0) //yet to map
                        }],
                        "TaxCategory": [{
                            "ID": [{
                                "_": currRec.getSublistValue('item','custcol_ein_t_taxtype',i) ? (currRec.getSublistText('item', 'custcol_ein_t_taxtype', i)).split("-")[0] : ""
                            }],
                            "Percent": [{
                                "_": parseFloat(currRec.getSublistValue('item','taxrate1',i) || 0) // yet to map
                            }],
                            "TaxScheme": [{
                                "ID": [{
                                    "_": "OTH",
                                    "schemeID": "UN/ECE 5153",
                                    "schemeAgencyID": "6"
                                }]
                            }],
                            "TaxExemptionReason": [{
                                "_": currRec.getSublistValue('item','taxrate1',i) ? "NA" : currRec.getSublistValue("item","custcol_ein_t_taxexemptionreason",i) //yet to map
                            }]
                        }]
                    }]
                }],
                "Item": [{
                    "CommodityClassification": [{
                            "ItemClassificationCode": [{
                                "_": currRec.getSublistText('item', 'custcol_ein_t_prodtariffcode', i) || "",
                                "listID": "PTC"
                            }]
                        },
                        {
                            "ItemClassificationCode": [{
                                "_": (currRec.getSublistText('item', 'custcol_ein_t_classification', i)).split('-')[0],
                                "listID": "CLASS"
                            }]
                        }
                    ],
                    "Description": [{
                        "_": currRec.getSublistValue('item', 'description', i) || ""
                    }],
                    "OriginCountry": [{
                        "IdentificationCode": [{
                            "_": currRec.getSublistText('item', 'custcol_ein_t_countryoforigin', i) || ""
                        }]
                    }]
                }],
                "Price": [{
                    "PriceAmount": [{
                        "_": parseFloat(currRec.getSublistValue('item', 'rate', i) || 0),
                        "currencyID": currRec.getText("currency")
                    }]
                }],
                "ItemPriceExtension": [{
                    "Amount": [{
                        "_": parseFloat(currRec.getSublistValue('item', 'amount', i) || 0),
                        "currencyID": currRec.getText("currency")
                    }]
                }]
            });

            let lineValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceLine(jsonObj["Invoice"][0]["InvoiceLine"][jsonObj["Invoice"][0]["InvoiceLine"].length-1]);
            jsonLineValidatorError += lineValidatorError ? `\nitem line ${i+1} :` + "\n" + Object.keys(lineValidatorError).map(key=>lineValidatorError[key]).join("\n") : '';
        }

        //expense lines adding into the invoice lines
        let expenseLineCount = currRec.getLineCount("expense");
        let invoiceLineCountStart = jsonObj["Invoice"][0]["InvoiceLine"].length;
        for(let i = 0; i < expenseLineCount; i++,invoiceLineCountStart++){
            jsonObj["Invoice"][0]["InvoiceLine"].push({
                "ID": [{
                    "_": currRec.getSublistText("expense","category",i)
                }],
                "InvoicedQuantity": [{
                    "_": 1,
                    "unitCode": ""//yet to map
                }],
                "LineExtensionAmount": [{
                    "_": currRec.getSublistValue("expense","amount",i) || 0,
                    "currencyID": currRec.getText("currency")
                }],
                "AllowanceCharge": [{
                        "ChargeIndicator": [{
                            "_": false
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0
                        }],
                        "Amount": [{
                            "_": 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    },
                    {
                        "ChargeIndicator": [{
                            "_": true
                        }],
                        "AllowanceChargeReason": [{
                            "_": "TEST" //yet to map
                        }],
                        "MultiplierFactorNumeric": [{
                            "_": 0 //yet to map
                        }],
                        "Amount": [{
                            "_": 0,//currRec.getSublistValue('item', 'discountamount', i) || 0,
                            "currencyID": currRec.getText("currency")
                        }]
                    }
                ],
                "TaxTotal": [{
                    "TaxAmount": [{
                        "_": currRec.getSublistValue('expense','taxrate1',i) ? (currRec.getSublistValue('expense', 'tax1amt', i) || 0) : 0,
                        "currencyID": currRec.getText("currency")
                    }],
                    "TaxSubtotal": [{
                        "TaxableAmount": [{
                            "_": currRec.getSublistValue('expense','amount',i) || 0, //yet to map
                            "currencyID": currRec.getText("currency")
                        }],
                        "TaxAmount": [{
                            "_": currRec.getSublistValue('expense', 'tax1amt', i) || 0,
                            "currencyID": currRec.getText("currency")
                        }],
                        "Percent": [{
                            "_": parseFloat(currRec.getSublistValue('expense','taxrate1',i) || 0) //yet to map
                        }],
                        "TaxCategory": [{
                            "ID": [{
                                "_": currRec.getSublistValue('expense','custcol_ein_t_taxtype',i) ? (currRec.getSublistText('expense', 'custcol_ein_t_taxtype', i)).split("-")[0] : ""
                            }],
                            "Percent": [{
                                "_": parseFloat(currRec.getSublistValue('expense','taxrate1',i) || 0) // yet to map
                            }],
                            "TaxScheme": [{
                                "ID": [{
                                    "_": "OTH",
                                    "schemeID": "UN/ECE 5153",
                                    "schemeAgencyID": "6"
                                }]
                            }],
                            "TaxExemptionReason": [{
                                "_": currRec.getSublistValue('expense','taxrate1',i) ? "NA" : currRec.getSublistValue("expense","custcol_ein_t_taxexemptionreason",i) //yet to map
                            }]
                        }]
                    }]
                }],
                "Item": [{
                    "CommodityClassification": [{
                            "ItemClassificationCode": [{
                                "_": currRec.getSublistText('expense', 'custcol_ein_t_prodtariffcode', i) || "",
                                "listID": "PTC"
                            }]
                        },
                        {
                            "ItemClassificationCode": [{
                                "_": (currRec.getSublistText('expense', 'custcol_ein_t_classification', i)).split('-')[0],
                                "listID": "CLASS"
                            }]
                        }
                    ],
                    "Description": [{
                        "_": currRec.getSublistValue('expense', 'memo', i) || ""
                    }],
                    "OriginCountry": [{
                        "IdentificationCode": [{
                            "_": currRec.getSublistText('expense', 'custcol_ein_t_countryoforigin', i) || ""
                        }]
                    }]
                }],
                "Price": [{
                    "PriceAmount": [{
                        "_": currRec.getSublistValue('expense', 'amount', i) || 0,
                        "currencyID": currRec.getText("currency")
                    }]
                }],
                "ItemPriceExtension": [{
                    "Amount": [{
                        "_": currRec.getSublistValue('expense', 'amount', i) || 0,
                        "currencyID": currRec.getText("currency")
                    }]
                }]
            });

            let lineValidatorError = _EINV_JSONVALIDATOR_MOD_.validateInvoiceLine(jsonObj["Invoice"][0]["InvoiceLine"][invoiceLineCountStart]);
            jsonLineValidatorError += lineValidatorError ? `\nexpense line ${i+1} :` + "\n" + Object.keys(lineValidatorError).map(key=>lineValidatorError[key]).join("\n") : '';
        }

        return {
            jsondata : jsonObj,
            jsonBodyValid: jsonBodyValidatorError ? Object.keys(jsonBodyValidatorError).map(key=>jsonBodyValidatorError[key]).join("\n") : '',
            jsonLineValid: jsonLineValidatorError
        };
    }
    

    return {
        mapJSONWithINVData: mapJSONWithINVData,
        mapJSONWithVBData: mapJSONWithVBData,
        mapJSONWithEXPData: mapJSONWithEXPData,
        mapJSONWithCHECKData: mapJSONWithCHECKData,
        mapJSONWithCMData: mapJSONWithCMData,
        mapJSONWithVCData: mapJSONWithVCData
    }
    
});