/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
define([
    './validate.js',
    './lodash.js'
], function (validate, _) {

    validate.validators.custom = function(value, options, key, attributes) {
        // log.debug(attributes + " : "  +  key,_.get(attributes, key));
        if((_.get(attributes, key) == 0 || _.get(attributes, key) == false) && (typeof _.get(attributes,key) == 'boolean' || typeof _.get(attributes,key) == 'number')){
            return "";
        }
        
        if(_.get(attributes, key)){
            return ""
        }else{
            return key + " " + options;
        }
      };

    var invoiceContraints = {        
        'Invoice[0]["ID"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["IssueDate"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["IssueTime"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["DocumentCurrencyCode"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["InvoiceTypeCode"][0]["_"]': {
            custom: "should not be empty."
        },
        'Invoice[0]["InvoiceTypeCode"][0]["listVersionID"]': {
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["IndustryClassificationCode"][0]["name"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"]':{
            custom: "should not be empty."
        },
        // 'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"]':{
        //     custom: "should not be empty."
        // },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingSupplierParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"]':{
            custom: "should not be empty."
        },
        // 'Invoice[0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["_"]':{
        //     custom: "should not be empty."
        // },
        'Invoice[0]["AccountingSupplierParty"][0]["AdditionalAccountID"][0]["schemeAgencyName"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][0]["ID"][0]["schemeID"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][1]["ID"][0]["schemeID"]':{
            custom: "should not be empty."
        },
        // 'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["_"]':{
        //     custom: "should not be empty."
        // },
        // 'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PartyIdentification"][2]["ID"][0]["schemeID"]':{
        //     custom: "should not be empty."
        // },
        'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["ElectronicMail"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["Contact"][0]["Telephone"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CityName"][0]["_"]':{
            custom: "should not be empty."
        },
        // 'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["PostalZone"][0]["_"]':{
        //     custom: "should not be empty."
        // },
        'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"]':{
            custom: "should not be empty."
        },
        // 'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"]':{
        //     custom: "should not be empty."
        // },
        // 'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"]':{
        //     custom: "should not be empty."
        // },
        'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["AccountingCustomerParty"][0]["Party"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PartyLegalEntity"][0]["RegistrationName"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][0]["ID"][0]["schemeID"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PartyIdentification"][1]["ID"][0]["schemeID"]':{
            custom: "should not be empty."
        },
        // 'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CityName"][0]["_"]':{
        //     custom: "should not be empty."
        // },
        // 'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["PostalZone"][0]["_"]':{
        //     custom: "should not be empty."
        // },
        'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["CountrySubentityCode"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][0]["Line"][0]["_"]':{
            custom: "should not be empty."
        },
        // 'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][1]["Line"][0]["_"]':{
        //     custom: "should not be empty."
        // },
        // 'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["AddressLine"][2]["Line"][0]["_"]':{
        //     custom: "should not be empty."
        // },
        'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listID"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["Delivery"][0]["DeliveryParty"][0]["PostalAddress"][0]["Country"][0]["IdentificationCode"][0]["listAgencyID"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["ChargeIndicator"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["Amount"][0]["currencyID"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["Delivery"][0]["Shipment"][0]["FreightAllowanceCharge"][0]["AllowanceChargeReason"][0]["_"]':{
            custom: "should not be empty."
        },

        // 'LegalMonetaryTotal[0]["LineExtensionAmount"][0]["_"]':{
        //     presence: {
        //         allowEmpty: false,
        //         message: 'LegalMonetaryTotal[0]["LineExtensionAmount"][0]["_"] should not be empty.'
        //     }
        // },
        // 'LegalMonetaryTotal[0]["LineExtensionAmount"][0]["currencyID"]':{
        //     presence: {
        //         allowEmpty: false,
        //         message: 'LegalMonetaryTotal[0]["LineExtensionAmount"][0]["currencyID"] should not be empty.'
        //     }
        // },
        'Invoice[0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["LegalMonetaryTotal"][0]["TaxExclusiveAmount"][0]["currencyID"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["LegalMonetaryTotal"][0]["TaxInclusiveAmount"][0]["currencyID"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["_"]':{
            custom: "should not be empty."
        },
        'Invoice[0]["LegalMonetaryTotal"][0]["PayableAmount"][0]["currencyID"]':{
            custom: "should not be empty."
        }
    }

    var invoiceLineConstraints = {

        // '["Item"][0]["CommodityClassification"][0]["ItemClassificationCode"][0]["_"]':{
        //     custom: "should not be empty."
        // },
        // '["Item"][0]["CommodityClassification"][0]["ItemClassificationCode"][0]["listID"]':{
        //     custom: "should not be empty."
        // },
        '["Item"][0]["CommodityClassification"][1]["ItemClassificationCode"][0]["_"]':{
            custom: "should not be empty."
        },
        '["Item"][0]["CommodityClassification"][1]["ItemClassificationCode"][0]["listID"]':{
            custom: "should not be empty."
        },
        '["Item"][0]["Description"][0]["_"]':{
            custom: "should not be empty."
        },
        '["Price"][0]["PriceAmount"][0]["_"]':{
            custom: "should not be empty."
        },
        '["Price"][0]["PriceAmount"][0]["currencyID"]':{
            custom: "should not be empty."
        },
        '["ItemPriceExtension"][0]["Amount"][0]["_"]':{
            custom: "should not be empty."
        },
        '["ItemPriceExtension"][0]["Amount"][0]["currencyID"]':{
            custom: "should not be empty."
        }
    }

    const validateInvoiceBody = (invBody) => {
        return validate(invBody, invoiceContraints,{fullMessages:false});
    }

    const validateInvoiceLine = (invLine) => {
        return validate(invLine, invoiceLineConstraints,{fullMessages:false});
    }

    return {
        validateInvoiceBody: validateInvoiceBody,
        validateInvoiceLine: validateInvoiceLine
    }

});