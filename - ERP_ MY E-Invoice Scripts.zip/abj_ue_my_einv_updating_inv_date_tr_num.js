/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/*******************************************************************************
 * **Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 * @Client        :  SRI E-Invoice
 * @Script File   :  abj_ue_my_einv_updating_inv_date_tr_num.js 
 * @script Record : - EINV UE | E-Invoice Update Date&Tranid
 * @Trigger Type  : afterSubmit
 * @Release Date  :  25/07/2024
 * @Author        :  SIRUSOLLA NAGARJUNA
 * @Description   :  This script is used  to Update  Created Date&Time and Transaction number to invoice,creditmemo,vendorcredit,vendorbill,check,expensereport after saving record.
 * @Deployment To:  invoice,creditmemo,vendorcredit,vendorbill,check,expensereport
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @Ticket_id : TECH-181
 *
 ******************************************************************************/
define(['N/record', 'N/runtime', 'N/search', 'N/runtime'], function (record, runtime, search, runtime) {
    function afterSubmit(context) {
        var newRecord = context.newRecord;
        var validTypes = ["invoice", "creditmemo", "vendorbill", "vendorcredit", "check", "expensereport"];
        try {
            if (context.type === context.UserEventType.CREATE && validTypes.includes(newRecord.type)) {
                var currentDate = new Date();
                log.debug("Record Created Date :", currentDate);
                var rec = record.load({
                    type: newRecord.type,
                    id: newRecord.id
                })
                rec.setValue({
                    fieldId: "custbody_ein_t_time",
                    value: currentDate
                });
                var tranid;
                // if (rec.type === "vendorbill" || rec.type === "vendorcredit" || rec.type === "check") {
                if (rec.type === "vendorbill") {
                    tranid = rec.getValue({
                        fieldId: "transactionnumber"
                    });
                } else {
                    tranid = rec.getValue({
                        fieldId: "tranid"
                    });
                }
                log.debug("tranid", tranid);
                rec.setValue({
                    fieldId: "custbody_ein_t_billrefno",
                    value: tranid
                });
                var saved = rec.save();
                log.debug("Record saved with ID:", saved);
            }
            logRemainingUsage();
        } catch (e) {
            log.error(e.name, e.message);
        }
    }

    function logRemainingUsage() {
        var scriptObj = runtime.getCurrentScript();
        var remainingUsage = scriptObj.getRemainingUsage();
        var totalUnits = 1000;
        log.debug("Current script consuming units: ", totalUnits - remainingUsage);
    }
    return {
        afterSubmit: afterSubmit
    };
});