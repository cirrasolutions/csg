/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
define([
    'N/record',
    'N/search',
    'N/https',
    'N/encode',
    'N/file',
    './crypto.min.js',
    './moment_timezone.js',
    './abj_my_einv_ubl_json.js',
    './lodash.js',
    './jsbi.min.js'
], function (record, search, https, encode, file, CryptoJS, moment_timezone, _EINV_UBL_, _, JSBI) {

    const sha256String = "5m4kwln2x5j1fpw94myf0r7d3";

    getConfigSetup = (subsId) => {
        let configFil = [];
        if (subsId) {
            configFil.push(["custrecord_my_e_invoice_subsidiary", "is", subsId]);
        }
        var configSetupSearch = search.create({
            type: 'customrecord_my_einv_con_setup',
            columns: [
                'internalid',
                'custrecord_my_e_inv_clientid',
                'custrecord_my_e_inv_client_secret',
                'custrecord_my_e_inv_client_secret2',
                'custrecord_my_e_invoice_base_url',
                'custrecord_my_e_invoice_subsidiary',
                'custrecord_my_e_inv_tin',
                'custrecord_my_e_inv_brn'
            ],
            filters: configFil
        }).run().getRange(0, 1);

        return configSetupSearch;
    }

    encryptAPIToken = (access_token) => {
        let encrypted_token = CryptoJS.AES.encrypt(access_token, sha256String).toString();
        return encrypted_token;
    }

    decryptAPIToken = (encryptedtoken) => {
        let decrypted_token = CryptoJS.AES.decrypt(encryptedtoken, sha256String).toString(CryptoJS.enc.Utf8);
        return decrypted_token;
    }

    // getAccessToken = (deploymentId) => {
    //     let configSetupSearch = this.getConfigSetup();
    //     let client_id = configSetupSearch[0].getValue("custrecord_my_e_inv_clientid");
    //     let client_secret = configSetupSearch[0].getValue("custrecord_my_e_inv_client_secret");
    //     let baseurl = configSetupSearch[0].getValue('custrecord_my_e_invoice_base_url');
    //     const urlencoded = `client_id=${client_id}&client_secret=${client_secret}&grant_type=client_credentials&scope=InvoicingAPI`;

    //     /*** getting the token custom record search and checking wether token remaining time more than 10 minutes */
    //     var tokenCustomRecSearch = search.create({
    //         type: "customrecord_my_einv_access_tkn_hldr",
    //         columns: ["internalid", "custrecord_my_einv_access_tkn_sttime", "custrecord_my_einv_acc_tkn_code"],
    //         filters: [
    //             // ["custrecord_my_einv_access_tkn_deply", "is", deploymentId],
    //             // "AND",
    //             ["isinactive", "is", false]
    //         ]
    //     }).run().getRange(0, 1);

    //     var diffMinutes = 0;
    //     if (tokenCustomRecSearch.length > 0) {
    //         let startTime = moment_timezone(tokenCustomRecSearch[0].getValue("custrecord_my_einv_access_tkn_sttime")).tz("Asia/Kuala_Lumpur");
    //         let endTime = moment_timezone().tz("Asia/Kuala_Lumpur");
    //         diffMinutes = endTime.diff(startTime, 'minutes');
    //     }

    //     log.debug("deployment ID " + deploymentId, "diff in minutes " + diffMinutes);

    //     if (tokenCustomRecSearch.length > 0 && diffMinutes < 50) {
    //         return this.decryptAPIToken(tokenCustomRecSearch[0].getValue("custrecord_my_einv_acc_tkn_code"));
    //     } else {
    //         let response = https.post({
    //             url: `https://${baseurl}/connect/token`,
    //             headers: {
    //                 "Content-Type": "application/x-www-form-urlencoded",
    //                 "Accept": "*/*"
    //             },
    //             body: urlencoded
    //         });

    //         if (response.code == 200) {
    //             log.debug("response", response);
    //             let responseBody = JSON.parse(response.body);
    //             /** creating the custom record which can hold the access token per script */
    //             let encryptedToken = this.encryptAPIToken(responseBody.access_token);
    //             let token_start_time = moment_timezone().tz("Asia/Kuala_Lumpur").format();

    //             // var scriptSearch = search.create({
    //             //     type: search.Type.SCRIPT_DEPLOYMENT,
    //             //     columns: ["internalid", "script.internalid"],
    //             //     filters: [
    //             //         ["scriptid", "is", deploymentId]
    //             //     ]
    //             // }).run().getRange(0, 1);

    //             log.audit("encryptedToken",encryptedToken);

    //             if (tokenCustomRecSearch.length > 0) {
    //                 try{
    //                     record.submitFields({
    //                         type: "customrecord_my_einv_access_tkn_hldr",
    //                         id: tokenCustomRecSearch[0].getValue("internalid"),
    //                         values: {
    //                             "custrecord_my_einv_acc_tkn_code": encryptedToken,
    //                             "custrecord_my_einv_access_tkn_deply": deploymentId,
    //                             // "custrecord_my_einv_acc_tkn_script": scriptSearch[0].getValue({
    //                             //     name: "internalid",
    //                             //     join: "script"
    //                             // }),
    //                             "custrecord_my_einv_access_tkn_sttime": token_start_time
    //                         },
    //                         options: {
    //                             enablesourcing: false,
    //                             ignoreMandatoryFields: true
    //                         }
    //                     });
    //                 }catch(ex){
    //                     if(ex.name == "RCRD_HAS_BEEN_CHANGED"){
    //                         var tokenCustomRecSearch = search.create({
    //                             type: "customrecord_my_einv_access_tkn_hldr",
    //                             columns: ["internalid", "custrecord_my_einv_access_tkn_sttime", "custrecord_my_einv_acc_tkn_code"],
    //                             filters: [
    //                                 // ["custrecord_my_einv_access_tkn_deply", "is", deploymentId],
    //                                 // "AND",
    //                                 ["isinactive", "is", false]
    //                             ]
    //                         }).run().getRange(0, 1);
    //                         return this.decryptAPIToken(tokenCustomRecSearch[0].getValue("custrecord_my_einv_acc_tkn_code"));
    //                     }
    //                 }
    //             } else {
    //                 record.create({
    //                     type: "customrecord_my_einv_access_tkn_hldr"
    //                 }).setValue({
    //                     fieldId: "custrecord_my_einv_acc_tkn_code",
    //                     value: encryptedToken
    //                 }).setValue({
    //                     fieldId: "custrecord_my_einv_access_tkn_deply",
    //                     value: deploymentId
    //                 }).setValue({
    //                     fieldId: "custrecord_my_einv_access_tkn_sttime",
    //                     value: token_start_time
    //                 }).save({
    //                     enablesourcing: false,
    //                     ignoreMandatoryFields: true
    //                 });

    //                 // .setValue({
    //                 //     fieldId: "custrecord_my_einv_acc_tkn_script",
    //                 //     value: scriptSearch[0].getValue({
    //                 //         name: "internalid",
    //                 //         join: "script"
    //                 //     })
    //                 // })
    //             }

    //             return responseBody.access_token;

    //         } else {
    //             throw Error(response);
    //         }
    //     }
    // }

    getAccessToken = (deploymentId, subsId) => {
        let configSetupSearch = this.getConfigSetup();
        let client_id = configSetupSearch[0].getValue("custrecord_my_e_inv_clientid");
        let client_secret = configSetupSearch[0].getValue("custrecord_my_e_inv_client_secret");
        let baseurl = configSetupSearch[0].getValue('custrecord_my_e_invoice_base_url');
        const urlencoded = `client_id=${client_id}&client_secret=${client_secret}&grant_type=client_credentials&scope=InvoicingAPI`;

        /*** getting the token custom record search and checking wether token remaining time more than 10 minutes */
        var tokenCustomRecSearch = search.create({
            type: "customrecord_my_einv_access_tkn_hldr",
            columns: ["internalid", "custrecord_my_einv_access_tkn_sttime", "custrecord_my_einv_acc_tkn_code"],
            filters: [
                ["custrecord_my_einv_access_tkn_deply", "is", deploymentId],
                "AND",
                ["isinactive", "is", false]
            ]
        }).run().getRange(0, 1);

        var diffMinutes = 0;
        if (tokenCustomRecSearch.length > 0) {
            let startTime = moment_timezone(tokenCustomRecSearch[0].getValue("custrecord_my_einv_access_tkn_sttime")).tz("Asia/Kuala_Lumpur");
            let endTime = moment_timezone().tz("Asia/Kuala_Lumpur");
            diffMinutes = endTime.diff(startTime, 'minutes');
        }

        log.debug("deployment ID " + deploymentId, "diff in minutes " + diffMinutes);

        if (tokenCustomRecSearch.length > 0 && diffMinutes < 50) {
            return this.decryptAPIToken(tokenCustomRecSearch[0].getValue("custrecord_my_einv_acc_tkn_code"));
        } else {
            let response = https.post({
                url: `https://${baseurl}/connect/token`,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Accept": "*/*"
                },
                body: urlencoded
            });

            log.debug("response", response);

            if (response.code == 200) {
                let responseBody = JSON.parse(response.body);
                /** creating the custom record which can hold the access token per script */
                let encryptedToken = this.encryptAPIToken(responseBody.access_token);
                let token_start_time = moment_timezone().tz("Asia/Kuala_Lumpur").format();

                var scriptSearch = search.create({
                    type: search.Type.SCRIPT_DEPLOYMENT,
                    columns: ["internalid", "script.internalid"],
                    filters: [
                        ["scriptid", "is", deploymentId]
                    ]
                }).run().getRange(0, 1);

                log.audit("encryptedToken", encryptedToken);

                if (tokenCustomRecSearch.length > 0) {
                    record.submitFields({
                        type: "customrecord_my_einv_access_tkn_hldr",
                        id: tokenCustomRecSearch[0].getValue("internalid"),
                        values: {
                            "custrecord_my_einv_acc_tkn_code": encryptedToken,
                            "custrecord_my_einv_access_tkn_deply": deploymentId,
                            "custrecord_my_einv_acc_tkn_script": scriptSearch[0].getValue({
                                name: "internalid",
                                join: "script"
                            }),
                            "custrecord_my_einv_access_tkn_sttime": token_start_time
                        },
                        options: {
                            enablesourcing: false,
                            ignoreMandatoryFields: true
                        }
                    });
                } else {
                    record.create({
                        type: "customrecord_my_einv_access_tkn_hldr"
                    }).setValue({
                        fieldId: "custrecord_my_einv_acc_tkn_code",
                        value: encryptedToken
                    }).setValue({
                        fieldId: "custrecord_my_einv_access_tkn_deply",
                        value: deploymentId
                    }).setValue({
                        fieldId: "custrecord_my_einv_acc_tkn_script",
                        value: scriptSearch[0].getValue({
                            name: "internalid",
                            join: "script"
                        })
                    }).setValue({
                        fieldId: "custrecord_my_einv_access_tkn_sttime",
                        value: token_start_time
                    }).save({
                        enablesourcing: false,
                        ignoreMandatoryFields: true
                    });


                }
                return responseBody.access_token;
            } else {
                throw Error(response);
            }
        }
    }

    submitDocuments = (parsedReduceData, deploymentId, subsId) => {
        let configSetupSearch = this.getConfigSetup(subsId);
        var einvoiceData = {
            "documents": []
        };
        let digitCertSearch = search.create({
            type: "customrecord_my_einv_digital_cert",
            columns: [
                "custrecord_my_einv_dc_certificate_key",
                "custrecord_my_einv_dc_private_key", 
                "custrecord_my_einv_dc_digi_cert",
                "custrecord_my_einv_dc_cert_dig_val",
                "custrecord_my_einv_subjname",
                "custrecord_my_einv_issuer_name",
                "custrecord_my_einv_dc_digi_cert_serial"
            ],
            filters: []
        }).run().getRange(0, 1);
        parsedReduceData.forEach(obj => {
            log.debug("obj",obj);
            let fileObj = file.load(obj.file_id);
            let parsedData = JSON.parse(fileObj.getContents());
            let invoiceStringData = JSON.stringify(parsedData);
            let signatureValue = obj.sig_val;
            let jsonDataWithSign;
            if (parsedData["Invoice"][0]["InvoiceTypeCode"][0]["listVersionID"] == "1.1") {
                let signatureJSON = _EINV_UBL_.getDigiCertJSON();
                let signProps = signatureJSON["UBLExtensions"][0]["UBLExtension"][0]["ExtensionContent"][0]["UBLDocumentSignatures"][0]["SignatureInformation"][0]["Signature"][0]["Object"][0]["QualifyingProperties"][0];                
                
                //setting the serial number
                let certSerialNumber = JSBI.BigInt('0x'+digitCertSearch[0].getValue("custrecord_my_einv_dc_digi_cert_serial")).toString();
                signatureJSON["UBLExtensions"][0]["UBLExtension"][0]["ExtensionContent"][0]["UBLDocumentSignatures"][0]["SignatureInformation"][0]["Signature"][0]["KeyInfo"][0]["X509Data"][0]["X509IssuerSerial"][0]["X509SerialNumber"][0]["_"] = certSerialNumber;
                signProps["SignedProperties"][0]["SignedSignatureProperties"][0]["SigningCertificate"][0]["Cert"][0]["IssuerSerial"][0]["X509SerialNumber"][0]["_"] = certSerialNumber;

                //setting the docDigest, signProDigest and singnature Value for document signature validation
                let { docDigestValue, signPropDigestValue } = signInvHashWithSignCertPrivateKey(invoiceStringData, signProps, digitCertSearch);
                log.debug("docDigestValue", docDigestValue);
                log.debug("signatureValue", signatureValue);
                log.debug("signPropDigestValue", signPropDigestValue);
                var k = digitCertSearch[0].getValue("custrecord_my_einv_dc_certificate_key").split("\r\n");
                k.shift();
                k.pop();
                signatureJSON["UBLExtensions"][0]["UBLExtension"][0]["ExtensionContent"][0]["UBLDocumentSignatures"][0]["SignatureInformation"][0]["Signature"][0]["SignatureValue"][0]["_"] = signatureValue;
                signatureJSON["UBLExtensions"][0]["UBLExtension"][0]["ExtensionContent"][0]["UBLDocumentSignatures"][0]["SignatureInformation"][0]["Signature"][0]["SignedInfo"][0]["Reference"][0]["DigestValue"][0]["_"] = signPropDigestValue;
                signatureJSON["UBLExtensions"][0]["UBLExtension"][0]["ExtensionContent"][0]["UBLDocumentSignatures"][0]["SignatureInformation"][0]["Signature"][0]["SignedInfo"][0]["Reference"][1]["DigestValue"][0]["_"] = docDigestValue;
                signatureJSON["UBLExtensions"][0]["UBLExtension"][0]["ExtensionContent"][0]["UBLDocumentSignatures"][0]["SignatureInformation"][0]["Signature"][0]["KeyInfo"][0]["X509Data"][0]["X509Certificate"][0]["_"] = k.join("");
                signatureJSON["UBLExtensions"][0]["UBLExtension"][0]["ExtensionContent"][0]["UBLDocumentSignatures"][0]["SignatureInformation"][0]["Signature"][0]["KeyInfo"][0]["X509Data"][0]["X509SubjectName"][0]["_"] = digitCertSearch[0].getValue("custrecord_my_einv_subjname");
                signatureJSON["UBLExtensions"][0]["UBLExtension"][0]["ExtensionContent"][0]["UBLDocumentSignatures"][0]["SignatureInformation"][0]["Signature"][0]["KeyInfo"][0]["X509Data"][0]["X509IssuerSerial"][0]["X509IssuerName"][0]["_"] = digitCertSearch[0].getValue("custrecord_my_einv_issuer_name");

                _.assignIn(parsedData["Invoice"][0], signatureJSON);

                jsonDataWithSign = JSON.stringify(parsedData);
            } else {
                jsonDataWithSign = invoiceStringData;
            }

            var base64Code = encode.convert({
                string: jsonDataWithSign,
                inputEncoding: encode.Encoding.UTF_8,
                outputEncoding: encode.Encoding.BASE_64
            });
            log.debug("base64Code",base64Code);
            file.create({
                fileType: file.Type.PLAINTEXT,
                name: "test_json_with_sig.json",
                contents: JSON.stringify(jsonDataWithSign, null, 2),
                folder: -15
            }).save();
            einvoiceData["documents"].push({
                "format": "JSON",
                "documentHash": CryptoJS.SHA256(jsonDataWithSign).toString(CryptoJS.enc.Hex),
                "codeNumber": obj.inv_doc,
                "document": base64Code
            });
        });

        let access_token = this.getAccessToken(deploymentId, subsId);

        log.debug("deployemnt ID " + deploymentId, access_token);

        log.debug("einvoiceData", einvoiceData);
        var postDocumentResponse = https.post({
            url: `https://${configSetupSearch[0].getValue("custrecord_my_e_invoice_base_url")}/api/v1.0/documentsubmissions`,
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*",
                "Authorization": `Bearer ${access_token}`
            },
            body: JSON.stringify(einvoiceData)
        });

        return postDocumentResponse;
    }

    getSubmission = (submissionUid, deploymentId, subsId) => {
        let configSetupSearch = this.getConfigSetup(subsId);
        let access_token = this.getAccessToken(deploymentId, subsId);
        let submissionRes = https.get({
            url: `https://${configSetupSearch[0].getValue("custrecord_my_e_invoice_base_url")}/api/v1.0/documentsubmissions/${submissionUid}?pageNo=1&pageSize=55`,
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*",
                "Authorization": `Bearer ${access_token}`
            }
        });
        log.debug("submissionRes", submissionRes);
        let submissionBody = submissionRes.body;
        if(submissionRes.code == "503")
            submissionBody = "503 Service Temporarily Unavailable";
        else if(submissionRes.code == "502")
            submissionBody = "502 Bad Gateway";
        else
            submissionBody = JSON.parse(submissionRes.body);
        return {
            code: submissionRes.code,
            body: submissionBody
        };
    }

    getDocumentDetails = (uuid, deploymentId, subsId) => {
        let configSetupSearch = this.getConfigSetup(subsId);
        let access_token = this.getAccessToken(deploymentId, subsId);
        let submissionRes = https.get({
            url: `https://${configSetupSearch[0].getValue("custrecord_my_e_invoice_base_url")}/api/v1.0/documents/${uuid}/details`,
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*",
                "Authorization": `Bearer ${access_token}`
            }
        });
        log.debug("submissionRes", submissionRes);
        let submissionBody = submissionRes.body;
        if(submissionRes.code == "503")
            submissionBody = "503 Service Temporarily Unavailable";
        else if(submissionRes.code == "502")
            submissionBody = "502 Bad Gateway";
        else
            submissionBody = JSON.parse(submissionRes.body);
        return {
            code: submissionRes.code,
            body: submissionBody
        };
    }

    cancelOrRejectDocument = (uuid, deploymentId, status, reason, recid, subsId) => {
        let configSetupSearch = this.getConfigSetup(subsId);
        let access_token = this.getAccessToken(deploymentId, subsId);
        let submissionRes = https.put({
            url: `https://${configSetupSearch[0].getValue("custrecord_my_e_invoice_base_url")}/api/v1.0/documents/state/${uuid}/state`,
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*",
                "Authorization": `Bearer ${access_token}`
            },
            body: JSON.stringify({
                status: status,
                reason: reason
            })
        });

        if (submissionRes.code == 200) {
            record.submitFields({
                type: "customrecord_my_einv_tax_data",
                id: recid,
                values: {
                    custrecord_my_e_inv_doc_status: JSON.parse(submissionRes.body).status
                },
                options: {
                    enablesourcing: false,
                    ignoreMandatoryFields: true
                }
            });
        }

        let submissionBody = submissionRes.body;
        if(submissionRes.code == "503")
            submissionBody = "503 Service Temporarily Unavailable";
        else if(submissionRes.code == "502")
            submissionBody = "502 Bad Gateway";
        else
            submissionBody = JSON.parse(submissionRes.body);

        return {
            code: submissionRes.code,
            body: submissionBody
        };
    }

    /**
     * 
     * @param {*} canonicalizedINVBody 
     * @returns 
     * @description Hash the canonicalized document invoice body using SHA-256.
        Use a HEX-to-Base64 encoder to encode the hashed value and convert it to base 64.
     */
    const getHashCanonicalizedInvUsingSha256 = (canonicalizedINVBody) => {
        const hash = CryptoJS.SHA256(canonicalizedINVBody);
        const docDigestValue = hash.toString(CryptoJS.enc.Base64);
        return docDigestValue;
    }

    const signInvHashWithSignCertPrivateKey = (canonicalizedINVBody, signProps, digitCertSearch) => {
        log.debug("signProps", signProps);
        let docDigestValue = getHashCanonicalizedInvUsingSha256(canonicalizedINVBody);

        let certDigestValue = digitCertSearch[0].getValue("custrecord_my_einv_dc_cert_dig_val");
        let isoDepDateTime = moment_timezone().toISOString();
        signProps["SignedProperties"][0]["SignedSignatureProperties"][0]["SigningTime"][0]["_"] = isoDepDateTime.split("T")[0] + "T" + isoDepDateTime.split("T")[1].split(".")[0] + 'Z';
        signProps["SignedProperties"][0]["SignedSignatureProperties"][0]["SigningCertificate"][0]["Cert"][0]["CertDigest"][0]["DigestValue"][0]["_"] = certDigestValue;
        signProps["SignedProperties"][0]["SignedSignatureProperties"][0]["SigningCertificate"][0]["Cert"][0]["IssuerSerial"][0]["X509IssuerName"][0]["_"] = digitCertSearch[0].getValue("custrecord_my_einv_issuer_name");
        const hash = CryptoJS.SHA256(JSON.stringify(signProps));
        const signPropDigestValue = hash.toString(CryptoJS.enc.Base64);
        return {
            docDigestValue: docDigestValue,
            signPropDigestValue: signPropDigestValue
        }
    }


    return {
        getAccessToken: getAccessToken,
        submitDocuments: submitDocuments,
        getSubmission: getSubmission,
        getDocumentDetails: getDocumentDetails,
        cancelOrRejectDocument: cancelOrRejectDocument
    }

});