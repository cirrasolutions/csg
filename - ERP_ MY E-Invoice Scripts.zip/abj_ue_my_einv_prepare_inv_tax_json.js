/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Task          Date                Author                                         Remarks
 * MY E-Invoice 29th Apr 2024   sayyad@abjcloudsolutions.com              
 */
define(['N/record',
        'N/file',
        'N/runtime',
        'N/search',
        'N/url',
        './abj_my_einv_ubl_json.js',
        './abj_my_einv_transaction_mapping_module.js',
        './node-forge.js'
    ],

    function (record, file, runtime, search, url, _EINV_UBL_, _EINV_MAP_MOD_, forge) {


        function beforeLoad(context) {
            try {
                if (context.type == "view") {
                    var jsonHolderSearch = search.create({
                        type: 'customrecord_my_einv_tax_data',
                        columns: [
                            'internalid',
                            'custrecord_my_e_inv_doc_status'
                        ],
                        filters: [
                            ['custrecord_my_e_inv_linked_rec', 'anyof', context.newRecord.id],'AND',
                            ['isinactive','is',false]
                        ]
                    }).run().getRange(0, 1);
                    // var jsonCreated = context.newRecord.getValue('custbody_my_e_inv_create_data');
                    // if(!jsonCreated && configSearch.length > 0 && !configSearch[0].getValue("custrecord_my_e_inv_tin_autojsonhold")){
                    var suiteletURL = url.resolveScript({
                        deploymentId: "customdeploy_su_einv_gen_json_holder",
                        scriptId: "customscript_su_einv_gen_json_holder",
                        params: {
                            custom_tranid: context.newRecord.id,
                            custom_trantype: context.newRecord.type
                        }
                    });

                    var tranSearch = search.create({
                        type: search.Type.TRANSACTION,
                        columns: ['posting'],
                        filters: [
                            ["internalid", "anyof", context.newRecord.id], "AND", ["mainline", "is", true]
                        ]
                    }).run().getRange(0, 10);

                    var isJSONAlreadyCreated = jsonHolderSearch.length > 0;

                    if (tranSearch[0].getValue("posting") && ((jsonHolderSearch.length > 0 && jsonHolderSearch[0].getValue("custrecord_my_e_inv_doc_status") == "Invalid") || jsonHolderSearch.length <= 0)) {
                        context.form.addButton({
                            id: "custpage_create_json_holder",
                            label: "Generate E-Invoice JSON Holder",
                            functionName: `require(['N/ui/dialog'],function(dialog){
                                    var isJSONExist = ${isJSONAlreadyCreated};
                                    let dialogOpt = {
                                    title:"Alert",
                                    message: isJSONExist ? "Do you want to overwrite the E-Invoice JSON File?" : "Do you want to generate the E-invoice JSON File?",
                                    buttons:[
                                        {label:"Ok", value:1},
                                        {label:"Cancel",value:2}
                                    ]
                                    }   
                                    dialog.create(dialogOpt).then(function(result){
                                        if(result == 1)
                                        window.location.href = '${suiteletURL}'
                                    }).catch(function(reason){
                                        console.log(reason);
                                    });
                                })`
                        });
                    }
                }
                // }
            } catch (ex) {
                log.error("Before Load error : " + ex.name, ex);
            }
        }

        function afterSubmit(context) {
            try {
                var scriptObj = runtime.getCurrentScript();
                var multiSubFeature = runtime.isFeatureInEffect({
                    feature: "subsidiaries"
                });
                var currentSubId = multiSubFeature ? context.newRecord.getValue('subsidiary') : 1;
                if (context.newRecord.getValue("custbody_my_e_inv_json_file_gerror")) return;
                var oldCreateEINVData = context.oldRecord ? context.oldRecord.getValue("custbody_my_e_inv_create_data") : undefined;
                var newCreateEINVData = context.newRecord.getValue("custbody_my_e_inv_create_data");
                log.debug("!oldCreateEINVData && newCreateEINVData", !oldCreateEINVData && newCreateEINVData);

                var configSearch = search.create({
                    type: 'customrecord_my_einv_con_setup',
                    columns: [
                        'internalid',
                        'custrecord_my_e_inv_tin_autojsonhold',
                        'custrecord_my_e_inv_tin_autoappreinv'
                    ],
                    filters: [
                        ['custrecord_my_e_invoice_subsidiary', 'anyof', currentSubId]
                    ]
                }).run().getRange(0, 1);

                var existingJSONRecSearch = search.create({
                    type: "customrecord_my_einv_tax_data",
                    columns: ["internalid"],
                    filters: [
                        ["custrecord_my_e_inv_linked_rec", "anyof", context.newRecord.id], "AND",
                        [
                            ["custrecord_my_e_inv_apprvd_for_einv", "is", true], "OR", ["custrecord_my_e_inv_apprvd_for_einv", "is", false]
                        ], "AND",
                        ["custrecord_my_e_inv_submted_to_einv", "is", false],
                        "AND",
                        ["isinactive", "is", false]
                    ]
                }).run().getRange(0, 1);

                var existingJSONRecId = existingJSONRecSearch.length > 0 ? existingJSONRecSearch[0].getValue("internalid") : undefined;

                let currRec = record.load({
                    type: context.newRecord.type,
                    id: context.newRecord.id
                });

                var tranSearch = search.create({
                    type: search.Type.TRANSACTION,
                    columns: ['posting'],
                    filters: [
                        ["internalid", "anyof", context.newRecord.id], "AND", ["mainline", "is", true]
                    ]
                }).run().getRange(0, 10);

                log.debug("record type : " + context.newRecord.type, currRec.getValue("status"));
                var statusisOpen = false;
                switch (context.newRecord.type) {
                    case "invoice":
                    case "expensereport":
                    case "vendorbill":
                    case "check":
                    case "creditmemo":
                    case "vendorcredit":
                        statusisOpen = tranSearch[0].getValue('posting');
                        break;
                    // case "invoice":
                    //     statusisOpen = tranSearch[0].getValue('posting');//currRec.getValue("status") == "Open";
                    //     break;
                    // case "expensereport":
                    //     statusisOpen = tranSearch[0].getValue('posting');//currRec.getValue("status") == "Approved by Accounting";
                    //     break;
                    // case "vendorbill":
                    //     statusisOpen = tranSearch[0].getValue('posting');//currRec.getValue("status") == "Open";
                    //     break;
                    // case "check":
                    //     statusisOpen = true;
                    //     break;
                    // case "creditmemo":
                    //     statusisOpen = tranSearch[0].getValue('posting');//currRec.getValue("status") == "Open";
                    //     break;
                    // case "vendorcredit":
                    //     statusisOpen = true;
                    //     break;
                    default:
                        log.debug("NOT Matched", "No transaction matching");
                }

                if ((!oldCreateEINVData && newCreateEINVData && statusisOpen) || runtime.executionContext === runtime.ContextType.SUITELET) {
                    createMYEINVDataRecord(currRec, existingJSONRecId, currentSubId, configSearch);
                }
            } catch (ex) {
                log.error("After Submit Error " + ex.name, ex);
                record.submitFields({
                    type: context.newRecord.type,
                    id: context.newRecord.id,
                    values: {
                        custbody_my_e_inv_create_data: false
                    },
                    options: {
                        enableSourcing: false,
                        ignoreMandatoryFields: true
                    }
                });
            }

            log.audit("after submit governance", scriptObj.getRemainingUsage());
        }

        function beforeSubmit(context) {
            try {
                var currRec = context.newRecord;
                // var multiSubFeature = runtime.isFeatureInEffect({
                //     feature: "subsidiaries"
                // });

                var configSearch = search.create({
                    type: 'customrecord_my_einv_con_setup',
                    columns: [
                        'internalid',
                        'custrecord_my_e_inv_tin_autojsonhold',
                        'custrecord_my_e_inv_tin_autoappreinv'
                    ],
                    filters: [
                        ['custrecord_my_e_invoice_subsidiary', 'anyof', currRec.getValue('subsidiary')]
                    ]
                }).run().getRange(0, 1);
                if (configSearch.length > 0 && configSearch[0].getValue("custrecord_my_e_inv_tin_autojsonhold")) {
                    currRec.setValue("custbody_my_e_inv_create_data", true);
                }

                // var eInvTaxCode = undefined;
                if (currRec.type == "creditmemo") {
                    var createdFromId = currRec.getValue("createdfrom");
                    log.debug("before submit contet", createdFromId);
                    if (createdFromId) {
                        var crCreatedFrom = search.lookupFields({
                            type: search.Type.TRANSACTION,
                            id: createdFromId,
                            columns: ['type','tranid']
                        });

                        var crReadFromTranType = undefined;
                        var crReadFromTranId = undefined;
                        if (crCreatedFrom['type'][0].value == "RtnAuth") {
                            var returnAuthLookup = search.lookupFields({
                                type: search.Type.RETURN_AUTHORIZATION,
                                id: createdFromId,
                                columns: ['createdfrom.type', 'createdfrom', 'createdfrom.tranid']
                            });
                            currRec.setValue("custbody_ein_t_invoice_doc_no", returnAuthLookup['createdfrom.tranid']);
                            crReadFromTranType = returnAuthLookup['createdfrom.type'][0].text;
                            crReadFromTranId = returnAuthLookup['createdfrom'][0].value;
                        }else if (crCreatedFrom['type'][0].text == "Invoice") {
                            currRec.setValue("custbody_ein_t_invoice_doc_no", crCreatedFrom['tranid']);
                            crReadFromTranType = crCreatedFrom['type'][0].text;
                            crReadFromTranId = createdFromId;
                        }

                        if(crReadFromTranType == "Invoice"){
                            var einvJsonHoldSearch = search.create({
                                type: "customrecord_my_einv_tax_data",
                                filters: [
                                    ["custrecord_my_e_inv_linked_rec", "anyof", crReadFromTranId],
                                    'AND',
                                    ['isinactive','is',false],
                                    'AND',
                                    ['custrecord_my_e_inv_doc_val_status','is','Valid']
                                ],
                                columns: ["custrecord_my_e_inv_uuid"]
                            }).run().getRange(0, 1);
                            if (einvJsonHoldSearch.length > 0 && einvJsonHoldSearch[0].getValue("custrecord_my_e_inv_uuid")) {
                                currRec.setValue("custbody_ein_t_invoice_uuid", einvJsonHoldSearch[0].getValue("custrecord_my_e_inv_uuid"));
                                currRec.setValue("custbody_my_e_inv_create_data", true);
                            } else {
                                currRec.setValue("custbody_my_e_inv_create_data", false);
                                currRec.setValue("custbody_my_e_inv_json_file_gerror", "Invoice doesn't have uuid.");
                            }
                        }
                    }
                }

                if (currRec.type == "vendorcredit") {
                    var createdFromId = currRec.getValue("createdfrom");
                    log.debug("before submit contet", createdFromId);
                    if (createdFromId) {
                        var crCreatedFrom = search.lookupFields({
                            type: search.Type.TRANSACTION,
                            id: createdFromId,
                            columns: ['type','transactionnumber']
                        });

                        var vcrReadFromTranType = undefined;
                        var vcrReadFromTranId = undefined;
                        if (crCreatedFrom['type'][0].value == "VendAuth") {
                            var returnAuthLookup = search.lookupFields({
                                type: search.Type.VENDOR_RETURN_AUTHORIZATION,
                                id: createdFromId,
                                columns: ['createdfrom.type', 'createdfrom', 'createdfrom.transactionnumber']
                            });
                            currRec.setValue("custbody_ein_t_invoice_doc_no", returnAuthLookup['createdfrom.transactionnumber']);
                            vcrReadFromTranType = returnAuthLookup['createdfrom.type'][0].text;
                            vcrReadFromTranId = returnAuthLookup['createdfrom'][0].value;
                        }else if(crCreatedFrom['type'][0].value == "VendBill"){
                            currRec.setValue("custbody_ein_t_invoice_doc_no", crCreatedFrom['transactionnumber']);
                            vcrReadFromTranType = crCreatedFrom['type'][0].text;
                            vcrReadFromTranId = createdFromId;
                        }

                        if(vcrReadFromTranType == "Bill"){
                            var einvJsonHoldSearch = search.create({
                                type: "customrecord_my_einv_tax_data",
                                filters: [
                                    ["custrecord_my_e_inv_linked_rec", "anyof", vcrReadFromTranId]
                                ],
                                columns: ["custrecord_my_e_inv_uuid"]
                            }).run().getRange(0, 1);
                            if (einvJsonHoldSearch.length > 0 && einvJsonHoldSearch[0].getValue("custrecord_my_e_inv_uuid")) {
                                currRec.setValue("custbody_ein_t_invoice_uuid", einvJsonHoldSearch[0].getValue("custrecord_my_e_inv_uuid"));
                                currRec.setValue("custbody_my_e_inv_create_data", true);
                            } else {
                                currRec.setValue("custbody_my_e_inv_create_data", false);
                                currRec.setValue("custbody_my_e_inv_json_file_gerror", "Invoice doesn't have uuid.");
                            }
                        }
                    }
                }

                var lineCount = currRec.getLineCount('item');
                for (let i = 0; i < lineCount; i++) {
                    let taxCode = currRec.getSublistValue({
                        sublistId: "item",
                        fieldId: "taxcode",
                        line: i
                    });
                    if (taxCode) {
                        let taxCodeLookup = search.lookupFields({
                            type: search.Type.SALES_TAX_ITEM,
                            id: taxCode,
                            columns: ["custrecord_ein_t_tax_type"]
                        });
                        if (taxCodeLookup['custrecord_ein_t_tax_type'].length > 0) {
                            currRec.setSublistValue({
                                sublistId: "item",
                                fieldId: "custcol_ein_t_taxtype",
                                value: taxCodeLookup['custrecord_ein_t_tax_type'][0].value,
                                line: i
                            });
                            eInvTaxCode = taxCodeLookup['custrecord_ein_t_tax_type'][0].value;
                        }
                    }
                }

                var expenseLineCount = currRec.getLineCount("expense");
                for (let i = 0; i < expenseLineCount; i++) {
                    let taxCode = currRec.getSublistValue({
                        sublistId: "expense",
                        fieldId: "taxcode",
                        line: i
                    });
                    if (taxCode) {
                        let taxCodeLookup = search.lookupFields({
                            type: search.Type.SALES_TAX_ITEM,
                            id: taxCode,
                            columns: ["custrecord_ein_t_tax_type"]
                        });
                        if (taxCodeLookup['custrecord_ein_t_tax_type'].length > 0) {
                            currRec.setSublistValue({
                                sublistId: "expense",
                                fieldId: "custcol_ein_t_taxtype",
                                value: taxCodeLookup['custrecord_ein_t_tax_type'][0].value,
                                line: i
                            });
                            eInvTaxCode = taxCodeLookup['custrecord_ein_t_tax_type'][0].value;
                        }
                    }
                }

                // currRec.setValue("custbody_ein_t_taxtype", 6); //Not Applicable
                currRec.setValue("custbody_my_e_inv_json_file_gerror", "");
            } catch (ex) {
                log.error("Before Submit error : " + ex.name, ex);
                currRec.setValue("custbody_my_e_inv_create_data", false);
                currRec.setValue("custbody_my_e_inv_json_file_gerror", ex.message);
            }
        }

        /**
         * context {object}
         */
        createMYEINVDataRecord = (currRec, existingJSONRecId, currentSubId, configSearch) => {

            var scriptObj = runtime.getCurrentScript();
            var folderId = scriptObj.getParameter({
                name: "custscript_einv_json_folder"
            });

            tranType = currRec.getText("custbody_ein_t_einvoicetype");
            if (tranType) {
                eInvTaxTypeSearch = search.create({
                    type: "customrecord_my_einv_tax_types",
                    columns: ['internalid', 'custrecord_einv_type_code'],
                    filters: [
                        ['name', 'is', tranType]
                    ]
                }).run().getRange(0, 1);
            }

            var UBLJsonObj, tranType, eInvTaxTypeSearch;
            switch (currRec.type) {
                case "invoice":
                    UBLJsonObj = _EINV_MAP_MOD_.mapJSONWithINVData(currRec, _EINV_UBL_.getInvoiceUBLJSON(), eInvTaxTypeSearch[0].getValue('custrecord_einv_type_code'), currentSubId);
                    break;
                case "vendorbill":
                    // if (currRec.getText("custbody_ein_t_international_local") == "International")
                    UBLJsonObj = _EINV_MAP_MOD_.mapJSONWithVBData(currRec, _EINV_UBL_.getInvoiceUBLJSON(), eInvTaxTypeSearch[0].getValue('custrecord_einv_type_code'), currentSubId);
                    break;
                case "expensereport":
                    // if (currRec.getText("custbody_ein_t_international_local") == "International")
                    UBLJsonObj = _EINV_MAP_MOD_.mapJSONWithEXPData(currRec, _EINV_UBL_.getInvoiceUBLJSON(), eInvTaxTypeSearch[0].getValue('custrecord_einv_type_code'), currentSubId);
                    break;
                case "check":
                    // if (currRec.getText("custbody_ein_t_international_local") == "International")
                    UBLJsonObj = _EINV_MAP_MOD_.mapJSONWithCHECKData(currRec, _EINV_UBL_.getInvoiceUBLJSON(), eInvTaxTypeSearch[0].getValue('custrecord_einv_type_code'), currentSubId);
                    break;
                case "creditmemo":
                    var invdoc = currRec.getValue("custbody_ein_t_invoice_doc_no");
                    var uuid = currRec.getValue("custbody_ein_t_invoice_uuid");
                    if (invdoc && uuid) {
                        UBLJsonObj = _EINV_MAP_MOD_.mapJSONWithCMData(currRec, _EINV_UBL_.getInvoiceUBLJSON(), eInvTaxTypeSearch[0].getValue('custrecord_einv_type_code'), currentSubId);
                    }
                    break;
                case "vendorcredit":
                    // if (currRec.getText("custbody_ein_t_international_local") == "International") {
                    var billdoc = currRec.getValue("custbody_ein_t_invoice_doc_no");
                    var billuuid = currRec.getValue("custbody_ein_t_invoice_uuid");
                    if (billdoc && billuuid)
                        UBLJsonObj = _EINV_MAP_MOD_.mapJSONWithVCData(currRec, _EINV_UBL_.getInvoiceUBLJSON(), eInvTaxTypeSearch[0].getValue('custrecord_einv_type_code'), currentSubId);
                    // }
                    break;
                default:
                    break;
            }

            if (UBLJsonObj) {
                // var tranId = currRec.getValue("tranid") ? currRec.getValue('tranid') : currRec.getValue('transactionnumber');
                var tranId = (currRec.type == "vendorbill" || currRec.type == "vendorcredit") ? currRec.getValue('transactionnumber') : currRec.getValue('tranid');

                var filedId = file.create({
                    name: eInvTaxTypeSearch[0].getValue('custrecord_einv_type_code') + "_" + tranType + "_" + tranId + "_EINV_DATA.txt",
                    fileType: file.Type.PLAINTEXT,
                    contents: JSON.stringify(UBLJsonObj.jsondata, null, 2),
                    description: "E-INVOICE TRANSACTION JSON DATA",
                    folder: folderId
                }).save();

                var error_filedid, invjsoncreated = false;
                if ((UBLJsonObj.jsonBodyValid != '' && UBLJsonObj.jsonBodyValid) || (UBLJsonObj.jsonLineValid != '' && UBLJsonObj.jsonLineValid)) {
                    log.debug("UBLJsonObj.jsondata", UBLJsonObj.jsondata);
                    var error_filedid = file.create({
                        name: eInvTaxTypeSearch[0].getValue('custrecord_einv_type_code') + "_" + tranType + "_" + tranId + "_JSON_ERROR.txt",
                        fileType: file.Type.PLAINTEXT,
                        contents: "-------RECORD BODY LEVEL VALIDATIONS--------\n" + UBLJsonObj.jsonBodyValid + "\n\n------RECORD LINE LEVEL VALIDATION-----\n" + UBLJsonObj.jsonLineValid,
                        description: tranId + " E-Invoice JSON validation Error file",
                        folder: scriptObj.getParameter({
                            name: "custscript_einv_json_error_folder"
                        })
                    }).save();

                } else {

                    let errorFileId = currRec.getValue("custbody_my_e_inv_json_valdtn_err");
                    if (errorFileId) file.delete(errorFileId);
                    invjsoncreated = !invjsoncreated;

                    var eINVRec = undefined;
                    log.debug("existingJSONRecId", existingJSONRecId);
                    if (existingJSONRecId) {
                        eINVRec = record.load({
                            type: "customrecord_my_einv_tax_data",
                            id: existingJSONRecId
                        });
                    } else {
                        eINVRec = record.create({
                            type: "customrecord_my_einv_tax_data"
                        });
                    }

                    let digitCertSearch = search.create({
                        type: "customrecord_my_einv_digital_cert",
                        columns: ["custrecord_my_einv_dc_private_key"],
                        filters: []
                    }).run().getRange(0, 1);

                    var signatureBase64 = "";
                    if (digitCertSearch.length > 0) {
                        //computing the signature value from the hash
                        // Compute SHA-256 hash
                        const md = forge.md.sha256.create();
                        md.update(JSON.stringify(UBLJsonObj.jsondata), 'utf8');
                        const hash = md.digest().toHex();
                        // Output the hash
                        log.debug('SHA-256 hash:2  ', hash);
                        // Extract the private key
                        const privateKeyObj = forge.pki.privateKeyFromPem(digitCertSearch[0].getValue("custrecord_my_einv_dc_private_key"));
                        // Create a hash for the example (use actual hash in practice)
                        const hash3 = forge.util.createBuffer(hash, 'binary');
                        // Sign the hash
                        const md2 = forge.md.sha256.create();
                        md2.update(hash3, 'binary');
                        const signature = privateKeyObj.sign(md);
                        // Convert signature to Base64
                        signatureBase64 = forge.util.encode64(signature);
                        // Output the signature
                        log.debug('Signature:', signatureBase64);
                    }

                    eINVRec.setValue({
                        fieldId: "custrecord_my_e_inv_linked_rec",
                        value: currRec.id
                    }).setValue({
                        fieldId: "custrecord_my_e_inv_submsn_file",
                        value: filedId
                    }).setValue({
                        fieldId: "custrecord_my_e_inv_tax_type",
                        value: eInvTaxTypeSearch[0].getValue("internalid")
                    }).setValue({
                        fieldId: "custrecord_my_e_inv_linkd_doc",
                        value: tranId
                    }).setValue({
                        fieldId: "custrecord_my_e_inv_apprvd_for_einv",
                        value: (configSearch.length > 0 && configSearch[0].getValue("custrecord_my_e_inv_tin_autoappreinv")) ? true : false
                    }).setValue({
                        fieldId: "custrecord_my_e_inv_sig_value",
                        value: signatureBase64
                    }).save({
                        enableSourcing: false,
                        ignoreMandatoryFields: true
                    });
                }

                record.submitFields({
                    type: currRec.type,
                    id: currRec.id,
                    values: {
                        custbody_my_e_inv_json_valdtn_err: error_filedid ? error_filedid : '',
                        custbody_my_e_inv_create_data: invjsoncreated,
                        custbody_my_e_inv_json_preview: filedId
                    },
                    options: {
                        enableSourcing: false,
                        ignoreMandatoryFields: true
                    }
                });
            }
        }


        return {
            beforeLoad: beforeLoad,
            afterSubmit: afterSubmit,
            beforeSubmit: beforeSubmit
        }
    }
)