/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Task          Date                Author                                         Remarks
 * doc status  21/05/2024      sayyad@abjcloudsolutions.com    
 */
define(['N/ui/serverWidget', 'N/runtime'],

    function (serverWidget, runtime) {


        function beforeLoad(context) {
            try {
                var scriptObj = runtime.getCurrentScript();
                var documentStatus = context.newRecord.getValue("custrecord_my_e_inv_doc_status");
                if (context.type == "view" && context.newRecord.getValue("custrecord_my_e_inv_submissionid") && context.newRecord.getValue("custrecord_my_e_inv_uuid")) {
                    if (documentStatus == "InProgress" || !documentStatus) {
                        context.form.addButton({
                            id: "custpage_einv_get_sub_statu",
                            label: "Get E-Invoice Submission Status",
                            functionName: "getSubmissionStatus('" + context.newRecord.getValue('custrecord_my_e_inv_submissionid') + "','" + context.newRecord.getValue('custrecord_my_e_inv_uuid') + "')"
                        });
                    }

                    context.form.addButton({
                        id: "custpage_einv_get_doc_details",
                        label: "Get E-Invoice Document Details",
                        functionName: "getDocumentDetails('" + context.newRecord.getValue('custrecord_my_e_inv_uuid') + "','"+context.newRecord.id+"')"
                    });


                    if (documentStatus == "Valid") {
                        context.form.addButton({
                            id: "custpage_einv_cancel_doc",
                            label: "Cancel E-Invoice Document",
                            functionName: "cancelOrRejectDocument('" + context.newRecord.getValue('custrecord_my_e_inv_uuid') + "','cancelled', '" + context.newRecord.id + "')"
                        });
                    }

                    if(documentStatus != "InProgress" && documentStatus){
                        context.form.addButton({
                            id: "custpage_einv_reject_doc",
                            label: "Reject E-Invoice Document",
                            functionName: "cancelOrRejectDocument('" + context.newRecord.getValue('custrecord_my_e_inv_uuid') + "','rejected', '" + context.newRecord.id + "')"
                        });
                    }

                    context.form.clientScriptModulePath = "./abj_cs_my_einv_json_holder_client_methods.js";
                }

            } catch (ex) {
                log.error(ex.name, ex);
            }
        }

        function afterSubmit(context) {}

        function beforeSubmit(context) {}

        return {
            beforeLoad: beforeLoad,
            // afterSubmit : afterSubmit,
            // beforeSubmit : beforeSubmit
        }
    }
)