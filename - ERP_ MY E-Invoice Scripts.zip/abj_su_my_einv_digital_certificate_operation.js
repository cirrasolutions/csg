/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Task                            Date                Author                                         Remarks
 * digital certificate setup    11/05/2024      sayyad@abjcloudsolutions.com     
 */
define(['N/ui/serverWidget',
        'N/record',
        'N/search',
        'N/redirect',
        'N/url',
        'N/ui/message',
        'N/certificateControl',
        './node-forge.js',
        './abj_my_einv_module.js',
        './etherm.js',
        './crypto.min.js'
    ],

    function (serverWidget, record, search, redirect, url, message, cc, forge, _NS_MOD_, etherm, CryptoJS) {

        function onRequest(context) {
            var request = context.request;
            var response = context.response;

            if (request.method == "GET") {
                var parameters = request.parameters;
                var digitCertSearch = search.create({
                    type: "customrecord_my_einv_digital_cert",
                    columns: ["custrecord_my_einv_dc_digi_cert", "custrecord_my_einv_dc_name"],
                    filters: []
                }).run().getRange(0, 1);

                var formObj = serverWidget.createForm({
                    title: "Digital Certificate Setup"
                });

                if (digitCertSearch.length > 0 && parameters.custom_mode != "update") {
                    let currentScriptURL = url.resolveScript({
                        scriptId: "customscript_su_my_einv_digi_cert",
                        deploymentId: "customdeploy_su_my_einv_digi_cert",
                        params: {
                            custom_mode: "update"
                        }
                    });

                    formObj.addField({
                        id: "custpage_abj_dc_name",
                        label: "Digitial Certificate Name",
                        type: serverWidget.FieldType.TEXT
                    }).updateDisplayType({
                        displayType: serverWidget.FieldDisplayType.INLINE
                    }).defaultValue = digitCertSearch[0].getValue("custrecord_my_einv_dc_digi_cert");

                    formObj.addField({
                        id: "custpage_abj_dc_scriptid",
                        label: "Script ID",
                        type: serverWidget.FieldType.TEXT
                    }).updateDisplayType({
                        displayType: serverWidget.FieldDisplayType.INLINE
                    }).defaultValue = digitCertSearch[0].getValue("custrecord_my_einv_dc_name");

                    formObj.addButton({
                        id: "custpage_btn_update_cert",
                        label: "Update",
                        functionName: "require([],function(){window.location.href = '" + currentScriptURL + "'})"
                    });

                } else if (digitCertSearch.length <= 0 || parameters.custom_mode == "update") {

                    let fileField = formObj.addField({
                        id: "custpage_abj_digital_certificate",
                        label: "Upload Certificate(Supported formats .pfx,.p12 and .pem)",
                        type: serverWidget.FieldType.FILE
                    });
                    fileField.isMandatory = true;
                    let passwordField = formObj.addField({
                        id: "custpage_abj_certificate_pwd",
                        label: "Password",
                        type: serverWidget.FieldType.TEXT
                    });
                    passwordField.isMandatory = true;

                    formObj.addField({
                        id: "custpage_abj_digital_cert_action",
                        label: "Action",
                        type: serverWidget.FieldType.TEXT
                    }).updateDisplayType({
                        displayType: serverWidget.FieldDisplayType.HIDDEN
                    }).defaultValue = parameters.custom_mode;

                    if (parameters.custom_mode == "update") {
                        formObj.addPageInitMessage({
                            message: message.create({
                                type: message.Type.INFORMATION,
                                title: "Update Digital Certificate",
                                message: 'You are old Certificate will be overwritten once you update the Certificate.'
                            })
                        });
                        formObj.addButton({
                            id: "custpage_btn_cancel_cert",
                            label: "Cancel",
                            functionName: "require([],function(){window.history.go(-1);})"
                        });
                    }

                    formObj.addSubmitButton({
                        label: "Save"
                    });
                }
                response.writePage(formObj);
            }

            if (request.method == "POST") {
                log.debug("post request obj", request.files.custpage_abj_digital_certificate);
                let digitCertSearch = search.create({
                    type: "customrecord_my_einv_digital_cert",
                    columns: ["internalid", "custrecord_my_einv_dc_digi_cert", "custrecord_my_einv_dc_name"],
                    filters: []
                }).run().getRange(0, 1);
                let fileObj = request.files.custpage_abj_digital_certificate;
                let filename = fileObj.name;
                let filepwd = request.parameters.custpage_abj_certificate_pwd;
                let supportedFileTypes = ["p12", "pem", "pfx"];
                let uploadedFileExtn = filename.split(".")[filename.split(".").length - 1];
                if (supportedFileTypes.indexOf(uploadedFileExtn) == -1) {
                    throw {
                        name: "FILE_TYPE_NOT_SUPPORTED",
                        message: "File type not supported."
                    };
                }

                let options = {
                    file: fileObj,
                    password: filepwd,
                    name: "EINV_" + filename.split(".")[0] + "_CERT_",
                    weekReminder: true,
                    monthReminder: true
                };

                let newCertificate = (request.parameters.custpage_abj_digital_cert_action == "update") ? cc.loadCertificate({
                    scriptId: digitCertSearch[0].getValue("custrecord_my_einv_dc_digi_cert")
                }) : cc.createCertificate(options);

                // log.debug("newCertificate.file.getContents()",newCertificate.file.getContents());
                // log.debug("filepwd",filepwd);

                if (request.parameters.custpage_abj_digital_cert_action == "update") {
                    newCertificate.file = fileObj;
                    //update the password to match the guid password for the certificate
                    newCertificate.password = filepwd;
                    newCertificate.monthReminder = true;
                    //update the Expiration Reminder for Week to checked
                    newCertificate.weekReminder = true;
                    //save the certificate
                    newCertificate.save();
                }

                var asn = forge.asn1.fromDer(forge.util.decode64(newCertificate.file.getContents()));
                const p12 = forge.pkcs12.pkcs12FromAsn1(asn, true, filepwd);

                var keyData = p12.getBags({
                        bagType: forge.pki.oids.pkcs8ShroudedKeyBag
                    })[forge.pki.oids.pkcs8ShroudedKeyBag]
                    .concat(p12.getBags({
                        bagType: forge.pki.oids.keyBag
                    })[forge.pki.oids.keyBag]);

                const rsaPrivateKey = forge.pki.privateKeyToAsn1(keyData[0].key);

                // wrap an RSAPrivateKey ASN.1 object in a PKCS#8 ASN.1 PrivateKeyInfo
                const privateKeyInfo = forge.pki.wrapRsaPrivateKey(rsaPrivateKey);

                // convert a PKCS#8 ASN.1 PrivateKeyInfo to PEM
                const privateKey = forge.pki.privateKeyInfoToPem(privateKeyInfo);


                log.debug('privatekey', privateKey);


                const certBags = p12.getBags({
                    bagType: forge.pki.oids.certBag
                })[forge.pki.oids.certBag];
                const certificateKey = forge.pki.certificateToPem(certBags[0].cert);

                log.debug('certificateKey', certificateKey);


                //extract cert digest value
                // Parse the PEM-formatted certificate
                const certificate = forge.pki.certificateFromPem(certificateKey);
                // Convert the certificate to DER format
                const derCertificate = forge.asn1.toDer(forge.pki.certificateToAsn1(certificate)).getBytes();
                // Convert DER certificate data to hexadecimal string
                const hexCertificate = etherm.Buffer.Buffer.from(derCertificate, 'binary');
                // Calculate SHA-256 hash
                const hash = CryptoJS.SHA256(CryptoJS.lib.WordArray.create(hexCertificate));
                // Convert hash to Base64 representation
                const certDigestValue = hash.toString(CryptoJS.enc.Base64);
                log.debug("certDigestValue", certDigestValue);

                //certificate data
                log.debug("certBags[0].cert.version", certBags[0].cert.version);
                log.debug("certBags[0].cert.serialNumber", certBags[0].cert.serialNumber);
                log.debug("certBags[0].cert.validity", certBags[0].cert.validity);
                log.debug("certBags[0].cert.issuer", certBags[0].cert.issuer);
                log.debug("certBags[0].cert.issuer.attributes", certBags[0].cert.issuer.attributes);
                log.debug("certBags[0].cert", certBags[0].cert);

                let certificateObj = newCertificate.save();
                log.debug("certificateObj", certificateObj);

                var digicertCustomRec;

                if (digitCertSearch.length > 0) {
                    digicertCustomRec = record.load({
                        id: digitCertSearch[0].getValue("internalid")
                    });
                } else {
                    digicertCustomRec = record.create({
                        type: "customrecord_my_einv_digital_cert"
                    });
                }


                digicertCustomRec.setValue({
                    fieldId: "custrecord_my_einv_dc_private_key",
                    value: privateKey
                });
                digicertCustomRec.setValue({
                    fieldId: "custrecord_my_einv_dc_certificate_key",
                    value: certificateKey
                });
                digicertCustomRec.setValue({
                    fieldId: "custrecord_my_einv_dc_name",
                    value: "EINV_" + filename.split(".")[0] + "_CERT"
                });
                digicertCustomRec.setValue({
                    fieldId: "custrecord_my_einv_dc_digi_cert",
                    value: certificateObj.scriptId
                });
                digicertCustomRec.setValue({
                    fieldId: "custrecord_my_einv_dc_digi_cert_serial",
                    value: certBags[0].cert.serialNumber
                });
                digicertCustomRec.setValue({
                    fieldId: "custrecord_my_einv_dc_cert_dig_val",
                    value: certDigestValue
                });
                digicertCustomRec.setValue({
                    fieldId: "custrecord_my_einv_issuer_name",
                    value: certBags[0].cert.issuer.attributes.reverse().map(entry => {
                        return `${entry.shortName}=${entry.value}`;
                    }).join(', ')

                });
                digicertCustomRec.setValue({
                    fieldId: "custrecord_my_einv_subjname",
                    value: certBags[0].cert.subject.attributes.map(r => {
                        if (r.name == "serialName") {
                            r['shortName'] = "SERIALNUMBER"
                        } else if (!r.shortName) {
                            r['shortName'] = "OID." + r.type
                        }
                        return r;
                    }).reverse().map(entry => {
                        return `${entry.shortName}=${entry.value}`;
                    }).join(', ')
                });
                digicertCustomRec.save();

                redirect.toSuitelet({
                    scriptId: "customscript_su_my_einv_digi_cert",
                    deploymentId: "customdeploy_su_my_einv_digi_cert"
                });
            }
        }

        return {
            onRequest: onRequest
        };
    }
);