/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 * Task          Date                Author                                         Remarks
 * doc status  21/05/2024      sayyad@abjcloudsolutions.com       
 */
define(['N/record', 'N/search', 'N/runtime', './abj_my_einv_module.js'],

    function (record, search, runtime, _MY_EINV_MOD_) {
        function getInputData() {
            try {
                var scriptObj = runtime.getCurrentScript();
                var multiSubFeature = runtime.isFeatureInEffect({feature:"subsidiaries"});
                var subsId = scriptObj.getParameter({name:"custscript_einv_status_subsidiary"});
                if(scriptObj.deploymentId == "customdeploy_mr_einv_get_doc_status"){
                    let searchFil = [
                        ["custrecord_my_e_inv_submted_to_einv","is",true],"AND",
                        ["custrecord_my_e_inv_status_code","is",202],"AND",
                        ["custrecord_my_e_inv_submissionid","isnotempty",null],"AND",
                        ["custrecord_my_e_inv_uuid","isnotempty",null],"AND",
                        ["isinactive","is",false],"AND",
                        ["custrecord_my_e_inv_doc_val_status","isempty",null],"AND",
                        ["custrecord_my_e_inv_doc_status","isempty",null],"AND",
                        ["custrecord_my_e_inv_linked_rec.mainline","is","T"]
                    ];
                    if(multiSubFeature){
                        searchFil.push("AND",["custrecord_my_e_inv_linked_rec.subsidiary","anyof",subsId]);
                    }
                    return search.create({  
                        type:"customrecord_my_einv_tax_data",
                        columns:[search.createColumn({name:"custrecord_my_e_inv_submissionid",summary:search.Summary.GROUP})],
                        filters:searchFil
                    });
                }else if(scriptObj.deploymentId == "customdeploy_mr_einv_get_doc_inprgss"){
                    let searchFil = [
                        ["custrecord_my_e_inv_submted_to_einv","is",true],"AND",
                        ["custrecord_my_e_inv_status_code","is",202],"AND",
                        ["custrecord_my_e_inv_submissionid","isnotempty",null],"AND",
                        ["custrecord_my_e_inv_uuid","isnotempty",null],"AND",
                        ["isinactive","is",false],"AND",
                        ["custrecord_my_e_inv_doc_val_status","isempty",null],"AND",
                        ["custrecord_my_e_inv_doc_status","is","InProgress"],"AND",
                        ["custrecord_my_e_inv_linked_rec.mainline","is","T"]
                    ];
                    if(multiSubFeature){
                        searchFil.push("AND",["custrecord_my_e_inv_linked_rec.subsidiary","anyof",subsId]);
                    }
                    return search.create({  
                        type:"customrecord_my_einv_tax_data",
                        columns:[search.createColumn({name:"custrecord_my_e_inv_submissionid",summary:search.Summary.GROUP})],
                        filters:searchFil
                    });
                }else if(scriptObj.deploymentId == "customdeploy_mr_einv_get_doc_submitted"){
                    let searchFil = [
                        ["custrecord_my_e_inv_submted_to_einv","is",true],"AND",
                        ["custrecord_my_e_inv_status_code","is",202],"AND",
                        ["custrecord_my_e_inv_submissionid","isnotempty",null],"AND",
                        ["custrecord_my_e_inv_uuid","isnotempty",null],"AND",
                        ["isinactive","is",false],"AND",
                        ["custrecord_my_e_inv_doc_status","is","Submitted"],"AND",
                        ["custrecord_my_e_inv_linked_rec.mainline","is","T"]
                    ];
                    if(multiSubFeature){
                        searchFil.push("AND",["custrecord_my_e_inv_linked_rec.subsidiary","anyof",subsId]);
                    }
                    return search.create({  
                        type:"customrecord_my_einv_tax_data",
                        columns:[search.createColumn({name:"custrecord_my_e_inv_submissionid",summary:search.Summary.GROUP})],
                        filters:searchFil
                    });
                }
            } catch (ex) {
                log.error(ex.name, ex);
            }
        }

        function map(ctx) {
            try {
                var scriptObj = runtime.getCurrentScript();
                var multiSubFeature = runtime.isFeatureInEffect({feature:"subsidiaries"});
                var subsId = multiSubFeature ? scriptObj.getParameter({name:"custscript_einv_status_subsidiary"}) : 1;
                var submissionUid = JSON.parse(ctx.value)["values"]["GROUP(custrecord_my_e_inv_submissionid)"];
                //get the document status from E-Invoice portal
                let submissionResponse = _MY_EINV_MOD_.getSubmission(submissionUid, scriptObj.deploymentId, subsId);
                log.debug("MAP submissionResponse", submissionResponse);
                if(submissionResponse.code == 200){
                    let submissionSuccessRes = submissionResponse.body;
                    if(submissionSuccessRes.overallStatus == "InProgress"){
                        log.debug("MAP Submission ID " + submissionSuccessRes.submissionUid , submissionSuccessRes.overallStatus);
                        search.create({
                            type:"customrecord_my_einv_tax_data",
                            columns:["internalid"],
                            filters:[
                                ["custrecord_my_e_inv_submissionid","is",submissionUid]
                            ]
                        }).run().each(r=>{
                            record.submitFields({
                                type:"customrecord_my_einv_tax_data",
                                id:r.getValue("internalid"),
                                values:{
                                    custrecord_my_e_inv_doc_status: submissionSuccessRes.overallStatus
                                },
                                options:{
                                    enablesourcing:false,
                                    ignoreMandatoryFields:true
                                }
                            });
                            return true;
                        })
                        return;
                    }
                    submissionSuccessRes.documentSummary.forEach(res=>{
                        ctx.write({
                            key: res.status,
                            value: res
                        });
                    });
                }else{
                    throw Error(submissionResponse.body)
                }
            } catch (ex) {
                log.error("map error " + ex.name, ex);
            }
        }

        function reduce(ctx) {
            try {
                var scriptObj = runtime.getCurrentScript();
                var multiSubFeature = runtime.isFeatureInEffect({feature:"subsidiaries"});
                var subsId = multiSubFeature ? scriptObj.getParameter({name:"custscript_einv_status_subsidiary"}) : 1;
                log.debug("REDUCE ctx",ctx);
                ctx.values.forEach(obj => {
                    let inObj = JSON.parse(obj);
                    let holderSearch = search.create({
                        type:"customrecord_my_einv_tax_data",
                        columns:["internalid"],
                        filters:[
                            ["custrecord_my_e_inv_uuid","is",inObj.uuid]
                        ]
                    }).run().getRange(0,1);
                    
                    if(holderSearch.length > 0){
                        let validationError = '';
                        if(inObj.status == "Invalid"){
                            var documentDetailedRes = _MY_EINV_MOD_.getDocumentDetails(inObj.uuid,scriptObj.deploymentId, subsId);
                            log.debug("documentDetailedRes",documentDetailedRes);
                            validationError = JSON.stringify(documentDetailedRes.body.validationResults.validationSteps.filter(r => r.status == "Invalid"));
                        }
                        record.submitFields({
                            type: "customrecord_my_einv_tax_data",
                            id: holderSearch[0].getValue("internalid"),
                            values: {
                                custrecord_my_e_inv_doc_status: inObj.status,
                                custrecord_my_e_inv_doc_val_status:  inObj.status,
                                custrecord_my_e_inv_data_longid: inObj.longId,
                                custrecord_my_e_inv_data_typename: inObj.typeName,
                                custrecord_my_e_inv_data_typvname: inObj.typeVersionName,
                                custrecord_my_e_inv_data_issuetin: inObj.issuerTin,
                                custrecord_my_e_inv_data_issuername: inObj.issuerName,
                                custrecord_my_e_inv_data_recevrid: inObj.receiverId,
                                custrecord_my_e_inv_data_recvrname: inObj.receiverName,
                                custrecord_my_e_inv_data_datetmissd: inObj.dateTimeIssued,
                                custrecord_my_e_inv_data_datetmrecvd: inObj.dateTimeReceived,
                                custrecord_my_e_inv_data_datetmvaltd: inObj.dateTimeValidated,
                                // custrecord_my_e_inv_data_totalsales: inObj.totalSales,
                                custrecord_my_e_inv_data_totaldscnt: inObj.totalDiscount,
                                custrecord_my_e_inv_data_netamt: inObj.totalNetAmount,
                                custrecord_my_e_inv_data_total: inObj.totalPayableAmount,
                                custrecord_my_e_inv_data_cacldattm: inObj.cancelDateTime,
                                custrecord_my_e_inv_data_rejectrqdtm: inObj.rejectRequestDateTime,
                                custrecord_my_e_inv_data_docstatures: inObj.documentStatusReason,
                                custrecord_my_e_inv_data_crbyuserid: inObj.createdByUserId,
                                custrecord_my_e_inv_validtn_error: validationError
                            },
                            options: {
                                enablesourcing: false,
                                ignoreMandatoryFields: true
                            }
                        });
                    }
                })
                log.audit("REDUCE END USAGE", scriptObj.getRemainingUsage());
            } catch (ex) {
                log.error("reduce error " + ex.name, ex);
            }
        }

        function summarize(summary) {}

        return {
            getInputData: getInputData,
            map: map,
            reduce: reduce,
            summarize: summarize
        };
    }
);