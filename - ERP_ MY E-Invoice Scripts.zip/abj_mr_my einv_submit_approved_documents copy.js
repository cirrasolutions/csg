/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 * Task          Date                Author                                         Remarks
 * submit docs  08/05/2024      sayyad@abjcloudsolutions.com       
 */
define(['N/record', 'N/search', 'N/runtime', './abj_my_einv_module.js'],

    function (record, search, runtime, _MY_EINV_MOD_) {
        function getInputData() {
            try {
                var scriptObj = runtime.getCurrentScript();
                var eInvTypeId = scriptObj.getParameter({name:"custscript_cpy_einv_type"});
                var eInvTypeCode = search.lookupFields({
                    type:"customrecord_my_einv_tax_types",
                    id:eInvTypeId,
                    columns:["custrecord_einv_type_code"]
                })['custrecord_einv_type_code'];
                var multiSubFeature = runtime.isFeatureInEffect({feature:"subsidiaries"});
                var taxDatafil = [
                    ["isinactive", "is", false],
                    "AND",
                    ["custrecord_my_e_inv_apprvd_for_einv", "is", true],
                    "AND",
                    ["custrecord_my_e_inv_linked_rec", "isnotempty", null],
                    "AND",
                    ["custrecord_my_e_inv_status_code", "isempty", null],
                    "AND",
                    ["custrecord_my_e_inv_error_code", "isempty", null],
                    "AND",
                    ["custrecord_my_e_inv_response", "isempty", null],
                    "AND",
                    ["custrecord_my_e_inv_submsn_file", "isnotempty", null],
                    "AND",
                    ["custrecord_my_e_inv_submted_to_einv", "is", false],
                    "AND",
                    ["custrecord_my_e_inv_code", "is", eInvTypeCode], //is invoice type
                    "AND",
                    ["custrecord_my_e_inv_linked_rec.mainline","is","T"]
                ];

                if(multiSubFeature){
                    let subsId = scriptObj.getParameter({name:"custscript_cpy_einv_submit_subsidiary"});
                    taxDatafil.push("AND",["custrecord_my_e_inv_linked_rec.subsidiary","anyof",subsId]);
                }

                return search.create({
                    type: "customrecord_my_einv_tax_data",
                    filters: taxDatafil,
                    columns: [
                        'custrecord_my_e_inv_submsn_file',
                        'custrecord_my_e_inv_linkd_doc'
                    ]
                }).run().getRange(0, 50);
            } catch (ex) {
                log.error(ex.name, ex);
            }
        }

        function map(ctx) {
            try {
                log.debug("MAP ctx", ctx);
                var jsonObj = JSON.parse(ctx.value)["values"];
                ctx.write({
                    key: "01",
                    value: {
                        holder_id: JSON.parse(ctx.value).id,
                        file_id: jsonObj["custrecord_my_e_inv_submsn_file"][0]["value"],
                        inv_doc: jsonObj["custrecord_my_e_inv_linkd_doc"],
                    }
                });
            } catch (ex) {
                log.error("map error " + ex.name, ex);
            }
        }

        function reduce(ctx) {
            try {
                var scriptObj = runtime.getCurrentScript();
                log.debug("REDUCE ctx", ctx);
                var parsedReduceData = ctx.values.map(r => JSON.parse(r));
                log.debug("parsedReduceData", parsedReduceData);

                //submitting the document to E-Invoice portal
                var multiSubFeature = runtime.isFeatureInEffect({feature:"subsidiaries"});
                let subsId = multiSubFeature ? scriptObj.getParameter({name:"custscript_cpy_einv_submit_subsidiary"}) : 1;
                let submittedInvRes = _MY_EINV_MOD_.submitDocuments(parsedReduceData, scriptObj.deploymentId, subsId);
                log.debug("submittedInvRes", submittedInvRes);
                let submitResBody = JSON.parse(submittedInvRes.body);

                //updating the e-invoice holder records if there are any errors
                if (submittedInvRes.code != 200 && submittedInvRes.code != 202) {
                    parsedReduceData.forEach(obj => {
                        record.submitFields({
                            type: "customrecord_my_einv_tax_data",
                            id: obj.holder_id,
                            values: {
                                custrecord_my_e_inv_submted_to_einv: true,
                                custrecord_my_e_inv_status_code: submittedInvRes.code,
                                custrecord_my_e_inv_error_code: typeof submitResBody['error'] == 'object' ? submitResBody.error.code : submitResBody['error'],
                                custrecord_my_e_inv_response: JSON.stringify(submitResBody['error'])
                            },
                            options: {
                                enablesourcing: true,
                                ignoreMandatoryFields: true
                            }
                        });
                    });
                } else {
                    //updating the record with success response from E-INVOICE
                    submitResBody.acceptedDocuments.forEach(subObj => {
                        let filteredData = parsedReduceData.filter(data => data.inv_doc == subObj.invoiceCodeNumber);
                        if (filteredData.length > 0) {
                            record.submitFields({
                                type: "customrecord_my_einv_tax_data",
                                id: filteredData[0].holder_id,
                                values: {
                                    custrecord_my_e_inv_status_code: submittedInvRes.code,
                                    custrecord_my_e_inv_submted_to_einv: true,
                                    custrecord_my_e_inv_uuid: subObj.uuid,
                                    custrecord_my_e_inv_submissionid: submitResBody.submissionUid
                                },
                                options: {
                                    enablesourcing: true,
                                    ignoreMandatoryFields: true
                                }
                            });
                        }
                    });

                    //updating the rejected documents with errors from the E-INVOICE
                    submitResBody.rejectedDocuments.forEach(subObj => {
                        let filteredData = parsedReduceData.filter(data => data.inv_doc == subObj.invoiceCodeNumber);
                        if (filteredData.length > 0) {
                            record.submitFields({
                                type: "customrecord_my_einv_tax_data",
                                id: filteredData[0].holder_id,
                                values: {
                                    custrecord_my_e_inv_submted_to_einv: true,
                                    custrecord_my_e_inv_status_code: submittedInvRes.code,
                                    custrecord_my_e_inv_error_code: subObj['error']['code'],
                                    custrecord_my_e_inv_response: JSON.stringify(subObj['error']['details'])
                                },
                                options: {
                                    enablesourcing: true,
                                    ignoreMandatoryFields: true
                                }
                            });
                        }
                    });
                }

                log.audit("REDUCE END USAGE", scriptObj.getRemainingUsage());
            } catch (ex) {
                log.error("reduce error " + ex.name, ex);
            }
        }

        function summarize(summary) {}

        return {
            getInputData: getInputData,
            map: map,
            reduce: reduce,
            summarize: summarize
        };
    }
);