/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Task          Date                Author                                         Remarks
 * doc status  22/05/2024      sayyad@abjcloudsolutions.com       
 */
 define(['N/search','./abj_my_einv_module.js','N/runtime'],

    function(search, _MY_EINV_MOD_, runtime) {

        function onRequest(context) {
            try{
                var scriptObj = runtime.getCurrentScript();
                log.debug("context",context);
                log.audit("scriptObj.deploymentId",scriptObj.deploymentId);
                var documentDetailedRes;
                var multiSubFeature = runtime.isFeatureInEffect({feature:"subsidiaries"});
                var configSearchLookup = multiSubFeature ? search.lookupFields({
                    type: "customrecord_my_einv_tax_data",
                    id: context.request.parameters.custom_recid,
                    columns: ["custrecord_my_e_inv_linked_rec.subsidiary"]
                }) : {"custrecord_my_e_inv_linked_rec.subsidiary" : [{value:1}]};
                var subsId = configSearchLookup["custrecord_my_e_inv_linked_rec.subsidiary"][0].value;
                switch(context.request.parameters.custom_details){
                    case "document":
                        documentDetailedRes = _MY_EINV_MOD_.getDocumentDetails(context.request.parameters.custom_uuid,scriptObj.deploymentId, subsId);
                    break;
                    case "submission":
                        documentDetailedRes = _MY_EINV_MOD_.getSubmission(context.request.parameters.custom_suid,scriptObj.deploymentId, subsId);
                    break;
                    default:
                    break;
                }                
                context.response.write(JSON.stringify(documentDetailedRes));
            }catch(ex){
                log.error(ex.name,ex);
            }
        }

        return {
            onRequest: onRequest
        };
     }
);