/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * Task          Date                Author                                         Remarks
 * DT-0000      01 Enero 2022       name lastname <examle@gmail.com>       
 */
define(['./sweetalert2.js', 'N/https'],

    function (Swal, https) {

        function lineInit(ctx) {}

        function pageInit(ctx) {}

        function postSourcing(ctx) {}

        function saveRecord(ctx) {}

        function sublistChanged(ctx) {}

        function validateDelete(ctx) {}

        function validateField(ctx) {}

        function validateInsert(ctx) {}

        function validateLine(ctx) {}

        function fieldChanged(ctx) {}

        function getDocumentDetails(uuid, recid) {
            Swal.fire({
                title: 'Please Wait..!',
                text: 'Its fetching the data.',
                allowOutsideClick: false,
                allowEscapeKey: false,
                allowEnterKey: false,
                showCancelButton: false,
                showConfirmButton: false,
                onOpen: () => {
                    Swal.showLoading()
                }
            });
            https.requestSuitelet.promise({
                scriptId: "customscript_su_my_einv_get_doc_detl",
                deploymentId: "customdeploy_su_my_einv_get_doc_detl",
                urlParams: {
                    custom_uuid: uuid,
                    custom_details: 'document',
                    custom_recid: recid
                }
            }).then(res => {
                console.log(res);
                let jsonObj = JSON.parse(res.body);

                if(jsonObj.code != 200){
                    if(jsonObj.code == 429 || jsonObj.code == 503){
                        Swal.fire({
                            icon: "error",
                            title: jsonObj.code,
                            html: `<ul>${jsonObj.body?.message || jsonObj.body}</ul>`,
                            showConfirmButton: true
                        });
                    }else{
                        let errorBody = jsonObj.body;
                        let errorDetails = errorBody.error.details.map(r => "<li>"+r.message+"</li>").join("");
                        Swal.fire({
                            icon: "error",
                            title: jsonObj.code,
                            html: `<ul>${errorDetails}</ul>`,
                            showConfirmButton: true
                        });
                    }
                }else{
                    let successBody = jsonObj.body;
                    var mainDetails = Object.keys(successBody).map(r => {
                        if (r != 'validationResults') {
                            return "<tr><td style='padding-left: 10px'>" + r + "</td><td style='padding-left: 10px'>" + successBody[r] + "</td></tr>"
                        }
                    }).join("");

                    var validatorDetails = '';
                    if(successBody.validationResults){
                        validatorDetails = successBody.validationResults.validationSteps.map(r => "<tr><td style='padding-left: 10px'>" + r.name + "</td><td style='padding-left: 10px'>" + r.status + "</td></tr>").join("");
                    }
                    
    
                    Swal.fire({
                        title: "E-Invoice Document Details",
                        html: `<style>
                        #sweettable th, #sweettable td{
                            border-style: inset;
                            border-color: #96D4D4;
                            text-align: left;
                          }
                          .swal-wide{
                            width:850px !important;
                        }
                        </style><table style="width:100%" id="sweettable">
                        ${mainDetails}
                        ${validatorDetails}
                      </table>`,
                        customClass: 'swal-wide',
                        confirmButtonText: "Ok",
                        allowOutsideClick: "true"
                    });
                }

            });

        }


        function cancelOrRejectDocument(uuid, status, recid) {
            Swal.fire({
                title: status == 'cancelled' ? "Cancel Reason" : "Reject Reason",
                input: "text",
                inputAttributes: {
                    autocapitalize: "off"
                },
                showCancelButton: true,
                confirmButtonText: "Confirm",
                showLoaderOnConfirm: true,
                preConfirm: async (input) => {
                    if(!input){
                        return Swal.showValidationMessage("Reason is required");
                    }
                },
                allowOutsideClick: () => !Swal.isLoading()
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        title: 'Please Wait..!',
                        text: status == 'cancelled' ? 'Cancellation in progress.' : 'Rejection in progress.',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        allowEnterKey: false,
                        showCancelButton: false,
                        showConfirmButton: false,
                        onOpen: () => {
                            Swal.showLoading()
                        }
                    });
                    https.requestSuitelet.promise({
                        scriptId: "customscript_su_my_einv_canorrej_doc",
                        deploymentId: "customdeploy_su_my_einv_canorrej_doc",
                        urlParams: {
                            custom_uuid: uuid,
                            custom_status: status,
                            custom_reason: result.value,
                            custom_recid: recid
                        }
                    }).then(res => {
                        console.log(res);
                        let jsonObj = JSON.parse(res.body);
                        if(jsonObj.code != 200){
                            let errorBody = jsonObj.body;
                            let errorDetails = typeof jsonObj.body == "object" ? errorBody.error.details.map(r=>"<li>"+r.message+"</li>").join("") : errorBody;
                            Swal.fire({
                                icon: "error",
                                title: jsonObj.code,
                                html: `<ul>${errorDetails}</ul>`,
                                showConfirmButton: true
                            });
                        }else{
                            let successBody = jsonObj.body;
                            Swal.fire({
                                icon: "success",
                                title: jsonObj.code,
                                html: `<h4>${successBody.uuid} successfully ${successBody.status}.</h4>`,
                                showConfirmButton: true
                            }).then(r=>{
                                location.reload();
                            });
                        }
                    });
                }
            });
        }

        function getSubmissionStatus(suid, uuid){
            Swal.fire({
                title: 'Please Wait..!',
                text: 'Its fetching the data.',
                allowOutsideClick: false,
                allowEscapeKey: false,
                allowEnterKey: false,
                showCancelButton: false,
                showConfirmButton: false,
                onOpen: () => {
                    Swal.showLoading()
                }
            });
            https.requestSuitelet.promise({
                scriptId: "customscript_su_my_einv_get_doc_detl",
                deploymentId: "customdeploy_su_my_einv_get_doc_detl",
                urlParams: {
                    custom_suid: suid,
                    custom_details: 'submission'
                }
            }).then(res => {
                console.log(res);
                let jsonObj = JSON.parse(res.body);

                if(jsonObj.code != 200){
                    if(jsonObj.code == 429 || jsonObj.code == 503 || jsonObj.code == 502){
                        Swal.fire({
                            icon: "error",
                            title: jsonObj.code,
                            html: `<ul>${jsonObj.body?.message || jsonObj.body}</ul>`,
                            showConfirmButton: true
                        });
                    }else{
                        let errorBody = jsonObj.body;
                        let errorDetails = errorBody.error.details.map(r => "<li>"+r.message+"</li>").join("");
                        Swal.fire({
                            icon: "error",
                            title: jsonObj.code,
                            html: `<ul>${errorDetails}</ul>`,
                            showConfirmButton: true
                        });
                    }
                }else{
                    var currentDocumentDetails = jsonObj.body.documentSummary.filter(r=>r.uuid == uuid);
                    var mainDetails = currentDocumentDetails.length > 0 ? Object.keys(currentDocumentDetails[0]).map(r => {
                        if (r != 'validationResults') {
                            return "<tr><td style='padding-left: 10px'>" + r + "</td><td style='padding-left: 10px'>" + currentDocumentDetails[0][r] + "</td></tr>"
                        }
                    }).join("") : "";
                    
                    Swal.fire({
                        title: "E-Invoice Submission Status Details",
                        html: `<style>
                        #sweettable th, #sweettable td{
                            border-style: inset;
                            border-color: #96D4D4;
                            text-align: left;
                          }
                          .swal-wide{
                            width:850px !important;
                        }
                        </style><table style="width:100%" id="sweettable">
                        <tr><td style='padding-left: 10px'>overallStatus</td><td style='padding-left: 10px'>${jsonObj.body.overallStatus}</td></tr>
                        ${mainDetails}
                      </table>`,
                        customClass: 'swal-wide',
                        confirmButtonText: "Ok",
                        allowOutsideClick: "true"
                    });
                }

            });
        }

        return {
            // lineInit: lineInit,
            getDocumentDetails: getDocumentDetails,
            cancelOrRejectDocument: cancelOrRejectDocument,
            getSubmissionStatus: getSubmissionStatus,
            pageInit: pageInit,
            // postSourcing : postSourcing,
            // saveRecord : saveRecord,
            // sublistChanged : sublistChanged,
            // validateDelete : validateDelete,
            // validateField : validateField,
            // validateInsert : validateInsert,
            // validateLine : validateLine,
            // fieldChanged : fieldChanged
        };
    }
);