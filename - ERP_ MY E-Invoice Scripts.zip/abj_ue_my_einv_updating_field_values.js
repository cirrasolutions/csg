
/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/*******************************************************************************
 * **Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 * @Client        :  SRI E-Invoice
 * @Script File   :  abj_ue_my_einv_updating_field_values.js  
 * @script Record : - EINV UE | E-Invoice Update Flds k1
 * @Trigger Type  :  beforeSubmit
 * @Release Date  :  25/07/2024
 * @Author        :  SIRUSOLLA NAGARJUNA
 * @Description   :  This script is used  to Update  K1 number and and country of origin from item receipt record line level to "vendorbill", "expensereport", "check","creditmemo","invoice" before Sumbitting record.
 * @Deployment To :  "vendorbill", "expensereport", "check","creditmemo","invoice"
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @Ticket_id : TECH-181
 *
 ******************************************************************************/
define(['N/record', 'N/runtime', 'N/log', 'N/runtime'], function (record, runtime, log, runtime) {
    function beforeSubmit(context) {
        var newRecord = context.newRecord;
        var newRecord_type = newRecord.type;
        var validTypes = ["vendorbill", "expensereport", "check", "creditmemo"];

        if (validTypes.includes(newRecord_type)) {
            try {
                var ir_id = newRecord.getValue("custbody_abj_ir");
                log.debug("IR ID", ir_id);
                if (ir_id) {
                    try {
                        var ir_record = record.load({
                            type: "itemreceipt",
                            id: ir_id
                        });
                        var custbody4Value = ir_record.getValue("custbody4");
                        log.debug("K1 value from IR record", custbody4Value);
                        var itemCount = ir_record.getLineCount({
                            sublistId: 'item'
                        });
                        for (var i = 0; i < itemCount; i++) {
                            var itemDescription = ir_record.getSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_ein_t_countryoforigin',
                                line: i
                            });
                            log.debug("Item Description from IR record", itemDescription);
                            newRecord.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_ein_t_countryoforigin',
                                line: i,
                                value: itemDescription
                            });
                        }
                        newRecord.setValue({
                            fieldId: "custbody_t_importedgoodsrefno",
                            value: custbody4Value
                        });
                        log.debug("Successfully set K1 value", custbody4Value);
                    } catch (e) {
                        log.error("Error looking up fields or setting value", e.toString());
                    }
                }
                logRemainingUsage();
            } catch (e) {
                log.error(e.name, e.message);
            }
        }
        if (newRecord_type === "invoice") {
            try {
                var itemFulfillmentId = newRecord.getValue("custbody_abj_if");
                log.debug("Item Fulfillment ID", itemFulfillmentId);

                if (itemFulfillmentId) {
                    try {
                        var itemFulfillmentRecord = record.load({
                            type: "itemfulfillment",
                            id: itemFulfillmentId
                        });
                        var portNameValue = itemFulfillmentRecord.getValue("custbody_abj_port_name");
                        log.debug("Port Name Value from Item Fulfillment Record", portNameValue);

                        newRecord.setValue({
                            fieldId: "custbody_ein_t_exportedgoodsrefno",
                            value: portNameValue
                        });
                        log.debug("Successfully set Port Name Value", portNameValue);

                        var itemCount = itemFulfillmentRecord.getLineCount({
                            sublistId: 'item'
                        });

                        for (var line = 0; line < itemCount; line++) {
                            var countryOfOrigin = itemFulfillmentRecord.getSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_ein_t_countryoforigin',
                                line: line
                            });
                            log.debug("Country of Origin from Item Fulfillment Record", countryOfOrigin);

                            newRecord.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_ein_t_countryoforigin',
                                line: line,
                                value: countryOfOrigin
                            });
                        }
                    } catch (e) {
                        log.error("Error loading fields or setting values", e.toString());
                    }
                }
                logRemainingUsage();
            } catch (e) {
                log.error(e.name, e.message);
            }
        }
    }

    function logRemainingUsage() {
        var scriptObj = runtime.getCurrentScript();
        var remainingUsage = scriptObj.getRemainingUsage();
        var totalUnits = 1000;
        log.debug("Current script consuming units: ", totalUnits - remainingUsage);
    }
    return {
        beforeSubmit: beforeSubmit
    };
});