/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
define([], function () {

    getInvoiceUBLJSON = () => {
        return {
            "_D": "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2",
            "_A": "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2",
            "_B": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",
            "Invoice": [{
                "ID": [{
                    "_": ""
                }],
                "IssueDate": [{
                    "_": ""
                }],
                "IssueTime": [{
                    "_": ""
                }],
                "InvoiceTypeCode": [{
                    "_": "",
                    "listVersionID": "1.1"
                }],
                "DocumentCurrencyCode": [{
                    "_": ""
                }],
                "InvoicePeriod": [{
                    "StartDate": [{
                        "_": ""
                    }],
                    "EndDate": [{
                        "_": ""
                    }],
                    "Description": [{
                        "_": ""
                    }]
                }],
                "BillingReference": [{
                        "AdditionalDocumentReference": [{
                            "ID": [{
                                "_": ""
                            }]
                        }]
                    },
                    {
                        "InvoiceDocumentReference": [{
                            "ID": [{
                                "_": ""
                            }],
                            "UUID": [{
                                "_": ""
                            }]
                        }]
                    }
                ],
                "AdditionalDocumentReference": [{
                        "ID": [{
                            "_": ""
                        }],
                        "DocumentType": [{
                            "_": ""
                        }]
                    },
                    {
                        "ID": [{
                            "_": ""
                        }],
                        "DocumentType": [{
                            "_": ""
                        }],
                        "DocumentDescription": [{
                            "_": ""
                        }]
                    },
                    {
                        "ID": [{
                            "_": ""
                        }],
                        "DocumentType": [{
                            "_": ""
                        }]
                    },
                    {
                        "ID": [{
                            "_": ""
                        }]
                    }
                ],
                "AccountingSupplierParty": [{
                    "AdditionalAccountID": [{
                        "_": "",
                        "schemeAgencyName": ""
                    }],
                    "Party": [{
                        "IndustryClassificationCode": [{
                            "_": "",
                            "name": ""
                        }],
                        "PartyIdentification": [{
                                "ID": [{
                                    "_": "",
                                    "schemeID": ""
                                }]
                            },
                            {
                                "ID": [{
                                    "_": "",
                                    "schemeID": ""
                                }]
                            },
                            {
                                "ID": [{
                                    "_": "",
                                    "schemeID": ""
                                }]
                            }
                        ],
                        "PostalAddress": [{
                            "CityName": [{
                                "_": ""
                            }],
                            "PostalZone": [{
                                "_": ""
                            }],
                            "CountrySubentityCode": [{
                                "_": ""
                            }],
                            "AddressLine": [{
                                    "Line": [{
                                        "_": ""
                                    }]
                                },
                                {
                                    "Line": [{
                                        "_": ""
                                    }]
                                },
                                {
                                    "Line": [{
                                        "_": ""
                                    }]
                                }
                            ],
                            "Country": [{
                                "IdentificationCode": [{
                                    "_": "",
                                    "listID": "",
                                    "listAgencyID": ""
                                }]
                            }]
                        }],
                        "PartyLegalEntity": [{
                            "RegistrationName": [{
                                "_": ""
                            }]
                        }],
                        "Contact": [{
                            "Telephone": [{
                                "_": ""
                            }],
                            "ElectronicMail": [{
                                "_": ""
                            }]
                        }]
                    }]
                }],
                "AccountingCustomerParty": [{
                    "Party": [{
                        "PostalAddress": [{
                            "CityName": [{
                                "_": ""
                            }],
                            "PostalZone": [{
                                "_": ""
                            }],
                            "CountrySubentityCode": [{
                                "_": ""
                            }],
                            "AddressLine": [{
                                    "Line": [{
                                        "_": ""
                                    }]
                                },
                                {
                                    "Line": [{
                                        "_": ""
                                    }]
                                },
                                {
                                    "Line": [{
                                        "_": ""
                                    }]
                                }
                            ],
                            "Country": [{
                                "IdentificationCode": [{
                                    "_": "",
                                    "listID": "",
                                    "listAgencyID": ""
                                }]
                            }]
                        }],
                        "PartyLegalEntity": [{
                            "RegistrationName": [{
                                "_": ""
                            }]
                        }],
                        "PartyIdentification": [{
                                "ID": [{
                                    "_": "",
                                    "schemeID": ""
                                }]
                            },
                            {
                                "ID": [{
                                    "_": "",
                                    "schemeID": ""
                                }]
                            },
                            {
                                "ID": [{
                                    "_": "",
                                    "schemeID": ""
                                }]
                            }
                        ],
                        "Contact": [{
                            "Telephone": [{
                                "_": ""
                            }],
                            "ElectronicMail": [{
                                "_": ""
                            }]
                        }]
                    }]
                }],
                "Delivery": [{
                    "DeliveryParty": [{
                        "PartyLegalEntity": [{
                            "RegistrationName": [{
                                "_": ""
                            }]
                        }],
                        "PostalAddress": [{
                            "CityName": [{
                                "_": ""
                            }],
                            "PostalZone": [{
                                "_": ""
                            }],
                            "CountrySubentityCode": [{
                                "_": ""
                            }],
                            "AddressLine": [{
                                    "Line": [{
                                        "_": ""
                                    }]
                                },
                                {
                                    "Line": [{
                                        "_": ""
                                    }]
                                },
                                {
                                    "Line": [{
                                        "_": ""
                                    }]
                                }
                            ],
                            "Country": [{
                                "IdentificationCode": [{
                                    "_": "",
                                    "listID": "",
                                    "listAgencyID": ""
                                }]
                            }]
                        }],
                        "PartyIdentification": [{
                                "ID": [{
                                    "_": "",
                                    "schemeID": ""
                                }]
                            },
                            {
                                "ID": [{
                                    "_": "",
                                    "schemeID": ""
                                }]
                            }
                        ]
                    }],
                    "Shipment": [{
                        "ID": [{
                            "_": ""
                        }],
                        "FreightAllowanceCharge": [{
                            "ChargeIndicator": [{
                                "_": true
                            }],
                            "AllowanceChargeReason": [{
                                "_": ""
                            }],
                            "Amount": [{
                                "_": 0,
                                "currencyID": ""
                            }]
                        }]
                    }]
                }],
                "PaymentMeans": [{
                    "PaymentMeansCode": [{
                        "_": "0"
                    }],
                    "PayeeFinancialAccount": [{
                        "ID": [{
                            "_": ""
                        }]
                    }]
                }],
                "PaymentTerms": [{
                    "Note": [{
                        "_": ""
                    }]
                }],
                "PrepaidPayment": [{
                    "ID": [{
                        "_": ""
                    }],
                    "PaidAmount": [{
                        "_": 0,
                        "currencyID": ""
                    }],
                    "PaidDate": [{
                        "_": ""
                    }],
                    "PaidTime": [{
                        "_": ""
                    }]
                }],
                "AllowanceCharge": [{
                        "ChargeIndicator": [{
                            "_": true
                        }],
                        "AllowanceChargeReason": [{
                            "_": ""
                        }],
                        "Amount": [{
                            "_": 0,
                            "currencyID": ""
                        }]
                    },
                    {
                        "ChargeIndicator": [{
                            "_": false
                        }],
                        "AllowanceChargeReason": [{
                            "_": ""
                        }],
                        "Amount": [{
                            "_": 0,
                            "currencyID": ""
                        }]
                    }
                ],
                "TaxTotal": [{
                    "TaxAmount": [{
                        "_": 0,
                        "currencyID": ""
                    }],
                    "TaxSubtotal": [{
                        "TaxableAmount": [{
                            "_": 0,
                            "currencyID": ""
                        }],
                        "TaxAmount": [{
                            "_": 0,
                            "currencyID": ""
                        }],
                        "TaxCategory": [{
                            "ID": [{
                                "_": ""
                            }],
                            "TaxScheme": [{
                                "ID": [{
                                    "_": "",
                                    "schemeID": "",
                                    "schemeAgencyID": ""
                                }]
                            }]
                        }]
                    }]
                }],
                "LegalMonetaryTotal": [{
                    "LineExtensionAmount": [{
                        "_": 0,
                        "currencyID": ""
                    }],
                    "TaxExclusiveAmount": [{
                        "_": 0,
                        "currencyID": ""
                    }],
                    "TaxInclusiveAmount": [{
                        "_": 0,
                        "currencyID": ""
                    }],
                    "AllowanceTotalAmount": [{
                        "_": 0,
                        "currencyID": ""
                    }],
                    "ChargeTotalAmount": [{
                        "_": 0,
                        "currencyID": ""
                    }],
                    "PayableRoundingAmount": [{
                        "_": 0,
                        "currencyID": ""
                    }],
                    "PayableAmount": [{
                        "_": 0,
                        "currencyID": ""
                    }]
                }],
                "TaxExchangeRate": [{
                    "SourceCurrencyCode": [{
                        "_": ""
                    }],
                    "TargetCurrencyCode": [{
                        "_": ""
                    }],
                    "CalculationRate": [{
                        "_": 1
                    }]
                }],
                "InvoiceLine": []
            }]
        }
    }

    getDigiCertJSON = () => {
        return {
            "UBLExtensions": [{
                "UBLExtension": [{
                    "ExtensionURI": [{
                        "_": "urn:oasis:names:specification:ubl:dsig:enveloped:xades"
                    }],
                    "ExtensionContent": [{
                        "UBLDocumentSignatures": [{
                            "SignatureInformation": [{
                                "ID": [{
                                    "_": "urn:oasis:names:specification:ubl:signature:1"
                                }],
                                "ReferencedSignatureID": [{
                                    "_": "urn:oasis:names:specification:ubl:signature:Invoice"
                                }],
                                "Signature": [{
                                    "Id": "signature",
                                    "Object": [{
                                        "QualifyingProperties": [{
                                            "Target": "signature",
                                            "SignedProperties": [{
                                                "Id": "id-xades-signed-props",
                                                "SignedSignatureProperties": [{
                                                    "SigningTime": [{
                                                        "_": "2024-07-27T13:22:39Z"
                                                    }],
                                                    "SigningCertificate": [{
                                                        "Cert": [{
                                                            "CertDigest": [{
                                                                "DigestMethod": [{
                                                                    "_": "",
                                                                    "Algorithm": "http://www.w3.org/2001/04/xmlenc#sha256"
                                                                }],
                                                                "DigestValue": [{
                                                                    "_": ""
                                                                }]
                                                            }],
                                                            "IssuerSerial": [{
                                                                "X509IssuerName": [{
                                                                    "_": ""
                                                                }],
                                                                "X509SerialNumber": [{
                                                                    "_": ""
                                                                }]
                                                            }]
                                                        }]
                                                    }]
                                                }]
                                            }]
                                        }]
                                    }],
                                    "KeyInfo": [{
                                        "X509Data": [{
                                            "X509Certificate": [{
                                                "_": ""
                                            }],
                                            "X509SubjectName": [{
                                                "_": ""
                                            }],
                                            "X509IssuerSerial": [{
                                                "X509IssuerName": [{
                                                    "_": ""
                                                }],
                                                "X509SerialNumber": [{
                                                    "_": ""
                                                }]
                                            }]
                                        }]
                                    }],
                                    "SignatureValue": [{
                                        "_": "Gw5uGjtok0IiPQ+hVH8R2xKFTojrm2fVM8P4wtcfgemqaJSAntAcacb8vcTbU6WAfLcIneEXRHTCG+qzawqBN6bjIl9yfsQ+IGReQhbZqQ43Zh2fFgPBwLo4Ywp4NqiGyGsrd/lm4PPtE8PmZbcQHTudHMYYxDDykA0ok1Lw6Xt/+lR7WHtp8+kHW37V8iPEDWAq5kfHazvke5kkzY+M/mWCzqlE4bIIiEk1lNjovGbER4K8XM3oMQUPpHkYi1P/UUMFP7QIAzMsLXKwmXx1rM77mfmOVrzNHgbetyfPJsfqiDrwQpB6KcODsui5CmhfrphMJs5gwcH7sG+6TNVn6w=="
                                    }],
                                    "SignedInfo": [{
                                        "SignatureMethod": [{
                                            "_": "",
                                            "Algorithm": "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"
                                        }],
                                        "Reference": [{
                                            "Type": "http://uri.etsi.org/01903/v1.3.2#SignedProperties",
                                            "URI": "#id-xades-signed-props",
                                            "DigestMethod": [{
                                                "_": "",
                                                "Algorithm": "http://www.w3.org/2001/04/xmlenc#sha256"
                                            }],
                                            "DigestValue": [{
                                                "_": ""
                                            }]
                                        }, {
                                            "Type": "",
                                            "URI": "",
                                            "DigestMethod": [{
                                                "_": "",
                                                "Algorithm": "http://www.w3.org/2001/04/xmlenc#sha256"
                                            }],
                                            "DigestValue": [{
                                                "_": ""
                                            }]
                                        }]
                                    }]
                                }] //
                            }]
                        }]
                    }]
                }]
            }],
            "Signature": [{
                "ID": [{
                    "_": "urn:oasis:names:specification:ubl:signature:Invoice"
                }],
                "SignatureMethod": [{
                    "_": "urn:oasis:names:specification:ubl:dsig:enveloped:xades"
                }]
            }]
        }
    }

    return {
        getInvoiceUBLJSON: getInvoiceUBLJSON,
        getDigiCertJSON: getDigiCertJSON
    }

});