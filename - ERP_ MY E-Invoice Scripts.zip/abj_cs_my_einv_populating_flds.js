/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/*******************************************************************************
 * **Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 * @Client        :  SRI E-Invoice
 * @Script File   :  abj_cs_my_einv_populating_flds.js
 * @script Record : - EINV CS | E-Invoice Update Entity Flds
 * @Trigger Type  :  pageInit,fieldChanged
 * @Release Date  :  25/07/2024
 * @Author        :  SIRUSOLLA NAGARJUNA
 * @Description   :  This script is used for to populate city,state,country,Local/International  fields on invoice,creditmemo,vendorcredit,vendorbill,check,expensereport
 * @Deployment To:  invoice,creditmemo,vendorcredit,vendorbill,check,expensereport 
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @Ticket_id : TECH-180
 *
 ******************************************************************************/
define(['N/record', 'N/log', 'N/currentRecord', 'N/search', 'N/runtime'], function (record, log, currentRecord, search, runtime) {

    function updateCustomerInfo(currentRec, entityId, entityType) {
        try {
            log.debug("currentRec:", currentRec)
            log.debug("entityId:", entityId)
            log.debug("entityType:", entityType)

            var entitySearch = search.create({
                type: entityType,
                filters: [
                    ["internalid", "anyof", entityId]
                ],
                columns: [
                    "custentity_ein_c_international_local",
                    "custentity_ein_c_state",
                    "custentity_ein_c_city",
                    "custentity_ein_c_country"
                ]
            });

            var searchResult = entitySearch.run().getRange({
                start: 0,
                end: 1
            });

            if (searchResult.length > 0) {
                var result = searchResult[0];
                var city = result.getValue("custentity_ein_c_city");
                var state = result.getValue("custentity_ein_c_state");
                var country = result.getValue("custentity_ein_c_country");
                var localInter = result.getValue("custentity_ein_c_international_local");

                log.debug("City", city);
                log.debug("State", state);
                log.debug("Country", country);
                log.debug("Local/International", localInter);

                currentRec.setValue("custbody_ein_t_c_city", city)
                    .setValue("custbody_ein_t_c_state", state)
                    .setValue("custbody_ein_t_c_country", country)
                    .setValue("custbody_ein_t_international_local", localInter);
            }
        } catch (e) {
            log.error(e.name, e.message);
        }
    }

    function pageInit(context) {
        var currentRec = context.currentRecord;
        var recType = currentRec.type;
        var createdFrom;
        try {
            if (["salesorder","purchaseorder","invoice", "creditmemo", "vendorcredit"].includes(recType)) {
                createdFrom = currentRec.getValue("createdfrom");
            } else if (recType === "vendorbill") {
                createdFrom = currentRec.getValue("itemrcpt");
            }

            if (!createdFrom) {
                return;
            }

            var lookupResult = search.lookupFields({
                type: 'transaction',
                id: createdFrom,
                columns: ['recordtype']
            });
            var entityType = lookupResult.recordtype;
            //log.debug("Entity Type", entityType);
            var customerId = currentRec.getValue("entity");
            if (recType === "invoice" || recType === "creditmemo" || recType === "salesorder") {
                updateCustomerInfo(currentRec, customerId, "customer");
            }
            if (recType === "vendorbill" || recType === "purchaseorder") {
                updateCustomerInfo(currentRec, customerId, "vendor");
            }

            logRemainingUsage();
        } catch (e) {
            log.error(e.name, e.message);
        }
    }

    function fieldChanged(context) {
        try {
            var currentRec = context.currentRecord;
            var currentRecType = currentRec.type;
            var fldId = context.fieldId;

            if (fldId === "entity") {
                var entityId = currentRec.getValue(fldId);

                if (entityId) {
                    if (["salesorder","invoice", "creditmemo"].includes(currentRecType)) {
                        updateCustomerInfo(currentRec, entityId, "customer");
                    } else if (["purchaseorder","vendorbill", "vendorcredit"].includes(currentRecType)) {
                        updateCustomerInfo(currentRec, entityId, "vendor");
                    } else if (currentRecType === "check") {
                        var entityType = search.lookupFields({
                            type: search.Type.ENTITY,
                            id: entityId,
                            columns: ["recordtype"]
                        }).recordtype;
                        log.debug("Entity Type", entityType);
                        updateCustomerInfo(currentRec, entityId, entityType);
                    } else if (currentRecType === "expensereport") {
                        updateCustomerInfo(currentRec, entityId, "employee");
                    }
                    logRemainingUsage();
                }
            }
        } catch (e) {
            log.error(e.name, e.message);
        }
    }

    function logRemainingUsage() {
        var scriptObj = runtime.getCurrentScript();
        var remainingUsage = scriptObj.getRemainingUsage();
        var totalUnits = 1000;
        log.debug("Current script consuming units: ", totalUnits - remainingUsage);
    }

    return {
        pageInit: pageInit,
        fieldChanged: fieldChanged
    };
});