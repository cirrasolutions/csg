/***************************************************************************************
 ** Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 ** A1-13-2 Arcoris Business Suite, 10, Jalan Kiara, Mont Kiara, 50480 Kuala Lumpur, Malaysia
 ** All Rights Reserved.
 ** This software is the confidential and proprietary information of ABJ Cloud Solutions. ("Confidential Information").
 ** You shall not disclose such Confidential Information and shall use it only in accordance with the terms of the license agreement you entered into with ABJ Cloud Solutions.                   
 ***************************************************************************************/
/*******************************************************************************
 * **Copyright (c) 2020 ABJ Cloud Solutions, Inc.
 * @Client        :  SRI E-Invoice
 * @Script File   :  abj_cs_my_einv_setting_itm_flds.js
 * @script Record : - EINV CS | E-Invoice Update Item Flds
 * @Trigger Type  : fieldChanged
 * @Release Date  :  25/07/2024
 * @Author        :  SIRUSOLLA NAGARJUNA
 * @Description   :  This script is used  to populate PRODUCT TARIFF CODE,CLASSIFICATION,COUNTRY OF ORIGIN invoice,creditmemo,vendorcredit,vendorbill,check when selecting item.
 * @Deployment To:  invoice,creditmemo,vendorcredit,vendorbill,check 
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @Ticket_id : TECH-180
 *
 ******************************************************************************/
define(['N/record', 'N/log', 'N/currentRecord', 'N/search', 'N/runtime'], function (record, log, currentRecord, search, runtime) {
    function fieldChanged(context) {
        try {
            var currentRecordObj = context.currentRecord;
            var fieldId = context.fieldId;
            var sublistId = context.sublistId;

            if (sublistId === 'item' && fieldId === "item") {
                log.debug("currentRecordObj", currentRecordObj);
                var itemListId = currentRecordObj.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'item'
                });

                var item_type = search.lookupFields({
                    type: search.Type.ITEM,
                    id: itemListId,
                    columns: ["recordtype"]
                }).recordtype;

                var item_rec = record.load({
                    type: item_type,
                    id: itemListId
                });

                log.debug("item_type", item_type);
                var item_class = item_rec.getValue("custitem_ein_i_classification_codes");
                var item_hscode = item_rec.getValue("custitem_abj_hs_code");
                var item_reason = item_rec.getValue("custitemcustitem_ein_i_tax_exp_reason");
                log.debug("Item Details", "item_class: " + item_class + ", item_hscode: " + item_hscode + ", item_reason: " + item_reason);

                if (item_class) {
                    currentRecordObj.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_ein_t_classification',
                        value: item_class
                    });
                }
                if (item_hscode) {
                    currentRecordObj.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_ein_t_prodtariffcode',
                        value: item_hscode
                    });
                }
                if (item_reason) {
                    currentRecordObj.setCurrentSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_ein_t_taxexemptionreason',
                        value: item_reason
                    });
                   logRemainingUsage();
                }
            }
        } catch (e) {
            log.debug(e.name, e.message);
        }
    }

    function logRemainingUsage() {
        var scriptObj = runtime.getCurrentScript();
        var remainingUsage = scriptObj.getRemainingUsage();
        var totalUnits = 1000;
        log.debug("Current script consuming units: ", totalUnits - remainingUsage);
    }

    return {
        fieldChanged: fieldChanged
    };
});